sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/Device"
], function (Controller, Filter, FilterOperator, MessageBox, Device) {
	"use strict";

	return Controller.extend("gdsd.FundingApplicationProcess.ApplicationFundProcess.controller.ApplicationInfo", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.FundingApplicationProcess.ApplicationFundProcess.view.ApplicationInfo
		 */
		onInit: function () {
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this._processModel = this.getOwnerComponent().getModel("ApplicationProcessing");
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this._mViewSettingsDialogs = {};
			this.TargetGroupModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.BeneficiariesModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.CapacityModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.Router.getRoute("ApplicationInfo").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function (e) {

			this.CapacityModel.getData().data = [];
			this.BeneficiariesModel.getData().data = [];
			this.TargetGroupModel.getData().data = [];

			this.RestoreModels();

			this.sPath = "/" + window.decodeURIComponent(e.getParameter("arguments").Path);

			if (e.getParameter("arguments").Path !== undefined) {
				this.oProperty = this._processModel.getProperty(this.sPath);
				this.getApplicationData(this.Guid);
			}
		},

		getApplicationData: function (vGuid) {

			sap.ui.core.BusyIndicator.show(0);
			this._oODataModel.read("/GetCRAGRelatedApplicationSet(Guid='" + this.oProperty.Guid + "')", {
				success: function (odata) {
					if (odata) {
						var ApplicationJsonModel = new sap.ui.model.json.JSONModel({
							data: odata
						});
						
						//Get Application Guid
						this.ApplicGuid = odata.Guid;

						//Set Binding Mode
						ApplicationJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
						
						this.byId("headerNPO").setTitle("Application: " + odata.ObjectId);

						this.byId("detailPage").setTitle(odata.But000.McName1);
						if (odata.Statu.Status === "I1002") {
							this.byId("Status").setText(odata.Statu.Txt30);
							this.byId("Status").setState("Success");
						} else {
							this.byId("Status").setText(odata.Statu.Txt30);
							this.byId("Status").setState("Error");
						}

						this.byId("BankName").setValue(odata.Bankname.Banka);

						if (odata.Banking.Bkont === "01") {
							this.byId("BankType").setValue("Current Account");
						} else if (odata.Banking.Bkont === "02") {
							this.byId("BankType").setValue("Savings Account");
						} else if (odata.Banking.Bkont === "03") {
							this.byId("BankType").setValue("Loan Account");
						} else if (odata.Banking.Bkont === "04") {
							this.byId("BankType").setValue("General Ledger");
						}
					}

					//this.byId("btnSubmit").setVisible(false);

					this.byId("headerNPO").setModel(ApplicationJsonModel);
					this.byId("headerNPO").bindElement({
						path: "/data"
					});

					this.byId("formOrg").setModel(ApplicationJsonModel);
					this.byId("formOrg").bindElement({
						path: "/data"
					});

					this.byId("formAdrc").setModel(ApplicationJsonModel);
					this.byId("formAdrc").bindElement({
						path: "/data"
					});

					this.byId("formContacts").setModel(ApplicationJsonModel);
					this.byId("formContacts").bindElement({
						path: "/data"
					});

					this.byId("formBank").setModel(ApplicationJsonModel);
					this.byId("formBank").bindElement({
						path: "/data"
					});

					this.byId("formApplication").setModel(ApplicationJsonModel);
					this.byId("formApplication").bindElement({
						path: "/data"
					});

					this.byId("formViability").setModel(ApplicationJsonModel);
					this.byId("formViability").bindElement({
						path: "/data"
					});

					this.byId("formCost").setModel(ApplicationJsonModel);
					this.byId("formCost").bindElement({
						path: "/data"
					});

					this.byId("formMonitorNPO").setModel(ApplicationJsonModel);
					this.byId("formMonitorNPO").bindElement({
						path: "/data"
					});

					this.byId("formCapacity").setModel(ApplicationJsonModel);
					this.byId("formCapacity").bindElement({
						path: "/data"
					});

					this.byId("formFundingReq").setModel(ApplicationJsonModel);
					this.byId("formFundingReq").bindElement({
						path: "/data"
					});

					this.byId("formAchievements").setModel(ApplicationJsonModel);
					this.byId("formAchievements").bindElement({
						path: "/data"
					});

					this.byId("formChallenges").setModel(ApplicationJsonModel);
					this.byId("formChallenges").bindElement({
						path: "/data"
					});

					this.byId("formNetworks").setModel(ApplicationJsonModel);
					this.byId("formNetworks").bindElement({
						path: "/data"
					});
					
						this.byId("formOverviewAppDet").setModel(ApplicationJsonModel);
			this.byId("formOverviewAppDet").bindElement({
				path: "/data"
			});

			this.byId("formOverviewProgramV").setModel(ApplicationJsonModel);
			this.byId("formOverviewProgramV").bindElement({
				path: "/data"
			});

			this.byId("formOverviewAchievements").setModel(ApplicationJsonModel);
			this.byId("formOverviewAchievements").bindElement({
				path: "/data"
			});

			this.byId("formOverviewChallenges").setModel(ApplicationJsonModel);
			this.byId("formOverviewChallenges").bindElement({
				path: "/data"
			});

			this.byId("formOverviewCapacityB").setModel(ApplicationJsonModel);
			this.byId("formOverviewCapacityB").bindElement({
				path: "/data"
			});

			this.byId("formOverviewFunding").setModel(ApplicationJsonModel);
			this.byId("formOverviewFunding").bindElement({
				path: "/data"
			});

			this.byId("formOverviewSummaryC").setModel(ApplicationJsonModel);
			this.byId("formOverviewSummaryC").bindElement({
				path: "/data"
			});

			this.byId("formOverviewSustain").setModel(ApplicationJsonModel);
			this.byId("formOverviewSustain").bindElement({
				path: "/data"
			});

			this.byId("formOverviewMonitor").setModel(ApplicationJsonModel);
			this.byId("formOverviewMonitor").bindElement({
				path: "/data"
			});

			this.byId("formOverviewNetworks").setModel(ApplicationJsonModel);
			this.byId("formOverviewNetworks").bindElement({
				path: "/data"
			});

					this.getView().setModel(ApplicationJsonModel);

					//ECM Intergration
					var SAPObj, ObjId;
					SAPObj = 'BUS2000270';
					ObjId = this.ApplicGuid;
					//destroy content on the attachment Icon Tab Filer 
					this.byId("WPFilter").destroyContent();
					//create an HTML object so that an iFrame can be added
					var html = new sap.ui.core.HTML();
					//adding a standard Fiori ECM application to the iframe and pass necessary url parameters 
					html.setContent("<div class='FrameWrapper'><iframe id='EcmFrame' src='/sap/bc/ui5_ui5/sap/zrmf_bws_ui/index.html?SAPObj=" +
						SAPObj +
						"&ObjId=" + ObjId + "' width='1200px' height='500px'></iframe></div>");
					//adding the html object to the Icon Tab filter
					this.byId("WPFilter").addContent(html);
					this.getCapacities(odata.Guid);

				}.bind(this),
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve application details");
				}.bind(this)
			});
		},

		getCapacities: function (vGuid) {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("RecordId", "EQ", vGuid);

			this._oODataModel.read("/GetCapacitySet", {
				filters: [oFilter],
				success: function (odata) {

					//Distribute capacity data
					this.distrubuteCapacity(odata.results);
				}.bind(this),
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve capacity details");
				}.bind(this)
			});
		},

		distrubuteCapacity: function (arrCapacity) {
			for (var capacity = 0; capacity < arrCapacity.length; capacity++) {

				switch (arrCapacity[capacity].Zztype) {
				case "BENEF":
					this.BeneficiariesModel.getData().data.push(arrCapacity[capacity]);
					break;
				case "TARG":
					this.TargetGroupModel.getData().data.push(arrCapacity[capacity]);
					break;
				case "STAFF":
				case "BOARD":
					this.CapacityModel.getData().data.push(arrCapacity[capacity]);
					break;
				}
			}

			this.RestoreModels();

		},

		RestoreModels: function (oEvent) {

			var oTableTarget = this.byId("targetTable");
			var oTableCapacity = this.byId("BoardCapacity");
			var oTableBeneficiary = this.byId("beneficiariesTable");

			oTableBeneficiary.setModel(this.BeneficiariesModel, "BeneficiariesModel");
			oTableBeneficiary.getModel("BeneficiariesModel").refresh(true);

			oTableCapacity.setModel(this.CapacityModel, "CapacityModel");
			oTableCapacity.getModel("CapacityModel").refresh(true);

			oTableTarget.setModel(this.TargetGroupModel, "TargetModel");
			oTableTarget.getModel("TargetModel").refresh(true);

			sap.ui.core.BusyIndicator.hide();

		},

		onNpoNextPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("application");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onApplicationDeteailsPrevPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("npo");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onApplicationDetailsNextPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("programme");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onProgramViabilityPrevPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("application");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onProgramViabilityNextPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("achievements");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAchievementNextPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("challenges");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAchievementPrevPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("programme");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onChallengesNextPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("capacity");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onChallengesPrevPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("achievements");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCapacityNextPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("funding");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCapacityPrevPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("challenges");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onFundingNextPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("cost");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onFundingPrevPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("capacity");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCostNextPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("sustainability");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCostPrevPress: function () {
			//.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("funding");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSustanabilityNextPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("monitoring");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSustanabilityPrevPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("cost");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onMonitoringNextPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("networks");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onMonitoringPrevPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("sustainability");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onNetworksNextPress: function () {
			//this.byId("btnSubmit").setVisible(true);
			this.byId("IconBar").setSelectedKey("attachments");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onNetworksPrevPress: function () {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("monitoring");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAttachmentsNextPress: function () {
			this.byId("IconBar").setSelectedKey("beneficiary");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAttachmentsPrevPress: function () {
			this.byId("IconBar").setSelectedKey("particular");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCRNextPress: function () {
			this.byId("IconBar").setSelectedKey("particular");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCRPrevPress: function () {
			this.byId("IconBar").setSelectedKey("particular");
			this.byId("detailPage").scrollTo(0, 0);
		},
		
		onSummary: function () {

			var oTableTarget = this.byId("targetTable");
			var oTableCapacity = this.byId("BoardCapacity");
			var oTableBeneficiary = this.byId("beneficiariesTable");
			
			this.byId("btnSubmit").setVisible(true);
			this.byId("IconBar").setSelectedKey("overview");
			this.byId("detailPage").scrollTo(0, 0);

			this.byId("AppTargetGroup1").setText(oTableTarget.getModel("TargetModel").getData().data.length);
			this.byId("AppNumberofBeneficiaries1").setText(oTableBeneficiary.getModel("BeneficiariesModel").getData().data.length);
			this.byId("AppCapacityofBoardStaff1").setText(oTableCapacity.getModel("CapacityModel").getData().data.length);
		},

		handleIconTabBarSelect: function (oEvent) {
			var sKey = oEvent.getParameter("key");

		//	if (sKey === "attachments") {
				//	this.byId("btnSubmit").setVisible(false);
		//	} else {
				//	this.byId("btnSubmit").setVisible(false);
		//	}
			if (sKey === "overview") {
				this.onSummary();
			}
		},

		onNavBack: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ApplicationProcess", true);
		},

		onProcess: function () {

			this.Router.navTo("Processing", {
				//prepare object path to be passed on to target
				TaskType: this.oProperty.TaskType,
				Path: window.encodeURIComponent(this.sPath.substr(1)),
				ApplicGuid: this.ApplicGuid
			});
		},

		onPressBeneficiary: function (oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogBeneficiary = this.createFormDialog(
				"gdsd.FundingApplicationProcess.ApplicationFundProcess.view.fragments.Beneficiariers");

			this._DialogBeneficiary.setModel(this.BeneficiariesModel);
			this._DialogBeneficiary.bindElement(oBindingContextPath);

			this._DialogBeneficiary.open();

		},

		onPressTarget: function (oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogTarget = this.createFormDialog("gdsd.FundingApplicationProcess.ApplicationFundProcess.view.fragments.TargetGroup");

			this._DialogTarget.setModel(this.TargetGroupModel);
			this._DialogTarget.bindElement(oBindingContextPath);

			this._DialogTarget.open();

		},

		onPressCapacity: function (oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogTarget = this.createFormDialog("gdsd.FundingApplicationProcess.ApplicationFundProcess.view.fragments.Capacity");

			this._DialogTarget.setModel(this.CapacityModel);
			this._DialogTarget.bindElement(oBindingContextPath);

			this._DialogTarget.open();

		},

		createFormDialog: function (sDialogFragmentName) {

			// https://stackoverflow.com/questions/55667673/how-to-remove-duplicates-and-display-only-unique-values-in-viewsettingsitem
			var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
				this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;

				if (Device.system.desktop) {
					oDialog.addStyleClass("sapUiSizeCompact");
				}
			}
			return oDialog;
		}

	});

});