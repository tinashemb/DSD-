sap.ui.define([
	"gdsd/FundingApplicationProcess/ApplicationFundProcess/test/unit/controller/ApplicationProcess.controller"
], function () {
	"use strict";
});