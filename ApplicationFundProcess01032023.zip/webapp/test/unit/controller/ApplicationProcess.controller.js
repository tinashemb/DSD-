/*global QUnit*/

sap.ui.define([
	"gdsd/FundingApplicationProcess/ApplicationFundProcess/controller/ApplicationProcess.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ApplicationProcess Controller");

	QUnit.test("I should test the ApplicationProcess controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});