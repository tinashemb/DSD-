sap.ui.define([
	"./BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"sap/ui/core/library"
	// "sap/ui/core/mvc/Controller"
], function(BaseController, Filter, FilterOperator, MessageBox, Device, Fragment, coreLibrary) {
	"use strict";
	return BaseController.extend("gdsd.FundingApplication.controller.NewApplication", {

		onInit: function() {
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);

			//get the odata model from the component
			this._oODataModel = this.getOwnerComponent().getModel();
			this._mViewSettingsDialogs = {};

			this.CapacityModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.TargetGroupModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.BeneficiariesModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.CostImplicationsModel = new sap.ui.model.json.JSONModel({
				data: []

			});

			this.OnceOffModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			//Set Binding Mode
			this.CapacityModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.TargetGroupModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.BeneficiariesModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.CostImplicationsModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.OnceOffModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

			this.getProgramType();

			this.Router.getRoute("NewApplication").attachPatternMatched(this._onObjectMatched, this);

		},

		_onObjectMatched: function(oEvent) {
			this.BpNo = oEvent.getParameter("arguments").BpNo;

			this.byId("headerNPO").setTitle("New Application");
			this.byId("Objective").setValue();
			//			this.byId("Region").setSelectedKey();
			//			this.byId("Region").setSelectedItem();

			this.byId("Objective").setEnabled(true);
			//			this.byId("Region").setEnabled(true);
			this.byId("pickerImplStart").setEnabled(true);
			this.byId("pickerImplEnd").setEnabled(true);

			this.CapacityModel.getData().data = [];
			this.BeneficiariesModel.getData().data = [];
			this.TargetGroupModel.getData().data = [];
		//	this.CostImplicationsModel.getData().data = [];
			this.OnceOffModel.getData().data = [];

			var oTableTarget = this.byId("targetTable");
			var oTableCapacity = this.byId("BoardCapacity");
			var oTableBeneficiary = this.byId("beneficiariesTable");
		//	var oTableCost = this.byId("FCItable");
			var oTableAsset = this.byId("OnceOffCostsTable");

			oTableBeneficiary.setModel(this.BeneficiariesModel, "BeneficiariesModel");
			oTableBeneficiary.getModel("BeneficiariesModel").refresh(true);

			oTableCapacity.setModel(this.CapacityModel, "CapacityModel");
			oTableCapacity.getModel("CapacityModel").refresh(true);

			oTableTarget.setModel(this.TargetGroupModel, "TargetModel");
			oTableTarget.getModel("TargetModel").refresh(true);

		//	oTableCost.setModel(this.CostImplicationsModel, "CostImplicationsModel");
		//	oTableCost.getModel("CostImplicationsModel").refresh(true);

			oTableAsset.setModel(this.OnceOffModel, "OnceOffModel");
			oTableAsset.getModel("OnceOffModel").refresh(true);

			//Get Application Data
			this.getBPData();
		},

		getBPData: function() {

			sap.ui.core.BusyIndicator.show(0);

			var oFilter = new sap.ui.model.Filter("BpNo", "EQ", this.BpNo);

			//this._oODataModel.read("/GET_BPSet(BpName='Test',BpNo='123')", {
			this._oODataModel.read("/GET_BPSet", {
				filters: [oFilter],
				success: function(odata) {

					var BPJsonModel = new sap.ui.model.json.JSONModel({
						data: odata.results[0]
					});

					var NewApplicationJsonModel = new sap.ui.model.json.JSONModel({
						data: []
					});

					this.CostImplicationsJsonModel = new sap.ui.model.json.JSONModel({
						data: []
					});

					//Set Binding Mode
					NewApplicationJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
					this.CostImplicationsJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

					if (odata.results[0].Bnk.AccountType === "01") {
						this.byId("BankType").setValue("Current Account");
					} else if (odata.results[0].Bnk.AccountType === "02") {
						this.byId("BankType").setValue("Savings Account");
					} else if (odata.results[0].Bnk.AccountType === "03") {
						this.byId("BankType").setValue("Loan Account");
					} else if (odata.results[0].Bnk.AccountType === "04") {
						this.byId("BankType").setValue("General Ledger");
					}

					this.byId("headerNPO").setModel(BPJsonModel);
					this.byId("headerNPO").bindElement({
						path: "/data"
					});

					this.byId("formOrg").setModel(BPJsonModel);
					this.byId("formOrg").bindElement({
						path: "/data"
					});

					this.byId("formAdrc").setModel(BPJsonModel);
					this.byId("formAdrc").bindElement({
						path: "/data"
					});

					this.byId("formContacts").setModel(BPJsonModel);
					this.byId("formContacts").bindElement({
						path: "/data"
					});

					this.byId("formBank").setModel(BPJsonModel);
					this.byId("formBank").bindElement({
						path: "/data"
					});

					this.byId("formApplication").setModel(NewApplicationJsonModel);
					this.byId("formApplication").bindElement({
						path: "/data"
					});

					this.byId("formViability").setModel(NewApplicationJsonModel);
					this.byId("formViability").bindElement({
						path: "/data"
					});

					/*	this.byId("FCItable").setModel(CostImplicationsJsonModel);
						this.byId("FCItable").bindElement({
							path: "/data"
						});*/

					this.byId("formMonitorNPO").setModel(NewApplicationJsonModel);
					this.byId("formMonitorNPO").bindElement({
						path: "/data"
					});

					this.byId("formCapacity").setModel(NewApplicationJsonModel);
					this.byId("formCapacity").bindElement({
						path: "/data"
					});

					this.byId("formFundingReq").setModel(NewApplicationJsonModel);
					this.byId("formFundingReq").bindElement({
						path: "/data"
					});

					this.byId("formAchievements").setModel(NewApplicationJsonModel);
					this.byId("formAchievements").bindElement({
						path: "/data"
					});

					this.byId("formChallenges").setModel(NewApplicationJsonModel);
					this.byId("formChallenges").bindElement({
						path: "/data"
					});

					this.byId("formNetworks").setModel(NewApplicationJsonModel);
					this.byId("formNetworks").bindElement({
						path: "/data"
					});

					this.getView().setModel(NewApplicationJsonModel);

					//this.onAddWorkSpace();
					this.getApplicationData();
					//sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve application details");
				}.bind(this)
			});

		},

		getApplicationData: function() {

			sap.ui.core.BusyIndicator.show(0);

			var oFilterBp = new sap.ui.model.Filter("BpNo", "EQ", this.BpNo),
				oFilterStatus = new sap.ui.model.Filter("Status", "EQ", "Y");

			this._oODataModel.read("/GETApplicationFundingSet", {
				filters: [oFilterStatus],
				success: function(odata) {
					if (odata.results[0]) {

						var ApplicationJsonModel = new sap.ui.model.json.JSONModel({
							data: odata.results[0]
						});

						odata.results[0].ProgramId = "";

						//Set Binding Mode
						ApplicationJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

					}

					this.byId("formApplication").setModel(ApplicationJsonModel);
					this.byId("formApplication").bindElement({
						path: "/data"
					});

					this.byId("formViability").setModel(ApplicationJsonModel);
					this.byId("formViability").bindElement({
						path: "/data"
					});

					// this.byId("formCost").setModel(ApplicationJsonModel);
					// this.byId("formCost").bindElement({
					// 	path: "/data"
					// });

					this.byId("formMonitorNPO").setModel(ApplicationJsonModel);
					this.byId("formMonitorNPO").bindElement({
						path: "/data"
					});

					this.byId("formCapacity").setModel(ApplicationJsonModel);
					this.byId("formCapacity").bindElement({
						path: "/data"
					});

					this.byId("formFundingReq").setModel(ApplicationJsonModel);
					this.byId("formFundingReq").bindElement({
						path: "/data"
					});

					this.byId("formAchievements").setModel(ApplicationJsonModel);
					this.byId("formAchievements").bindElement({
						path: "/data"
					});

					this.byId("formChallenges").setModel(ApplicationJsonModel);
					this.byId("formChallenges").bindElement({
						path: "/data"
					});

					this.byId("formSustain").setModel(ApplicationJsonModel);
					this.byId("formSustain").bindElement({
						path: "/data"
					});

					this.byId("formNetworks").setModel(ApplicationJsonModel);
					this.byId("formNetworks").bindElement({
						path: "/data"
					});

					this.byId("formOverviewAppDet").setModel(ApplicationJsonModel);
					this.byId("formOverviewAppDet").bindElement({
						path: "/data"
					});

					this.byId("formOverviewProgramV").setModel(ApplicationJsonModel);
					this.byId("formOverviewProgramV").bindElement({
						path: "/data"
					});

					this.byId("formOverviewAchievements").setModel(ApplicationJsonModel);
					this.byId("formOverviewAchievements").bindElement({
						path: "/data"
					});

					this.byId("formOverviewChallenges").setModel(ApplicationJsonModel);
					this.byId("formOverviewChallenges").bindElement({
						path: "/data"
					});

					this.byId("formOverviewCapacityB").setModel(ApplicationJsonModel);
					this.byId("formOverviewCapacityB").bindElement({
						path: "/data"
					});

					this.byId("formOverviewFunding").setModel(ApplicationJsonModel);
					this.byId("formOverviewFunding").bindElement({
						path: "/data"
					});

					this.byId("formOverviewSummaryC").setModel(ApplicationJsonModel);
					this.byId("formOverviewSummaryC").bindElement({
						path: "/data"
					});

					this.byId("formOverviewSustain").setModel(ApplicationJsonModel);
					this.byId("formOverviewSustain").bindElement({
						path: "/data"
					});

					this.byId("formOverviewMonitor").setModel(ApplicationJsonModel);
					this.byId("formOverviewMonitor").bindElement({
						path: "/data"
					});

					this.byId("formOverviewNetworks").setModel(ApplicationJsonModel);
					this.byId("formOverviewNetworks").bindElement({
						path: "/data"
					});

					this.getView().setModel(ApplicationJsonModel);

					//Validate BP
					if (this.byId("headerNPO").getModel().getData().data.But0id.ValidDateTo !== null) {
						MessageBox.warning("BP: " + this.byId("headerNPO").getModel().getData().data.BpNo + "  is not valid");
					}

					sap.ui.core.BusyIndicator.hide();

				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve application details");
				}.bind(this)
			});

		},

		onAddWorkSpace: function(ObjId) {
			this.AttachmentTab = "";
			//ECM Intergration
			var SAPObj;
			SAPObj = 'BUS2000270';
			//ObjId = '0050569545C51EDB85F0B3462B7E511D';
			//destroy content on the attachment Icon Tab Filer 
			this.byId("WPFilter").destroyContent();
			//create an HTML object so that an iFrame can be added
			var html = new sap.ui.core.HTML();
			//adding a standard Fiori ECM application to the iframe and pass necessary url parameters 
			html.setContent("<div class='FrameWrapper'><iframe id='EcmFrame' src='/sap/bc/ui5_ui5/sap/zrmf_bws_ui/index.html?SAPObj=" +
				SAPObj +
				"&ObjId=" + ObjId + "' width='1200px' height='500px'></iframe></div>");
			//adding the html object to the Icon Tab filter
			this.byId("WPFilter").addContent(html);
		},

		onNPONextPress: function() {
			// create a JSON Object to populate the data for when submitting the data 
			//there is currently no structure developed on the gateway for the create therefore the below structure is a dummy structure
			var oProperty = {};
			oProperty.Type = "";
			oProperty.Name = "";
			oProperty.PracticeNumber = "";
			//we submitting the auditing data in order to create the application on CRM so that the business workspace is created and pulled to the UI.
			this._oODataModel.create("/EntityName", oProperty, {
				success: function(data) {
					//parameters have to be returned when creating application
					this.objId = data.guid; //GUID number
					this.sabObj = // BUS2000125 we got this object ID from the ECM team
						this.onAddWorkSpace(this.sabObj, this.objId);

					this._oODataModel.read("/EntityName(GUID)", {
						success: function(odata) {
							//returns the structure of the newly created application which will be used on update
							this.createdApp = odata;
						}.bind(this)
					});
				}.bind(this),
				error: function(t) {
						this.getView().setBusy(false);
						this.onErrorMessageBoxPress(t, "Submitted");
					}
					.bind(this)
			});
		},

		getRouter: function() {
			return this.getOwnerComponent().getRouter();
		},

		getObjectives: function(vProgType) {

			var oFilter = new Filter("ProgType", FilterOperator.EQ, vProgType);

			this._oODataModel.read("/GETObjectiveSet", {
				filters: [oFilter],
				success: function(oData) {
					var ObjectivesJsonModel = new sap.ui.model.json.JSONModel({
						results: oData.results
					});
					this.getView().setModel(ObjectivesJsonModel, "ObjectivesModel");
					sap.ui.core.BusyIndicator.hide();

				}.bind(this),
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured while retrieving Objectives");
				}.bind(this)
			});
		},

		getProgramType: function() {

			this._oODataModel.read("/ZdsdProgrammeTypeSet", {
				success: function(oData) {
					var ProgramJsonModel = new sap.ui.model.json.JSONModel({
						results: oData.results
					});
					this.getView().setModel(ProgramJsonModel, "ProgramTypeModel");
					this.getRegions();

				}.bind(this),
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured while retrieving Program Types");
				}.bind(this)
			});
		},

		getRegions: function() {

			this._oODataModel.read("/ZdsdRegionsSet", {
				success: function(oData) {
					var RegionsJsonModel = new sap.ui.model.json.JSONModel({
						results: oData.results
					});
					this.getView().setModel(RegionsJsonModel, "RegionsModel");
					sap.ui.core.BusyIndicator.hide();

				}.bind(this),
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured while retrieving Regions");
				}.bind(this)
			});
		},

		getMunicipality: function(vRegid) {
			var oFilter = new Filter("Regid", FilterOperator.EQ, vRegid);
			this._oODataModel.read("/ZdsdMunicipSet", {
				filters: [oFilter],
				success: function(oData) {
					var MunicipalJsonModel = new sap.ui.model.json.JSONModel({
						results: oData.results
					});
					this.getView().setModel(MunicipalJsonModel, "MunicipalModel");
					sap.ui.core.BusyIndicator.hide();

				}.bind(this),
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured while retrieving Municipalities");
				}.bind(this)
			});
		},

		getWards: function(vMunid) {
			var oFilter = new Filter("Municpid", FilterOperator.EQ, vMunid);
			this._oODataModel.read("/ZdsdWardsSet", {
				filters: [oFilter],
				success: function(oData) {
					var WardsJsonModel = new sap.ui.model.json.JSONModel({
						results: oData.results
					});
					this.getView().setModel(WardsJsonModel, "WardsModel");
					sap.ui.core.BusyIndicator.hide();

				}.bind(this),
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured while retrieving Municipalities");
				}.bind(this)
			});
		},

		onNpoNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("application");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onApplicationDeteailsPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("npo");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onApplicationDetailsNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("programme");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onProgramViabilityPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("application");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onProgramViabilityNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("achievements");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAchievementNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("challenges");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAchievementPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("programme");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onChallengesNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("capacity");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onChallengesPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("achievements");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCapacityNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("funding");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCapacityPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("challenges");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onFundingNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("cost");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onFundingPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("capacity");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCostNextPress: function() {
			
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("sustainability");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCostPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("funding");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSustanabilityNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("monitoring");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSustanabilityPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("cost");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onMonitoringNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("networks");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onMonitoringPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("sustainability");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onNetworksNextPress: function() {
			this.AttachmentTab = "X";

			if (this._ObjectId) {
				this.onAddWorkSpace(this._ObjectGuid);

			} else {

				//Validate key fields
				if (this.validateKeyFields() === true) {

					MessageBox.warning("Please save the application first before you attach document, Are you sure you want to save the application?", {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						emphasizedAction: MessageBox.Action.OK,
						onClose: function(sAction) {
							if (sAction === "OK") {
								this.getView().getModel().getData().data.Status = "";
								this.onSaveApplication();
								return;
							}
						}.bind(this)
					});
				}

			}
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("attachments");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onNetworksPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("monitoring");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAttachmentsNextPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("beneficiary");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAttachmentsPrevPress: function() {
			this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("particular");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSummary: function() {
			var oTableTarget = this.byId("targetTable");
			var oTableCapacity = this.byId("BoardCapacity");
			var oTableBeneficiary = this.byId("beneficiariesTable");

			this.byId("btnSubmit").setVisible(true);
			this.byId("IconBar").setSelectedKey("overview");
			this.byId("detailPage").scrollTo(0, 0);

			this.byId("AppTargetGroup1").setText(oTableTarget.getModel("TargetModel").getData().data.length);
			this.byId("AppNumberofBeneficiaries1").setText(oTableBeneficiary.getModel("BeneficiariesModel").getData().data.length);
			this.byId("AppCapacityofBoardStaff1").setText(oTableCapacity.getModel("CapacityModel").getData().data.length);
		},

		onUpdate: function() {
			sap.ui.core.BusyIndicator.show(0);
			this.UpdateInd = "X";
			var oProperties = this.getView().getModel().getData().data;
			oProperties.ObjectId = this._ObjectId;
			oProperties.Guid = this._ObjectGuid;
			oProperties.Description = this.byId("headerNPO").getModel().getData().data.But000.McName2;
			this._oODataModel.update("/GETApplicationFundingSet(BpNo='" + oProperties.BpNo + "',Guid='" + oProperties.Guid + "',ObjectId='" +
				oProperties.ObjectId + "')", oProperties, {

					success: function(results) {
						//sap.ui.core.BusyIndicator.hide();
						//this.successAndNavigate();
						
						this.onSubmitCapacity();

					}.bind(this),
					error: function(results) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error("Error occured when submiting Application");
					}

				});
		},

		onSaveApplication: function() {
			this.getView().getModel().getData().data.BpNo = this.byId("headerNPO").getModel().getData().data.BpNo;

			if (this._ObjectId) {
				this.onUpdate();
			} else {
				this._aContexts = [];
				var row = this.getView().getModel().getData().data;
				row.But000.Partner = this.BpNo;
				row.Description = this.byId("headerNPO").getModel().getData().data.But000.McName2;
				var oContext = this._oODataModel.createEntry("/GETApplicationFundingSet", {
					properties: row
				});
				this._aContexts.push(oContext);

				sap.ui.core.BusyIndicator.show(0);
				if (this._oODataModel.hasPendingChanges()) {
					this._oODataModel.submitChanges({
						success: function(oData) {
							this._oODataModel.resetChanges();

							if (oData.__batchResponses[0].__changeResponses[0].data.ObjectId === "") {
								sap.ui.core.BusyIndicator.hide();
								MessageBox.error("Error occured when creating an Application. Please try again later");
							} else {
								this._ObjectId = oData.__batchResponses[0].__changeResponses[0].data.ObjectId;
								this._ObjectGuid = oData.__batchResponses[0].__changeResponses[0].data.Guid;
								this.onSubmitCapacity();
							}

						}.bind(this),
						error: function(oError) {
							this._oODataModel.resetChanges();
							sap.ui.core.BusyIndicator.hide();
							MessageBox.error("Error occured when submiting Application");
						}.bind(this)
					});

				} else {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("No changes made to the Application");
				}

			}

		},

		onDraftApplication: function() {

			//Validate key fields
			if (this.validateKeyFields() === true) {
				//Assign Draft status
				this.getView().getModel().getData().data.Status = "";
				//Display Warning
				this.onWarningDraftApplication();
			}
		},

		onSubmitApplication: function() {

			//Validate key fields
			if (this.validateKeyFields() === true) {
				//Assign Draft status
				this.getView().getModel().getData().data.Status = "E0002";
				//Display Warning
				this.onWarningSubmitApplication();
			}
		},

		onSubmitCapacity: function() {

			var aItemsCapacity = [],
				aItemsOnceOff = [],
				aItemsCost = [];

			var oItemCapacity = {},
				oItemOnceOff = {},
				oItemCost = {};

			var i;

			var batchChanges = [],
				batchModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDSD_CRM_UI5_APP_SRV/");

			for (i = 0; i < this.CapacityModel.getData().data.length; i++) {
				oItemCapacity = this.CapacityModel.getData().data[i];
				oItemCapacity.ParentId = this._ObjectGuid;
				aItemsCapacity.push(oItemCapacity);
			}

			for (i = 0; i < this.TargetGroupModel.getData().data.length; i++) {
				oItemCapacity = this.TargetGroupModel.getData().data[i];
				oItemCapacity.ParentId = this._ObjectGuid;
				aItemsCapacity.push(oItemCapacity);
			}

			for (i = 0; i < this.BeneficiariesModel.getData().data.length; i++) {
				oItemCapacity = this.BeneficiariesModel.getData().data[i];
				oItemCapacity.ParentId = this._ObjectGuid;
				aItemsCapacity.push(oItemCapacity);
			}

			for (i = 0; i < this.CostImplicationsModel.getData().data.length; i++) {
				oItemOnceOff = this.CostImplicationsModel.getData().data[i];
				oItemOnceOff.ParentId = this._ObjectGuid;
				aItemsOnceOff.push(oItemOnceOff);
			}

			for (i = 0; i < this.OnceOffModel.getData().data.length; i++) {
				oItemCost = this.OnceOffModel.getData().data[i];
				oItemCost.ParentId = this._ObjectGuid;
				aItemsCost.push(oItemCost);
			}

			if (aItemsCapacity.length > 0) {
				for (i = 0; i < aItemsCapacity.length; i++) {
					batchChanges.push(batchModel.createBatchOperation("/GetCapacitySet", "POST", aItemsCapacity[i]));
				}
			}

			if (aItemsOnceOff.length > 0) {
				for (i = 0; i < aItemsOnceOff.length; i++) {
					batchChanges.push(batchModel.createBatchOperation("/GetOnceOffCostSet", "POST", aItemsOnceOff[i]));
				}
			}

			if (aItemsCost.length > 0) {
				for (i = 0; i < aItemsCost.length; i++) {
					batchChanges.push(batchModel.createBatchOperation("/GetCostSet", "POST", aItemsCost[i]));
				}
			}

			if (batchChanges.length > 0) {

				batchModel.addBatchChangeOperations(batchChanges);
				batchModel.setUseBatch(true);

				sap.ui.core.BusyIndicator.show();
				//submit Batch and refresh the table
				batchModel.submitBatch(function(data) {
					var parser = new DOMParser(),
						xmlDoc;

					sap.ui.core.BusyIndicator.hide();

					if (data.__batchResponses[0].__changeResponses[0].statusCode.startsWith('2')) {

						this.successAndNavigate();

					} else {

						// xmlDoc = parser.parseFromString(data.__batchResponses[0].response.body, "text/xml");
						// MessageBox.error(xmlDoc.documentElement.children[1].innerHTML);
						// sap.ui.core.BusyIndicator.hide();

						// xmlDoc = parser.parseFromString(data.__batchResponses[0].response.body, "text/xml");
						MessageBox.error("Error occured when submiting Application");

					}

					batchModel.resetChanges();
					batchModel.refresh();
				}.bind(this), function(err) {
					//MessageBox.error("Connection error. Check if you're connected.");
					sap.ui.core.BusyIndicator.hide();
				});
			} else {
				sap.ui.core.BusyIndicator.hide();
				this.successAndNavigate();
			}

		},

		handleIconTabBarSelect: function(oEvent) {
			var sKey = oEvent.getParameter("key");

			// if (sKey === "attachments") {
			// 	this.onNetworksNextPress();
			// } else {
			// 	this.byId("btnSubmit").setVisible(false);
			// }

			switch (sKey) {
				case "attachments":
					this.onNetworksNextPress();
					break;
				case "overview":
					this.onSummary();
					break;
				default:
					this.byId("btnSubmit").setVisible(false);
			}

		},

		onValueHelpRequest: function(oEvent) {

			var sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();
			this.byId("Objective").setValue();

			if (this.byId("ProgrammeType").getValue().trim() !== "") {
				if (!this._pValueHelpDialog) {
					this._pValueHelpDialog = Fragment.load({
						id: oView.getId(),
						name: "gdsd.FundingApplication.view.fragments.Objectives",
						controller: this
					}).then(function(oDialog) {
						oView.addDependent(oDialog);
						return oDialog;
					});
				}
				this._pValueHelpDialog.then(function(oDialog) {
					// Create a filter for the binding
					oDialog.getBinding("items").filter([new Filter("ExternalId", FilterOperator.Contains, sInputValue)]);
					// Open ValueHelpDialog filtered by the input's value
					oDialog.open(sInputValue);
				});
			} else {
				this.byId("Objective").setValue();
				MessageBox.error("Please select program type first");
			}
		},

		onValueHelpRequestProgType: function(oEvent) {

			var sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();
			this.byId("ProgrammeType").setValue();

			if (!this._pValueHelpDialogProgType) {
				this._pValueHelpDialogProgType = Fragment.load({
					id: oView.getId(),
					name: "gdsd.FundingApplication.view.fragments.ProgramTypes",
					controller: this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					return oDialog;
				});
			}
			this._pValueHelpDialogProgType.then(function(oDialog) {
				// Create a filter for the binding
				oDialog.getBinding("items").filter([new Filter("PrtypText", FilterOperator.Contains, sInputValue)]);
				// Open ValueHelpDialog filtered by the input's value
				oDialog.open(sInputValue);
			});
		},

		onValueHelpRequestRegion: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();

			this.byId("Region").setValue();
			if (!this._pValueHelpDialogRegions) {
				this._pValueHelpDialogRegions = Fragment.load({
					id: oView.getId(),
					name: "gdsd.FundingApplication.view.fragments.Regions",
					controller: this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					return oDialog;
				});
			}
			this._pValueHelpDialogRegions.then(function(oDialog) {
				// Create a filter for the binding
				oDialog.getBinding("items").filter([new Filter("Regname", FilterOperator.Contains, sInputValue)]);
				// Open ValueHelpDialog filtered by the input's value
				oDialog.open(sInputValue);
			});
		},

		onValueHelpRequestMunicipal: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();

			this.byId("Municipality").setValue();
			if (this.byId("Region").getValue().trim() !== "") {
				if (!this._pValueHelpDialogMunicpal) {
					this._pValueHelpDialogMunicpal = Fragment.load({
						id: oView.getId(),
						name: "gdsd.FundingApplication.view.fragments.Municipalities",
						controller: this
					}).then(function(oDialog) {
						oView.addDependent(oDialog);
						return oDialog;
					});
				}
				this._pValueHelpDialogMunicpal.then(function(oDialog) {
					// Create a filter for the binding
					oDialog.getBinding("items").filter([new Filter("Municipname", FilterOperator.Contains, sInputValue)]);
					// Open ValueHelpDialog filtered by the input's value
					oDialog.open(sInputValue);
				});
			} else {
				MessageBox.error("Please select a region first");
			}
		},

		onValueHelpRequestWards: function(oEvent) {
			var sInputValue = oEvent.getSource().getValue(),
				oView = this.getView();

			this.byId("Ward").setValue();
			if (this.byId("Municipality").getValue().trim() !== "") {

				if (!this._pValueHelpDialogWards) {
					this._pValueHelpDialogWards = Fragment.load({
						id: oView.getId(),
						name: "gdsd.FundingApplication.view.fragments.Wards",
						controller: this
					}).then(function(oDialog) {
						oView.addDependent(oDialog);
						return oDialog;
					});
				}
				this._pValueHelpDialogWards.then(function(oDialog) {
					// Create a filter for the binding
					oDialog.getBinding("items").filter([new Filter("Wardname", FilterOperator.Contains, sInputValue)]);
					// Open ValueHelpDialog filtered by the input's value
					oDialog.open(sInputValue);
				});
			} else {
				MessageBox.error("Please select a municipality first");
			}
		},

		onValueHelpSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("ExternalId", FilterOperator.Contains, sValue);

			oEvent.getSource().getBinding("items").filter([oFilter]);
		},

		onValueHelpSearchProgType: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("PrtypText", FilterOperator.Contains, sValue);

			oEvent.getSource().getBinding("items").filter([oFilter]);
		},

		onValueHelpSearchRegion: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Regname", FilterOperator.Contains, sValue);

			oEvent.getSource().getBinding("items").filter([oFilter]);
		},

		onValueHelpSearchMunicipal: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Municipname", FilterOperator.Contains, sValue);

			oEvent.getSource().getBinding("items").filter([oFilter]);
		},

		onValueHelpSearchWards: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("Wardname", FilterOperator.Contains, sValue);

			oEvent.getSource().getBinding("items").filter([oFilter]);
		},

		onValueHelpClose: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			//oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}

			this.byId("Objective").setValue(oSelectedItem.getDescription());
			this.byId("Objective").setDescription(oSelectedItem.getTitle());
		},

		onValueHelpCloseProgType: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}

			this.byId("ProgrammeType").setValue(oSelectedItem.getTitle());
			this.byId("ProgrammeType").setDescription(oSelectedItem.getDescription());

			this.byId("Objective").setValue();
			this.byId("Objective").setDescription();

			this.getObjectives(this.byId("ProgrammeType").getValue());
		},

		onValueHelpCloseRegion: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}

			this.byId("Region").setValue(oSelectedItem.getTitle());
			this.byId("Region").setDescription(oSelectedItem.getDescription());

			this.byId("Municipality").setValue();
			this.byId("Municipality").setDescription();
			this.byId("Ward").setValue();
			this.byId("Ward").setDescription();

			this.getMunicipality(this.byId("Region").getValue());
		},

		onValueHelpCloseMunicipal: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}

			this.byId("Municipality").setValue(oSelectedItem.getTitle());
			this.byId("Municipality").setDescription(oSelectedItem.getDescription());

			this.byId("Ward").setValue();
			this.byId("Ward").setDescription();

			this.getWards(this.byId("Municipality").getValue());
		},

		onValueHelpCloseWards: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}

			this.byId("Ward").setValue(oSelectedItem.getTitle());
			this.byId("Ward").setDescription(oSelectedItem.getDescription());

		},

		onAddBeneficiariesPressed: function() {
			this.createFormDialog("gdsd.FundingApplication.view.fragments.Beneficiariers").open();
		},
		onAddStaffCapacity: function() {
			this.createFormDialog("gdsd.FundingApplication.Fragments.CapacityofStaff").open();
		},

		onAddBoardCapacity: function() {
			this.createFormDialog("gdsd.FundingApplication.view.fragments.Capacity").open();
		},
		onAddTargetPressed: function() {
			this.createFormDialog("gdsd.FundingApplication.view.fragments.TargetGroup").open();
		},

		onAddAssetPressed: function() {
			this.createFormDialog("gdsd.FundingApplication.view.fragments.AddAsset").open();
		},
		onAddFinancialCostImplications: function () {
			this.createFormDialog("gdsd.FundingApplication.view.fragments.FinancialCosts").open();
		},

		createFormDialog: function(sDialogFragmentName) {

			// https://stackoverflow.com/questions/55667673/how-to-remove-duplicates-and-display-only-unique-values-in-viewsettingsitem
			var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
				this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;

				if (Device.system.desktop) {
					oDialog.addStyleClass("sapUiSizeCompact");
				}
			}
			return oDialog;
		},

		onCancel: function() {
			//Cater for the age group selected 
			var oDialogKey,
				oDialogValue;

			for (oDialogKey in this._mViewSettingsDialogs) {
				oDialogValue = this._mViewSettingsDialogs[oDialogKey];

				if (oDialogValue) {
					oDialogValue.close();
					// oDialogValue = null;
				}
			}
		},

		onSaveBeneficiaries: function(oEvent) {
			var oTable = this.byId("beneficiariesTable");

			if (sap.ui.getCore().byId("bgender").getSelectedItem() === null || sap.ui.getCore().byId("brace").getSelectedItem() === null) {
				MessageBox.error("Please make sure gender and race are selected");
			} else {
				this.BeneficiariesModel.getData().data.push({
					"ParentId": "",
					"Zztype": "BENEF",
					"Zzafld000007": sap.ui.getCore().byId("bname").getValue(),
					"Zzafld000008": sap.ui.getCore().byId("bcontact").getValue(),
					"Zzafld000009": sap.ui.getCore().byId("bidnumber").getValue(),
					"Zzafld00000a": sap.ui.getCore().byId("bgender").getSelectedItem().getKey(),
					"Zzafld00000b": sap.ui.getCore().byId("brace").getSelectedItem().getKey(),
					"Zzafld00000c": sap.ui.getCore().byId("bdisabilitynature").getValue(),
					"Zzafld00000d": sap.ui.getCore().byId("bposition").getValue(),
					"Zzafld000087": sap.ui.getCore().byId("bdisability").getValue()
				});

				oTable.setModel();

				oTable.setModel(this.BeneficiariesModel, "BeneficiariesModel");
				oTable.getModel("BeneficiariesModel").refresh(true);

				this.byId("countBeneficiaries").setText("Beneficiaries (" + this.BeneficiariesModel.getData().data.length + ")");

				sap.ui.getCore().byId("bname").setValue();
				sap.ui.getCore().byId("bidnumber").setValue();
				sap.ui.getCore().byId("bgender").setValue();
				sap.ui.getCore().byId("brace").setValue();
				sap.ui.getCore().byId("bcontact").setValue();
				sap.ui.getCore().byId("bposition").setValue();
				sap.ui.getCore().byId("bdisabilitynature").setValue();
				sap.ui.getCore().byId("bdisability").setValue();
				this.onCancel();
			}
		},

		onSaveTarget: function(oEvent) {
			var oTable = this.byId("targetTable");

			if (sap.ui.getCore().byId("tgender").getSelectedItem() === null || sap.ui.getCore().byId("trace").getSelectedItem() === null) {
				MessageBox.error("Please make sure gender and race are selected");
			} else {
				this.TargetGroupModel.getData().data.push({
					"ParentId": "",
					"Zztype": "TARG",
					"Zzafld000007": sap.ui.getCore().byId("tname").getValue(),
					"Zzafld000008": sap.ui.getCore().byId("tcontact").getValue(),
					"Zzafld000009": sap.ui.getCore().byId("tidnumber").getValue(),
					"Zzafld00000a": sap.ui.getCore().byId("tgender").getSelectedItem().getKey(),
					"Zzafld00000b": sap.ui.getCore().byId("trace").getSelectedItem().getText(),
					"Zzafld00000c": sap.ui.getCore().byId("tdisabilitynature").getValue(),
					"Zzafld00000d": sap.ui.getCore().byId("tposition").getValue(),
					"Zzafld000087": sap.ui.getCore().byId("tdisability").getValue()
				});

				oTable.setModel();

				oTable.setModel(this.TargetGroupModel, "TargetModel");
				oTable.getModel("TargetModel").refresh(true);

				this.byId("countTarget").setText("Target Group (" + this.TargetGroupModel.getData().data.length + ")");

				sap.ui.getCore().byId("tname").setValue();
				sap.ui.getCore().byId("tidnumber").setValue();
				sap.ui.getCore().byId("tgender").setValue();
				sap.ui.getCore().byId("trace").setValue();
				sap.ui.getCore().byId("tcontact").setValue();
				sap.ui.getCore().byId("tposition").setValue();
				sap.ui.getCore().byId("tdisabilitynature").setValue();
				sap.ui.getCore().byId("tdisability").setValue();
				this.onCancel();
			}
		},

		onSaveBoardCapacity: function(oEvent) {
			var oTable = this.byId("BoardCapacity");

			if (sap.ui.getCore().byId("cgender").getSelectedItem() === null || sap.ui.getCore().byId("crace").getSelectedItem() === null) {
				MessageBox.error("Please make sure gender and race are selected");
			} else {
				this.CapacityModel.getData().data.push({
					"ParentId": "",
					"Zztype": sap.ui.getCore().byId("ctype").getSelectedItem().getText(),
					"Zzafld000007": sap.ui.getCore().byId("cname").getValue(),
					"Zzafld000008": sap.ui.getCore().byId("ccontact").getValue(),
					"Zzafld000009": sap.ui.getCore().byId("cidnumber").getValue(),
					"Zzafld00000a": sap.ui.getCore().byId("cgender").getSelectedItem().getKey(),
					"Zzafld00000b": sap.ui.getCore().byId("crace").getSelectedItem().getKey(),
					"Zzafld00000c": sap.ui.getCore().byId("cdisabilitynature").getValue(),
					"Zzafld00000d": sap.ui.getCore().byId("cposition").getValue(),
					"Zzafld000087": sap.ui.getCore().byId("cdisability").getSelectedItem().getKey()

				});

				//Refresh model
				//var oTable = this.byId("capacity");
				oTable.setModel();

				oTable.setModel(this.CapacityModel, "CapacityModel");
				oTable.getModel("CapacityModel").refresh(true);

				this.byId("countCapacity").setText("Capacity of Board/Staff (" + this.CapacityModel.getData().data.length + ")");

				sap.ui.getCore().byId("ctype").setValue();
				sap.ui.getCore().byId("cname").setValue();
				sap.ui.getCore().byId("cidnumber").setValue();
				sap.ui.getCore().byId("cgender").setValue();
				sap.ui.getCore().byId("crace").setValue();
				sap.ui.getCore().byId("ccontact").setValue();
				sap.ui.getCore().byId("cposition").setValue();
				sap.ui.getCore().byId("cdisabilitynature").setValue();
				sap.ui.getCore().byId("cdisability").setValue();

				this.onCancel();
			}
		},

		onSaveAsset: function() {
			var oTable = this.byId("OnceOffCostsTable");

			if (sap.ui.getCore().byId("Product").getValue() === "" || sap.ui.getCore().byId("ExistPrice").getValue() === "" || sap.ui.getCore()
				.byId("PropPrice").getValue() === "") {
				MessageBox.error("Please input all the required values");
			} else {
				this.OnceOffModel.getData().data.push({
					"ObjectId": "",
					"ParentId": "",
					"RecordId": "",
					"Zzafld00009v": sap.ui.getCore().byId("Product").getValue(),
					"Zzafld00009w": sap.ui.getCore().byId("ExistPrice").getValue(),
					"Zzafld00009y": sap.ui.getCore().byId("PropPrice").getValue()
				});

				//Refresh model
				//var oTable = this.byId("capacity");
				oTable.setModel();

				oTable.setModel(this.OnceOffModel, "OnceOffModel");
				oTable.getModel("OnceOffModel").refresh(true);

				sap.ui.getCore().byId("Product").setValue();
				sap.ui.getCore().byId("ExistPrice").setValue();
				sap.ui.getCore().byId("PropPrice").setValue();
				this.onCancel();
			}
		},

		onPressBeneficiary: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogBeneficiary = this.createFormDialog("gdsd.FundingApplication.view.fragments.UpdateBeneficiariers");

			this._DialogBeneficiary.setModel(this.BeneficiariesModel);
			this._DialogBeneficiary.bindElement(oBindingContextPath);

			this._DialogBeneficiary.open();

		},

		onPressTarget: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogTarget = this.createFormDialog("gdsd.FundingApplication.view.fragments.UpdateTargetGroup");

			this._DialogTarget.setModel(this.TargetGroupModel);
			this._DialogTarget.bindElement(oBindingContextPath);

			this._DialogTarget.open();

		},

		onPressCapacity: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogTarget = this.createFormDialog("gdsd.FundingApplication.view.fragments.UpdateCapacity");

			this._DialogTarget.setModel(this.CapacityModel);
			this._DialogTarget.bindElement(oBindingContextPath);

			this._DialogTarget.open();

		},
		
		onPressCostImplication: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogCostImp = this.createFormDialog("gdsd.FundingApplication.view.fragments.UpdateFinancialCosts");

			this._DialogCostImp.setModel(this.CostImplicationsModel);
			this._DialogCostImp.bindElement(oBindingContextPath);

			this._DialogCostImp.open();

		},

		successAndNavigate: function(oEvent) {
			var textMsg;

			if (this.getView().getModel().getData().data.Status === "") {
				textMsg = "Draft Application for " + this._ObjectId + " saved successfully";
				this.byId("headerNPO").setTitle("Application: " + this._ObjectId);
			} else if (this.getView().getModel().getData().data.Status === "E0002") {
				textMsg = "Application " + this._ObjectId + " created successfully";
			}
			if (this.UpdateInd) {
				textMsg = "Application " + this._ObjectId + " has been successfully submitted";
				this.UpdateInd = "";
			}

			MessageBox.success(textMsg, {
				icon: sap.m.MessageBox.Icon.CONFIRMATION,
				title: "Confirmation",
				actions: [sap.m.MessageBox.Action.OK],
				onClose: function(oAction) {
					if (oAction === "OK") {
						if (this.AttachmentTab) {
							this.onAddWorkSpace(this._ObjectGuid);
							this.byId("Objective").setEnabled(false);
							//							this.byId("Region").setEnabled(false);
							this.byId("pickerImplStart").setEnabled(false);
							this.byId("pickerImplEnd").setEnabled(false);
						} else {
							this.byId("Objective").setValue();
							//							this.byId("Region").setSelectedKey();
							//							this.byId("Region").setSelectedItem();
							this.Router.navTo("ListOfApplications");
							location.reload();
							return;
						}
					}
				}.bind(this)
			});
		},

		validateKeyFields: function(oEvent) {
			if (this.byId("ProgrammeType").getValue() === "" || this.byId("ProgrammeType").getValue() === undefined) {
				MessageBox.error("Please select program type in application details tab");
				return false;
			}
			if (this.byId("Objective").getValue() === "" || this.byId("Objective").getValue() === undefined) {
				MessageBox.error("Please select program ID in application details tab");
				return false;
			}
			if (this.byId("Region").getSelectedKey() === "" || this.byId("Region").getSelectedKey() === undefined) {
				//				MessageBox.error("Please select region in application details tab");
				//				return false;
			}
			// else if (this.byId("pickerPeriodStart").getValue() === "" || this.byId("pickerPeriodEnd").getValue() === "") {
			// 	MessageBox.error("Please select period start and end date in application details tab");
			// 	return false;
			// }
			if (this.byId("pickerImplStart").getValue() === "" || this.byId("pickerImplEnd").getValue() === "") {
				MessageBox.error("Please select period of implementation start and end date in application details tab");
				return false;
			}
			if (this.byId("idAppType").getSelectedKey() === "" || this.byId("idAppType").getSelectedKey() === undefined) {
				MessageBox.error("Please select type of application in application details tab");
				return false;
			}
			if (this.byId("idPeriodOperation").getSelectedKey() === "" || this.byId("idPeriodOperation").getSelectedKey() === undefined) {
				MessageBox.error("Please select period of operation in application details tab");
				return false;
			}
			if (this.byId("Region").getValue() === "" || this.byId("Region").getValue() === undefined) {
				MessageBox.error("Please select region in application details tab");
				return false;
			}
			if (this.byId("Municipality").getValue() === "" || this.byId("Municipality").getValue() === undefined) {
				MessageBox.error("Please select municipality in application details tab");
				return false;
			}
			if (this.byId("Ward").getValue() === "" || this.byId("Ward").getValue() === undefined) {
				MessageBox.error("Please select ward in application details tab");
				return false;
			}

			return true;
		},

		onWarningSubmitApplication: function() {
			MessageBox.warning("The Application will be submitted for processing. Do you want to continue", {
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function(sAction) {
					if (sAction === "OK") {
						// Save Application
						this.onSaveApplication();
						return;
					}
				}.bind(this)
			});
		},

		onWarningDraftApplication: function() {
			MessageBox.warning("The Application will be save as a draft and you can retrieve it later. Do you want to continue", {
				actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
				emphasizedAction: MessageBox.Action.OK,
				onClose: function(sAction) {
					if (sAction === "OK") {
						// Save Application
						this.onSaveApplication();
						return;
					}
				}.bind(this)
			});
		},

		onChangeStartDate: function() {

			if (this.byId("pickerPeriodStart").getValue() !== "") {
				var date = this.byId("pickerPeriodStart").getDateValue().getDate();
				var month = this.byId("pickerPeriodStart").getDateValue().getMonth();
				var year = this.byId("pickerPeriodStart").getDateValue().getFullYear();

				this.byId("pickerPeriodEnd").setMinDate(new Date(year, month, date));
			}
		},

		onChangeStartDateImpl: function() {

			if (this.byId("pickerImplStart").getValue() !== "") {
				var date = this.byId("pickerImplStart").getDateValue().getDate();
				var month = this.byId("pickerImplStart").getDateValue().getMonth();
				var year = this.byId("pickerImplStart").getDateValue().getFullYear();

				this.byId("pickerImplEnd").setMinDate(new Date(year, month, date));
			}
		},

		clearControls: function() {
			this.byId("Objective").setValue("");
			this.byId("motivation").setValue("");
			//this.byId("idPeriodOperation").setValue("");
			//this.byId("Region")
			this.byId("ProgramAlign").setValue("");
			this.byId("ProgramDesign").setValue("");
			this.byId("ProgramType").setValue("");
			this.byId("Achivements").setValue("");
			this.byId("Impact").setValue("");
			this.byId("Mitigation").setValue("");
			this.byId("Achievemnt2").setValue("");
			this.byId("NPORequire").setValue("");
			this.byId("NPOPractical").setValue("");
			this.byId("Shortcoming").setValue("");
			this.byId("Board").setValue("");
			this.byId("BoardElect").setValue("");
			this.byId("OrganisationRequire").setValue("");
			this.byId("HumanResource").setValue("");
			this.byId("idProgram").setValue("");
			this.byId("ApplicationOnce").setValue("");
			this.byId("PersonnelCost").setValue("0");
			this.byId("ProjectCost").setValue("0");
			this.byId("CapitalCost").setValue("0");
			this.byId("AdminCost").setValue("0");
			this.byId("OtherCost").setValue("0");
			this.byId("TotalCost").setValue("0");
			this.byId("OtherSource").setValue("0");
			this.byId("InternalControl").setValue("");
			this.byId("Efficient").setValue("");
			this.byId("NamePerson").setValue("");
			this.byId("NameFirm").setValue("");
			this.byId("NPOTrack").setValue("");
			this.byId("Similar").setValue("");
			this.byId("OtherService").setValue("");
		},
		handleChangeCostImpType: function(oEvent) {
			var ValueState = coreLibrary.ValueState;
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
			//	MessageBox.error("Please select a Cost Implication Type");
				this.byId("typeCostImplications").setValue("");
			}else {
				oValidatedComboBox.setValueState(ValueState.None);
			}
		},
		handleChangePersonnelType: function(oEvent) {
			var ValueState = coreLibrary.ValueState;
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
			//	MessageBox.error("Please select Personnel Type");
				this.byId("personnelType").setValue("");
			} else {
				oValidatedComboBox.setValueState(ValueState.None);
			}
		},

		handleChangeAppType: function(oEvent) {
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				MessageBox.error("Please select application Type");
				this.byId("idAppType").setValue("");
			}
		},

		handleChangePeriod: function(oEvent) {
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				MessageBox.error("Please select period of operation");
				this.byId("idPeriodOperation").setValue("");
			}
		},

		handleChangeRegion: function(oEvent) {
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				MessageBox.error("Please select region");
				this.byId("Region").setValue("");
			}
		},

		onPressNavButton: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("NPOApplication", true);
			location.reload();
		},

		onDeleteTargetPressed: function(oEvent) {
			//Delete Row

			//Delete Row 
			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("TargetModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("TargetModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this.TargetGroupModel.refresh();

			//				alert("Entry Successfully Deleted");
		},

		onDeleteBeneficiariesPressed: function(oEvent) {

			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("BeneficiariesModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("BeneficiariesModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this.BeneficiariesModel.refresh();

			//				alert("Entry Successfully Deleted");
		},

		onDeleteCapacity: function(oEvent) {

			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("CapacityModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("CapacityModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this.CapacityModel.refresh();

			//				alert("Entry Successfully Deleted");
		},

		onDeleteAssetPressed: function(oEvent) {
			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("OnceOffModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("OnceOffModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this.OnceOffModel.refresh();
		},
		
		onDeleteCostImplicationPressed: function(oEvent) {

			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("CostImplicationsModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("CostImplicationsModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this.CostImplicationsModel.refresh();
		},

		searchObjective: function(oEvent) {
			this.onValueHelpRequest(oEvent);
		},

	onUpdateFCIBNEFICIARIES: function(oEvent) {
			var oSource = oEvent.getSource();
			var sValue;

			sValue = oSource.getValue();

			if (sValue.length <= 6) {
				this.ValueFCIBenef = sValue;
				sap.ui.getCore().byId("totalNumBeneficiaries").setValue(sValue);
			} else {
				sap.ui.getCore().byId("totalNumBeneficiaries").setValue(this.ValueFCIBenef);
				MessageBox.error("Maximum Digits Exceeded");
			}
		},


		onFloatCheck: function(oEvent) {

			var sValue = oEvent.getSource().getValue();
			var regexp = /^[0-9]*(\.[0-9]{0,2})?$/;
			var bFlag = regexp.test(sValue);
			if (!bFlag) {
				oEvent.getSource().setValueState("Error");
				oEvent.getSource().setValueStateText("Please enter a decimal value of 2");
			} else {
				oEvent.getSource().setValueState("None");
				oEvent.getSource().setValueStateText("");
			}

		},

		onUpdateExistingPriceChange: function(oEvent) {
			var oSource = oEvent.getSource();
			var sValue;

			sValue = oSource.getValue();

			if (sValue.length <= 14) {
				this.ValueExistPrice = sValue;
				sap.ui.getCore().byId("ExistPrice").setValue(sValue);
			} else {
				sap.ui.getCore().byId("ExistPrice").setValue(this.ValueExistPrice);
				MessageBox.error("Exceeded the limit");
			}
		},

		onUpdateProposedPriceChange: function(oEvent) {
			var oSource = oEvent.getSource();
			var sValue;

			sValue = oSource.getValue();

			if (sValue.length <= 14) {
				this.ValuePropPrice = sValue;
				sap.ui.getCore().byId("PropPrice").setValue(sValue);
			} else {
				sap.ui.getCore().byId("PropPrice").setValue(this.ValuePropPrice);
				MessageBox.error("Exceeded the limit");
			}
		},

		onPressAsset: function(oEvent) {
			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogAsset = this.createFormDialog("gdsd.FundingApplication.view.fragments.UpdateAsset");

			this._DialogAsset.setModel(this.OnceOffModel);
			this._DialogAsset.bindElement(oBindingContextPath);

			this._DialogAsset.open();

		},
		
		onSaveCostImplications: function() {

			var ttlNumBenef = sap.ui.getCore().byId("totalNumBeneficiaries").getValue();
			var SubRate = sap.ui.getCore().byId("monthlySubrate").getValue();
			var TotalCosts = sap.ui.getCore().byId("budgetCosts").getValue();
			var oTable = this.byId("tableCostImplications");
			TotalCosts = 0;

			if (this.validateCostType() === true) {
               MessageBox.error("This cost type already exist");
			} else {

				if (ttlNumBenef !== "" && SubRate !== "") {
					TotalCosts = (parseFloat(ttlNumBenef) * parseFloat(SubRate));

					sap.ui.getCore().byId("budgetCosts").setValue(TotalCosts);
				}

				if (sap.ui.getCore().byId("typeCostImplications").getSelectedItem() === null || sap.ui.getCore().byId("totalNumBeneficiaries").getValue() ===
					"" || sap.ui.getCore()
					.byId("monthlySubrate").getValue() === "" || sap.ui.getCore().byId("personnelType").getSelectedItem() === null) {
					MessageBox.error("Please input all the required values");
				} else {
					this.CostImplicationsModel.getData().data.push({
						"ObjectId": "",
						"ParentId": "",
						"RecordId": "",
						"Zzafld0000a1": sap.ui.getCore().byId("totalNumBeneficiaries").getValue(),
						"Zzafld0000ae": sap.ui.getCore().byId("typeCostImplications").getSelectedItem().getKey(),
						"Zzafld0000a3": sap.ui.getCore().byId("monthlySubrate").getValue(),
						"Zzafld0000a5": sap.ui.getCore().byId("personnelType").getSelectedItem().getKey(),
						"Zzafld0000a6": sap.ui.getCore().byId("budgetCosts").getValue()
					});

					//Refresh model
					//var oTable = this.byId("capacity");
					oTable.setModel();

					oTable.setModel(this.CostImplicationsModel, "CostImplicationsModel");
					oTable.getModel("CostImplicationsModel").refresh(true);

					sap.ui.getCore().byId("totalNumBeneficiaries").setValue();
					sap.ui.getCore().byId("typeCostImplications").setValue();
					sap.ui.getCore().byId("monthlySubrate").setValue();
					sap.ui.getCore().byId("personnelType").setValue();
					sap.ui.getCore().byId("budgetCosts").setValue();
					this.onCancel();
				}
			}
		},

		validateCostType: function() {

			for (var i = 0; i < this.CostImplicationsModel.getData().data.length; i++) {
				if (this.CostImplicationsModel.getData().data[i].Zzafld0000ae === sap.ui.getCore().byId("typeCostImplications").getSelectedItem().getKey()) {
					return true;
				}
			}
			return false;
		}

	});
});