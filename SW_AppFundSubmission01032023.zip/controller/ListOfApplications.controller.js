sap.ui.define([
	"./BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/Device"
], function (BaseController, Filter, FilterOperator, MessageBox, Device) {
	"use strict";

	return BaseController.extend("gdsd.FundingApplication.controller.ListOfApplications", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.FundingApplication.view.ListOfApplications
		 */
		onInit: function () {

			//get the odata model from the component
			this._oODataModel = this.getOwnerComponent().getModel();
			this._ApplicationModel = this.getOwnerComponent().getModel("Applications");
			this._mViewSettingsDialogs = {};
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this.Router.getRoute("ListOfApplications").attachPatternMatched(this._onObjectMatched, this);
			
			$.ajax({
				type: "GET",
				async: false,
				url: "https://cnbscsapfm01.gpsap.gpg.gov.za:3443/sap/bc/ui2/start_up",
				success: function (data, textStatus, jqXHR) {
					if (data === null || data.fullName === "") {
						var userName = "User";
					} else {
						var userName = data.id;
						//that.userName1 = data.id;
					}
				},
				error: function (error) {
					// var bundle = sap.ui.getCore().getModel(“i18n”).getResourceBundle();
					// jQuery.sap.require(“sap.m.MessageBox”);
					// com.bnsf.eam.tne.util.ServiceErrorHandler.handleODataError(error, bundle.getText(“tne.dashMsg.msg.oDataDashFailureMessages”),
					// 	bundle.getText(“tne.dashMsg.msg.MessageScreenErrorNumber”));
				}
			});

		},

		_onObjectMatched: function () {
			//Get Application Data
			this.getAllApplications();
		},

		getAllApplications: function () {

			sap.ui.core.BusyIndicator.show(0);

			this._oODataModel.read("/GETApplicationFundingSet", {
				success: function (odata) {
					if (odata.results[0]) {
						var ApplicationHeaderJsonModel = new sap.ui.model.json.JSONModel({
							data: odata.results[0]
						});

						//this.byId("detailPage").setTitle(odata.results[0].But000.McName1);
					}

					this._ApplicationModel.getData().data = odata.results;
					// var ApplicationsJsonModel = new sap.ui.model.json.JSONModel({
					// 		data: odata.results
					// 	});

					this.byId("headerNPO").setModel(ApplicationHeaderJsonModel);
					this.byId("headerNPO").bindElement({
						path: "/data"
					});

					this.getView().setModel(this._ApplicationModel);
					sap.ui.core.BusyIndicator.hide();

				}.bind(this),
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve application details");
				}.bind(this)
			});

		},

		onCreate: function () {
			this.Router.navTo("NewApplication");
		},

		onNewApplication: function () {
			//this.createFormDialog("gdsd.FundingApplication.view.fragments.SearchBP").open();
			this.Router.navTo("NPOApplication");
		},

		onItemPress: function (oEvent) {
			var oItem = oEvent.getSource();
			//this.Router.navTo("TaskDetail");
			this.Router.navTo("ExistingApplication", {
				ApplicationPath: window.encodeURIComponent(oItem.getBindingContext().getPath().substr(1))
			});
		},

		onSearch: function (oEvent) {
			// add filter for search
			//var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var contains = sap.ui.model.FilterOperator.Contains;
				var aFilters = new Filter([
						new sap.ui.model.Filter("ObjectId", contains, sQuery)
					],
					false);
			}
			// update list binding
			var oList = this.byId("ApplicationList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		createFormDialog: function (sDialogFragmentName) {

			// https://stackoverflow.com/questions/55667673/how-to-remove-duplicates-and-display-only-unique-values-in-viewsettingsitem
			var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
				this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;

				if (Device.system.desktop) {
					oDialog.addStyleClass("sapUiSizeCompact");
				}
			}
			return oDialog;
		},

		onCancel: function () {
			var oDialogKey,
				oDialogValue;

			for (oDialogKey in this._mViewSettingsDialogs) {
				oDialogValue = this._mViewSettingsDialogs[oDialogKey];

				if (oDialogValue) {
					oDialogValue.close();
					// oDialogValue = null;
				}
			}
		}

		/*	onCreate: function () {
				//Cater for the age group selected 
				var oDialogKey,
					oDialogValue;

				for (oDialogKey in this._mViewSettingsDialogs) {
					oDialogValue = this._mViewSettingsDialogs[oDialogKey];

					if (oDialogValue) {
						oDialogValue.close();
						// oDialogValue = null;
					}
				}
			}*/

	});

});