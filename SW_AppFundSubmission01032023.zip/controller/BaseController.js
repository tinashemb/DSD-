sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/core/routing/History"], function(e, t) {
	"use strict";
	return e.extend("com.sanbs.SANBS_GoodsIssue.controller.BaseController", {
		getRouter: function() {
			return this.getOwnerComponent().getRouter();
		},
		getModel: function(e) {
			return this.getView().getModel(e);
		},
		setModel: function(e, t) {
			return this.getView().setModel(e, t);
		},
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		onPressNavButton: function(e, n) {
			var o = t.getInstance().getPreviousHash();
			if (o !== undefined) {
				window.history.go(-1);
			} else {
				var r = true;
				this.getRouter().navTo(e, n, r);
			}
		}
	});
});