sap.ui.define([
	"gdsd/FundingApplication/test/unit/controller/NewApplication.controller"
], function () {
	"use strict";
});