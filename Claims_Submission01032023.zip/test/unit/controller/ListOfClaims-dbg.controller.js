/*global QUnit*/

sap.ui.define([
	"gdsd/NewClaimsApp/controller/ListOfClaims.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ListOfClaims Controller");

	QUnit.test("I should test the ListOfClaims controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});