sap.ui.define([
	"gdsd/NewClaimsApp/test/unit/controller/ListOfClaims.controller"
], function () {
	"use strict";
});