sap.ui.define(["./BaseController"], function(o) {
	"use strict";
	return o.extend("gdsd.NewClaimsApp.controller.FormSelection", {
		onInit: function() {
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this.Router.getRoute("FormSelection").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(o) {
			this.path = o.getParameter("arguments").claimPath;
		},
		onPressChildrenHome: function() {
			var o = "1";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressShelterChild: function() {
			var o = "2";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressShelterWoman: function() {
			var o = "3";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressHomeBased: function() {
			var o = "4";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressHomePeopleDisability: function() {
			var o = "5";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressHomePeople: function() {},
		onPressHomeAge: function() {},
		onPressInPatient: function() {
			var o = "7";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressOutPatient: function() {
			var o = "8";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressPlacesCare: function() {
			var o = "9";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressProtective: function() {
			var o = "10";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressServiceCentre: function() {
			var o = "11";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressSWDisability: function() {
			var o = "12";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressSWChild: function() {
			var o = "13";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressSWAged: function() {
			var o = "14";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressSWFamilies: function() {
			var o = "16";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressSWSubstance: function() {
			var o = "17";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressSWVEP: function() {
			var o = "18";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressSWCrime: function() {
			var o = "15";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		},
		onPressResidentFacility: function () {
				var o = "19";
			this.Router.navTo("SocialWorkPosts", {
				FormNo: o,
				claimPath: this.path
			});
		}
	});
});