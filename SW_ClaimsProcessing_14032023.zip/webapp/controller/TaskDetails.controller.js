sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], function(Controller, JSONModel, History, Filter, FilterOperator, Sorter) {
	"use strict";

	return Controller.extend("gdsd.Claims_Processing.controller.TaskDetails", {

		onInit: function() {

			this._oODataModel = this.getOwnerComponent().getModel();
			var oModel = new JSONModel({
				HTMLGov: "<ol><li>To determine consistency of board members across all funding phases from application, approval and reporting stages</li><li>Assess whether the board is holding regular meetings to exercise oversight over management and to provide strategic direction</li><li>Determine how the current board was elected/appointed and check when last the NPO held its annual general meeting (AGM) and the records/minutes of that AGM</li><li>Confirm that board members have no conflicting interests e.g. dual roles in management and board, companies owned by board members are not service providers in any form, etc. </li><li>Overall assessment of the effectiveness of board’s oversight role on the affairs of the organization</li></ol>",
				HTMLRec: "<ol><li>To confirm whether the NPO has key documentation in their records and information correlates with Departmental records<ul type='a'><li>Request for a copy of a Quarterly Expenditure Report (QER), Monthly Income & Expenditure (MIE); three monthly claim forms for that quarter that were submitted to the Department as per SLA terms & conditions</li><li>Test for correctness of the information contained in the above key documents for correlation with Departmental records e.g. confirm whether the number of beneficiaries reported in the claim forms tally with the regional performance quarterly report against the annual performance plan (APP); </li></ul></li><li>Verify that the NPO has submitted a letter of assurance which is attached to the SLA to give assurance that it has a transparent accounting system and effective internal control</li><li>To confirm whether the NPO has a reliable accounting system in terms accuracy and completeness of financial records</li><li>To confirm whether the NPO has effective internal financial controls to mitigate any possible financial risks that may occur</li><li>Observe the speed of retrieving the records of the organisation to test efficiency</li><li>Overall assessment of the records management, accounting system & internal controls of the organisation</li></ol>",
				HTMLFin: "<ol><li>To track whether the organization plans for its financial activities and whether is financial stable beyond the Departmental subsidy</li><li>Assess whether it has a financial policy in place and confirm whether it plans for its financial activities on a regular basis<ul ><li>Obtain the financial policy if any</li><li>Request for monthly/quarterly/annual budget for the NPO against their strategic objective</li></ul></li><li>Obtain the monthly income & expenditure (MIE), quarterly expenditure report (QER) and bank statements to confirm other sources of income were reported:<ul><li>Confirm whether the other sources of income were reported accurately in the MIE/QER against the bank statement or audited financial statements;</li></ul></li><li>Determine whether the organisation is financially sustainable without DSD funds or is reliant on Departmental funding:<ul><li>Quantify, in percentage form, the value of the other incomes versus the total income of the NPO</li><li>Quantify, in percentage form, the value of Departmental subsidy versus the total income of the NPO;</li></ul></li><li>Make an overall assessment on the NPO’s financial planning and sustainability; </li></ol>",
				HTMLBen: "<ol><li>To track whether the organization is reaching the targeted number of beneficiaries as outlined in the SLA</li><li>Check whether the negative variance - from actual beneficiaries reached against SLA approved number - is within the 80/20 rule<ul><li>Quantify the value of the negative variance (quarterly subsidy divided by total number of beneficiaries x negative variance)</li><li>The value of the negative variance should be considered for recovery or regarded as a surplus;</li></ul></li><li>Confirm whether the number of beneficiaries reported in the claim forms tally with the regional performance quarterly report against the annual performance plan (APP);</li><li>Assess whether the beneficiaries reached are appropriate for the programme/services provided by the organisation e.g. no children in an old age home, etc.<ul><li>Provide details of the inappropriate beneficiaries (names, profile, etc.) and the period under review or visit</li></ul></li><li>Make an overall assessment on performance of the NPO in relation to beneficiaries</li></ol>",
				HTMLExp: "<ol><li>To track whether the expenditure incurred by the NPO was in line the SLA or approved deviation or costing framework;</li><li>Obtain the monthly income & expenditure (MIE) or monthly separate ledger for detailed daily/monthly transactions in order to compare with other key documents such as SLA, the quarterly expenditure report (QER) and bank statement</li><li>Test for correlation between QER reported amounts with MIE amounts to confirm the correctness of the QER report.  The aggregated quarterly amounts should tally with the monthly ledger or MIE<ul><li>Use the excel spreadsheets to show your workings, analysis and findings of MIE, QER, SLA and bank statements</li></ul></li><li>Confirm whether the overall total monthly expenditure is complete, accurate and valid as per the MIE and the reported</li><li>Furthermore, determine the final quarterly surplus or unspent amount as per the above financial analysis</li></ol>",
				HTMLBank: "<ol><li>Determine whether the NPO is conducting its daily financial transactions in the account provided in the service level agreement:<ul><li>Confirm whether the bank statement attached to the QER correlate with the banking details on the SLA;</li></ul></li><li>Transactional bank account testing:<ul><li>confirm whether the bank statements attached to the QER are for the transactional account of the NPO and that is the same bank account used for DSD subsidy deposits. </li><li>If funds are transferred-out to another account, the NPO should submit the bank statement of the transactional account or give the designated DSD official access to the main transactional account for inspection & analysis;</li></ul></li><li>Determine whether the bank account utilised by the NPO is a transactional account or not and if not, do you get access to the main transactional account or they have submitted bank statements of the account other than the one used to pay the subsidy.</li></ol>",
				HTMLSubsidy: "<ol><li>Subsidy payment tracking – <ul><li>Track the income amount reported either in the MIE or QER in the bank statement for correlation with the SLA quarterly tranche amount paid;</li></ul></li></ol>",
				HTMLPersonnel: "<ol><li>Track all employees outlined in the monthly claim form in the bank statement and compare the monthly salaries paid against the monthly amounts reported in the monthly claim form. If the employees are not directly paid or reflected as individuals in the bank statements but paid as a lump-sum, obtain a payroll with list of employees paid, monthly amounts paid and their designation:  <ul><li>Use the excel spreadsheets to show your workings, analysis and findings of claim form, payroll and bank statements;</li></ul></li><li>Confirm whether the NPO is directly funded for personnel or not and the breakdown should be outlined in the SLA;</li><li>Check that the number of personnel and their designation as reported on the claim form correlates with the following:<ul><li>SLA personnel details;</li><li>Monthly payroll or staff list;</li></ul></li><li>Determine whether the total monthly personnel expenditure amount is the same as the one reported in the quarterly expenditure report (QER) or monthly income & expenditure (MIE) or separate ledger and report any variances thereof;</li><li>Trace each monthly salary expenditure to the bank statement alternatively via the payroll system to the bank statement in order to confirm the reported personnel are employed by the NPO and receive a salary from the organization;<ul><li>Check whether the monthly salaries paid to personnel are equal or above the subsidy rates as outline in the SLA;</li></ul></li><li>Be on look-out for any vacancies on the directly funded NPOs and they should not be vacant for more than 3 consecutive months <ul><li>If there were vacancies, quantify the amount for the vacant period and check how the funds were utilized by the organization;</li><li>Assess whether the funds from vacant posts were used for the benefit of NPO and reported accordingly;</li></ul></li><li>Request the qualification certificates for all appointed professionals such as Social Workers, Nurses, Doctors, etc to confirm that salaries are paid to qualified personnel;</li><li>Where applicable, assess the ratio of programme/professional personnel versus beneficiaries against the relevant norm and standard;</li><li>Quantify in percentage form the overall personnel costs vs total expenditure of NPO and overall personnel expenditure vs total NPO costs to determine whether the programme is labour intensive or not;</li><li>Make an overall assessment on personnel expenditure management; </li></ol>",
				HTMLOperational: "<ol><li>Tracking of other expenditure items – firstly, select few high value transactions to track them from the bank statement to MIE and eventually to the QER to ensure that they are correctly and accurately reported; <ul><li>Use the excel spreadsheets to show your workings, analysis and findings in tracking the other expenditure transactions;</li></ul></li></ol>",
				HTMLDocuments: "<ol><li>Supporting documents or invoices – sample few transactions to test that the supporting documents are available, and that the information correlates with the selected expenditure items from bank statement to MIE and QER; <ul><li>Assess the validity of invoices – the invoice must have a date, details of the service provider (name, physical address, registration no, contact details, etc.), itemized quantities, description of products/goods, itemized amount per quantity;</li><li>You can either request the invoices to be emailed to you or conduct an on-site visit for inspection of supporting documents;</li><li>If in doubt about the supporting documents, you can do further test and verification by contacting the service provider to confirm the correctness of the invoice;</li></ul></li></ol>",
				HTMLWithdrawals: "<ol><li>Cash withdrawals – scrutinize for any cash withdrawals from the monthly bank statements provided and if any, aggregate all the withdrawal amounts for the quarter to determine whether they are above R10, 000 or the aggregate exceeds 10% of the quarterly subsidy as per SLA.  <ul><li>Detail all the dates of withdrawals and amounts withdrawn as cash. The afore-mentioned detail can be outlined below under monitoring findings or can be outlined on an excel spreadsheet as part of your workings;</li></ul></li></ol>",
				HTMLUnspent: "<ol><li>Preliminary quarterly surplus or unspent - add all expenditure amounts from beginning of the month to the end and compare with the total amounts reported in MIE and QER:  <ul><li>You can obtain a preliminary quarterly surplus or unspent amount by deducting the total expenditure amounts for the quarter against the subsidy amount paid for that quarter;</li></ul></li><li>Final quarterly surplus or unspent - add all verified monthly expenditure amounts according to your excel spreadsheet workings and deduct it from the confirmed quarterly subsidy paid for that quarterly period;<ul><li>You can obtain a preliminary quarterly surplus or unspent amount by deducting the total expenditure amounts for the quarter against the subsidy amount paid for that quarter;</li></ul></li></ol>"
			});

			this.getView().setModel(oModel);
			this._IconBar = this.byId("inspIconBar");
			this.fetchData();

		},

		fetchData: function() {

			var GUID = "0022486530D81EDCB8B741BC08D39127";
			var ObjID = "22486530";

			// var oFilter = [
			// 	new Filter("Guid", FilterOperator.EQ, GUID)
			// ];

			var oFilter = new sap.ui.model.Filter("Guid", "EQ", GUID);
			var oInspectionJSON = new JSONModel();
			var oBusyIndicator = sap.ui.core.BusyIndicator;
			oBusyIndicator.show();
			var sPath = "/GetFinancialInspectionSet(Guid='" + GUID + "',ObjectId='" + ObjID + "')";
			this._oODataModel.read(sPath, {
				// filters: [oFilter],
				success: function(oData) {
					oInspectionJSON.setSizeLimit(oData.length);
					oInspectionJSON.setData({
						data: oData
					});
					this.getView().setModel(oInspectionJSON);
					this.getView().bindElement({
						path: "/data"
					});
					oBusyIndicator.hide();
				}.bind(this),
				error: function(oError) {
					oBusyIndicator.hide();
				}.bind(this)
			});
		},

		Scroll: function() {
			document.body.scrollTop = 0; // For Safari
			document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
		},

		onNPODetailsNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Gov");
			this.byId("pageId").scrollTo(0, 0);
		},
		onGovPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("NPO");
			this.byId("pageId").scrollTo(0, 0);
		},
		onGovNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Rec");
			this.byId("pageId").scrollTo(0, 0);
		},
		onRecordsPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("Gov");
			this.byId("pageId").scrollTo(0, 0);
		},
		onRecordsNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Fin");
			this.byId("pageId").scrollTo(0, 0);
		},
		onFinancialPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("Rec");
			this.byId("pageId").scrollTo(0, 0);
		},
		onFinancialNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Ben");
			this.byId("pageId").scrollTo(0, 0);
		},
		onBeneficiaryPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("Fin");
			this.byId("pageId").scrollTo(0, 0);
		},
		onBeneficiaryNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Bank");
			this.byId("pageId").scrollTo(0, 0);
		},
		onBankPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("Ben");
			this.byId("pageId").scrollTo(0, 0);
		},
		onBankNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Sub");
			this.byId("pageId").scrollTo(0, 0);
		},
		onSubsidyPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("Bank");
			this.byId("pageId").scrollTo(0, 0);
		},
		onSubsidyNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Ppl");
			this.byId("pageId").scrollTo(0, 0);
		},
		onPersonnelPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("Sub");
			this.byId("pageId").scrollTo(0, 0);
		},
		onPersonnelNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Op");
			this.byId("pageId").scrollTo(0, 0);
		},
		onOperationalPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("Ppl");
			this.byId("pageId").scrollTo(0, 0);
		},
		onOperationalNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Doc");
			this.byId("pageId").scrollTo(0, 0);
		},
		onDocumentsPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("Op");
			this.byId("pageId").scrollTo(0, 0);
		},
		onDocumentsNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Wdr");
			this.byId("pageId").scrollTo(0, 0);
		},
		onWithdrawalsPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("Doc");
			this.byId("pageId").scrollTo(0, 0);
		},
		onWithdrawalsNextPress: function() {
			this.byId("progInspBar").setSelectedKey("UnSp");
			this.byId("pageId").scrollTo(0, 0);
		},
		onUnspentPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("Wdr");
			this.byId("pageId").scrollTo(0, 0);
		},
		onUnspentNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Ats");
			this.byId("pageId").scrollTo(0, 0);
		},
		onAssetsPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("UnSp");
			this.byId("pageId").scrollTo(0, 0);
		},
		onAssetsNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Scr");
			this.byId("pageId").scrollTo(0, 0);
		},
		onScoresPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("Ats");
			this.byId("pageId").scrollTo(0, 0);
		},
		onScoresNextPress: function() {
			this.byId("progInspBar").setSelectedKey("Recc");
			this.byId("pageId").scrollTo(0, 0);
		},
		onRecommendationPreviousPress: function() {
			this.byId("progInspBar").setSelectedKey("Scr");
			this.byId("pageId").scrollTo(0, 0);
		},
		onRecommendationNextPress: function() {
			this.byId("progInspBar").setSelectedKey("location");
			this.byId("pageId").scrollTo(0, 0);
		},
	

	/*	onPreviousPress: function(oEvent) {
			var oSource = oEvent.getSource();
			var sKey = oSource.getTooltip();
			this._IconBar.setSelectedKey(sKey);
			this.Scroll();
		},*/
		onHandleGovText: function() {
			if (!this._GovText) {
				this._GovText = sap.ui.xmlfragment("gdsdZFIN_SUPERVISOR_DISPLAY.view.Fragments.Gov", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._GovText);
			this.getView().addDependent(this._GovText);
			this._GovText.open();
		},

		onCloseGovText: function() {
			this._GovText.close();
		},

		onHandleRecordsText: function() {
			if (!this._RecordsText) {
				this._RecordsText = sap.ui.xmlfragment("gdsdZFIN_SUPERVISOR_DISPLAY.view.Fragments.Records", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._RecordsText);
			this.getView().addDependent(this._RecordsText);
			this._RecordsText.open();
		},

		onCloseRecordsText: function() {
			this._RecordsText.close();
		},

		onHandleFinText: function() {
			if (!this._FinanceText) {
				this._FinanceText = sap.ui.xmlfragment("gdsdZFIN_SUPERVISOR_DISPLAY.view.Fragments.Finance", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._FinanceText);
			this.getView().addDependent(this._FinanceText);
			this._FinanceText.open();
		},

		onCloseFinText: function() {
			this._FinanceText.close();
		},

		onHandleBenText: function() {
			if (!this._BeneficiariesText) {
				this._BeneficiariesText = sap.ui.xmlfragment("gdsdZFIN_SUPERVISOR_DISPLAY.view.Fragments.Beneficiaries", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._BeneficiariesText);
			this.getView().addDependent(this._BeneficiariesText);
			this._BeneficiariesText.open();
		},

		onCloseBenText: function() {
			this._BeneficiariesText.close();
		},

		onHandleExpText: function() {
			if (!this._ExpindetureText) {
				this._ExpindetureText = sap.ui.xmlfragment("gdsdZFIN_SUPERVISOR_DISPLAY.view.Fragments.Expenditure", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._ExpindetureText);
			this.getView().addDependent(this._ExpindetureText);
			this._ExpindetureText.open();
		},

		onCloseExpText: function() {
			this._ExpindetureText.close();
		},

		onHandleSubsidyText: function() {
			if (!this._SubsidyText) {
				this._SubsidyText = sap.ui.xmlfragment("gdsdZFIN_SUPERVISOR_DISPLAY.view.Fragments.Subsidy", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._SubsidyText);
			this.getView().addDependent(this._SubsidyText);
			this._SubsidyText.open();
		},

		onCloseSubsidyText: function() {
			this._SubsidyText.close();
		},

		onHandlePersonnelText: function() {
			if (!this._PersonnelText) {
				this._PersonnelText = sap.ui.xmlfragment("gdsdZFIN_SUPERVISOR_DISPLAY.view.Fragments.Personnel", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._PersonnelText);
			this.getView().addDependent(this._PersonnelText);
			this._PersonnelText.open();
		},

		onClosePersonnelText: function() {
			this._PersonnelText.close();
		},

		onHandleOperationText: function() {
			if (!this._OperationText) {
				this._OperationText = sap.ui.xmlfragment("gdsdZFIN_SUPERVISOR_DISPLAY.view.Fragments.Operational", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._OperationText);
			this.getView().addDependent(this._OperationText);
			this._OperationText.open();
		},

		onCloseOperationText: function() {
			this._OperationText.close();
		},

		onHandleDocText: function() {
			if (!this._DocumentText) {
				this._DocumentText = sap.ui.xmlfragment("gdsdZFIN_SUPERVISOR_DISPLAY.view.Fragments.Documents", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._DocumentText);
			this.getView().addDependent(this._DocumentText);
			this._DocumentText.open();
		},

		onCloseDocText: function() {
			this._DocumentText.close();
		},

		onHandleWithdrawText: function() {
			if (!this._WithdrawText) {
				this._WithdrawText = sap.ui.xmlfragment("gdsdZFIN_SUPERVISOR_DISPLAY.view.Fragments.Withdrawal", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._WithdrawText);
			this.getView().addDependent(this._WithdrawText);
			this._WithdrawText.open();
		},

		onCloseWithdrawText: function() {
			this._WithdrawText.close();
		},

		onHandleUnspentText: function() {
			if (!this._UnspentText) {
				this._UnspentText = sap.ui.xmlfragment("gdsdZFIN_SUPERVISOR_DISPLAY.view.Fragments.Unspent", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._UnspentText);
			this.getView().addDependent(this._UnspentText);
			this._UnspentText.open();
		},

		onCloseUnspentText: function() {
			this._UnspentText.close();
		}
	});
});