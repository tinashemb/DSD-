sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/ui/Device",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/MessageToast",
	"sap/m/Text"
], function(BaseController, MessageBox, Device, Filter, FilterOperator, Fragment, Dialog, DialogType, Button, ButtonType, MessageToast,
	Text) {
	"use strict";

	return BaseController.extend("gdsd.Claims_Processing.controller.SWProcess", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.Claims_Processing.view.SWProcess
		 */
		onInit: function() {
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this.QuarterlyClaims = this.getOwnerComponent().getModel("QuarterlyClaims");

			var oViewModel = new sap.ui.model.json.JSONModel({
				totalAmount: 0
			});

			this.ProductsModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.getView().setModel(oViewModel, "ViewModel");
			this.Router.getRoute("SWProcess").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function(oEvent) {
			this.sPath = "/" + window.decodeURIComponent(oEvent.getParameter("arguments").Path);
			this.Property = this.QuarterlyClaims.getProperty(this.sPath);

			this.Property.NPIFlagP = "X";

			var ClaimProcessModel = new sap.ui.model.json.JSONModel({
				data: this.Property
			});

			//Set Binding Mode
			ClaimProcessModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

			this.getView().setModel(ClaimProcessModel);

			this.byId("beneficiary").setModel(ClaimProcessModel);
			this.byId("beneficiary").bindElement({
				path: "/data"
			});
			this.byId("governance").setModel(ClaimProcessModel);
			this.byId("governance").bindElement({
				path: "/data"
			});
			this.byId("admin").setModel(ClaimProcessModel);
			this.byId("admin").bindElement({
				path: "/data"
			});
			this.byId("program").setModel(ClaimProcessModel);
			this.byId("program").bindElement({
				path: "/data"
			});
			this.byId("programmon").setModel(ClaimProcessModel);
			this.byId("programmon").bindElement({
				path: "/data"
			});
			this.byId("capacity").setModel(ClaimProcessModel);
			this.byId("capacity").bindElement({
				path: "/data"
			});
			this.byId("summary").setModel(ClaimProcessModel);
			this.byId("summary").bindElement({
				path: "/data"
			});

			switch (this.Property.TaskType) {
				case "ZT22":
					this.byId("sw_benef").setVisible(true);
					this.byId("sup_benef").setVisible(false);
					this.byId("sw_govern").setVisible(true);
					this.byId("sup_govern").setVisible(false);
					this.byId("sw_admincomp").setVisible(true);
					this.byId("sup_admincomp").setVisible(false);
					this.byId("sw_programdet").setVisible(true);
					this.byId("sup_programdet").setVisible(false);
					this.byId("sw_programmon").setVisible(true);
					this.byId("sup_programmon").setVisible(false);
					this.byId("sw_capacity").setVisible(true);
					this.byId("sup_capacity").setVisible(false);
					this.byId("sw_evalution").setVisible(true);
					this.byId("sup_evalution").setVisible(false);
					this.byId("score").setVisible(true);
					this.byId("GroupA").setVisible(true);
					this.byId("sup_scoring1").setVisible(false);
					this.byId("sup_scoring2").setVisible(false);

					this.byId("sw_benef").setEnabled(true);
					this.byId("sw_govern").setEnabled(true);
					this.byId("sw_admincomp").setEnabled(true);
					this.byId("sw_programdet").setEnabled(true);
					this.byId("sw_programmon").setEnabled(true);
					this.byId("sw_capacity").setEnabled(true);
					this.byId("sw_evalution").setEnabled(true);
					break;
				case "ZT26":
					this.byId("sw_benef").setVisible(true);
					this.byId("sup_benef").setVisible(true);
					this.byId("sw_govern").setVisible(true);
					this.byId("sup_govern").setVisible(true);
					this.byId("sw_admincomp").setVisible(true);
					this.byId("sup_admincomp").setVisible(true);
					this.byId("sw_programdet").setVisible(true);
					this.byId("sup_programdet").setVisible(true);
					this.byId("sw_programmon").setVisible(true);
					this.byId("sup_programmon").setVisible(true);
					this.byId("sw_capacity").setVisible(true);
					this.byId("sup_capacity").setVisible(true);
					this.byId("sw_evalution").setVisible(true);
					this.byId("sup_evalution").setVisible(true);
					this.byId("score").setVisible(false);
					this.byId("GroupA").setVisible(false);
					this.byId("sup_scoring1").setVisible(true);
					this.byId("sup_scoring2").setVisible(true);

					this.byId("sw_benef").setEnabled(false);
					this.byId("sw_govern").setEnabled(false);
					this.byId("sw_admincomp").setEnabled(false);
					this.byId("sw_programdet").setEnabled(false);
					this.byId("sw_programmon").setEnabled(false);
					this.byId("sw_capacity").setEnabled(false);
					this.byId("sw_evalution").setEnabled(false);
					break;
				case "ZT28":
					this.byId("sw_benef").setVisible(true);
					this.byId("sup_benef").setVisible(true);
					this.byId("sw_govern").setVisible(true);
					this.byId("sup_govern").setVisible(true);
					this.byId("sw_admincomp").setVisible(true);
					this.byId("sup_admincomp").setVisible(true);
					this.byId("sw_programdet").setVisible(true);
					this.byId("sup_programdet").setVisible(true);
					this.byId("sw_programmon").setVisible(true);
					this.byId("sup_programmon").setVisible(true);
					this.byId("sw_capacity").setVisible(true);
					this.byId("sup_capacity").setVisible(true);
					this.byId("sw_evalution").setVisible(true);
					this.byId("sup_evalution").setVisible(true);
					this.byId("score").setVisible(false);
					this.byId("GroupA").setVisible(false);
					this.byId("sup_scoring1").setVisible(false);
					this.byId("sup_scoring2").setVisible(false);

					this.byId("ApproveSWButton").setVisible(false);
					this.byId("RejectSWButton").setVisible(false);

					this.byId("sw_benef").setEnabled(false);
					this.byId("sup_benef").setEnabled(false);
					this.byId("sw_govern").setEnabled(false);
					this.byId("sup_govern").setEnabled(false);
					this.byId("sw_admincomp").setEnabled(false);
					this.byId("sup_admincomp").setEnabled(false);
					this.byId("sw_programdet").setEnabled(false);
					this.byId("sup_programdet").setEnabled(false);
					this.byId("sw_programmon").setEnabled(false);
					this.byId("sup_programmon").setEnabled(false);
					this.byId("sw_capacity").setEnabled(false);
					this.byId("sup_capacity").setEnabled(false);
					this.byId("sw_evalution").setEnabled(false);
					this.byId("sup_evalution").setEnabled(false);
					break;
			}

			this.getProducts(this.Property.parent_guid);
		},

		getProducts: function(vGuid) {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("Applicationguid", "EQ", vGuid);
			var oTable = this.byId("LineItemsTable");
			//	oTable2 = this.byId("LineItemsTable2");

			this._oODataModel.read("/GetApplicationItemsSet", {
				filters: [oFilter],
				success: function(odata) {
					// var ProductsModel = new sap.ui.model.json.JSONModel({
					// 	data: odata.results
					// });

					this.ProductsModel.getData().data = odata.results;

					oTable.setModel();
					oTable.setModel(this.ProductsModel, "ProductLineItemsModel");
					oTable.getModel("ProductLineItemsModel").refresh(true);

					this.countGrandTotal();
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve product details");
				}.bind(this)
			});
		},

		onSWSubmit: function() {
			if (this.getView().getModel().getData().data.TaskType === "ZT22") {
				if (!this.oInspectionDialog) {
					this.oInspectionDialog = new Dialog({
						type: DialogType.Message,
						title: "Confirm",
						content: new Text({
							text: "Is an inspection required?"
						}),
						customHeader: [
							new sap.m.Bar({
								contentRight: new sap.ui.core.Icon({
									type: ButtonType.Reject,
									text: "Confirm",
									src: "sap-icon://decline",
									useIconTooltip: false,
									color: "#f33334",
									press: function(oEvent) {
										this.oInspectionDialog.close();
										this.oInspectionDialog = null;
									}.bind(this)
								}).addStyleClass("sapUiMediumMarginBottom"),
								contentMiddle: [
									new sap.m.Title({
										text: "Confirm"
									}),
									new sap.ui.core.Icon({
										src: "sap-icon://message-warning",
										useIconTooltip: false,
										color: "#E69A17"
									})
								]
							})

						],
						beginButton: new Button({
							type: ButtonType.Emphasized,
							text: "Yes",
							press: function() {
								this.getView().getModel().getData().data.Status = "E0019";
								this.onUpdateClaim();
								this.oInspectionDialog.close();
							}.bind(this)
						}),
						endButton: new Button({
							text: "No",
							press: function() {
								this.getView().getModel().getData().data.Status = "E0027";
								this.onUpdateClaim();
								this.oInspectionDialog.close();
							}.bind(this)
						})
					});
				}

				this.oInspectionDialog.open();
			} else {
				this.getView().getModel().getData().data.Status = "E0019";
				this.onUpdateClaim();
			}
		},

		onSWApprove: function() {
			if (!this.oApproveSWDialog) {
				this.oApproveSWDialog = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({
						text: "Are you sure you want to approve the claim?"
					}),
					customHeader: [
						new sap.m.Bar({
							contentRight: new sap.ui.core.Icon({
								type: ButtonType.Reject,
								text: "Confirm",
								src: "sap-icon://decline",
								useIconTooltip: false,
								color: "#f33334",
								press: function(oEvent) {
									this.oApproveSWDialog.close();
									this.oApproveSWDialog = null;
								}.bind(this)
							}).addStyleClass("sapUiMediumMarginBottom"),
							contentMiddle: [
								new sap.m.Title({
									text: "Confirm"
								}),
								new sap.ui.core.Icon({
									src: "sap-icon://message-warning",
									useIconTooltip: false,
									color: "#E69A17"
								})
							]
						})

					],
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Yes",
						press: function() {
							this.getView().getModel().getData().data.Status = "E0019";
							this.onUpdateClaim();
							this.oApproveSWDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "No",
						press: function() {
							this.oApproveSWDialog.close();
						}.bind(this)
					})
				});
			}

			this.oApproveSWDialog.open();
		},

		onSWReject: function() {
			if (!this.oRejectSWDialog) {
				this.oRejectSWDialog = new Dialog({
					type: DialogType.Message,
					title: "Reject",
					content: new Text({
						text: "Are you sure you want to reject the claim?"
					}),
					customHeader: [
						new sap.m.Bar({
							contentRight: new sap.ui.core.Icon({
								type: ButtonType.Reject,
								text: "Reject",
								src: "sap-icon://decline",
								useIconTooltip: false,
								color: "#f33334",
								press: function(oEvent) {
									this.oRejectSWDialog.close();
									this.oRejectSWDialog = null;
								}.bind(this)
							}).addStyleClass("sapUiMediumMarginBottom"),
							contentMiddle: [
								new sap.m.Title({
									text: "Reject"
								}),
								new sap.ui.core.Icon({
									src: "sap-icon://message-warning",
									useIconTooltip: false,
									color: "#E69A17"
								})
							]
						})

					],
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Yes",
						press: function() {
							this.getView().getModel().getData().data.Status = "E0027";
							this.onUpdateClaim();
							this.oRejectSWDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "No",
						press: function() {
							this.oRejectSWDialog.close();
						}.bind(this)
					})
				});
			}

			this.oRejectSWDialog.open();
		},

		onUpdateClaim: function() {
			sap.ui.core.BusyIndicator.show(0);
			var oProperties = this.getView().getModel().getData().data;

			if (oProperties.TaskType === "ZT22") {
				switch (this.byId("GroupA").getSelectedIndex()) {
					case 0:
						oProperties.Zgc8 = "Low";
						break;
					case 1:
						oProperties.Zgc8 = "Medium";
						break;
					case 2:
						oProperties.Zgc8 = "High";
						break;
				}
			}

			if (oProperties.TaskType === "ZT28" && oProperties.NPIFlagM !== "X") {
				MessageBox.error("Please also review Monitoring and Evaluation section before processing");
				return;
			}

			this._oODataModel.update("/GetClaimsProcessingSet(Guid='" + oProperties.Guid + "',ObjectId='" + oProperties.ObjectId + "')",
				oProperties, {
					success: function(results) {
						sap.ui.core.BusyIndicator.hide();
						this.successAndNavigate();
					}.bind(this),
					error: function(results) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error("Error occured while trying to process a claim");
					}

				});
		},

		successAndNavigate: function() {

			MessageBox.success("Claim " + this.Property.ObjectId + " has been successfully updated", {
				icon: sap.m.MessageBox.Icon.CONFIRMATION,
				title: "Confirmation",
				actions: [sap.m.MessageBox.Action.OK],
				onClose: function(oAction) {
					if (oAction === "OK") {
						this.Router.navTo("QuarterlyClaims");
						return;
					}
				}.bind(this)
			});
		},

		onProductsNextPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("beneftracking");
			this.byId("me_processPage").scrollTo(0, 0);
		},

		onBenefTrackingPrevPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("LineItems");
			this.byId("swProcessPage").scrollTo(0, 0);
		},

		onBenefTrackingNextPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("governance");
			this.byId("swProcessPage").scrollTo(0, 0);
		},

		onGovPreviousPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("beneftracking");
			this.byId("swProcessPage").scrollTo(0, 0);
		},

		onGovNextPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("adminCompliance");
			this.byId("swProcessPage").scrollTo(0, 0);
		},

		onAdminCompliancePreviousPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("governance");
			this.byId("swProcessPage").scrollTo(0, 0);
		},

		onAdminComplianceNextPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("programDetails");
			this.byId("swProcessPage").scrollTo(0, 0);
		},
		onProgramDetailsPreviousPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("adminCompliance");
			this.byId("swProcessPage").scrollTo(0, 0);
		},
		onProgramDetailsNextPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("programMonitoring");
			this.byId("swProcessPage").scrollTo(0, 0);
		},

		onProgramMonitoringPreviousPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("programDetails");
			this.byId("swProcessPage").scrollTo(0, 0);
		},

		onProgramMonitoringNextPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("capacityneeds");
			this.byId("swProcessPage").scrollTo(0, 0);
		},

		onCapacityNeedsPrevPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("programMonitoring");
			this.byId("swProcessPage").scrollTo(0, 0);
		},

		onCapacityNeedsNextPress: function() {
			if (this.Property.TaskType === "ZT28") {
				this.byId("ApproveSWButton").setVisible(false);
				this.byId("RejectSWButton").setVisible(false);
				this.byId("submitSWButton").setVisible(false);
			} 
			if (this.Property.TaskType === "ZT26") {
				this.byId("ApproveSWButton").setVisible(true);
				this.byId("RejectSWButton").setVisible(true);
				this.byId("submitSWButton").setVisible(false);
			}
			if (this.Property.TaskType === "ZT22") {
				this.byId("ApproveSWButton").setVisible(false);
				this.byId("RejectSWButton").setVisible(false);
				this.byId("submitSWButton").setVisible(true);
			}
			this.byId("IconBar").setSelectedKey("summary");
			this.byId("swProcessPage").scrollTo(0, 0);
		},

		onSummaryPrevPress: function() {
			this.byId("ApproveSWButton").setVisible(false);
			this.byId("RejectSWButton").setVisible(false);
			this.byId("submitSWButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("capacityneeds");
			this.byId("swProcessPage").scrollTo(0, 0);
		},

		handleIconTabBarSelect: function(oEvent) {
			var sKey = oEvent.getParameter("key");

			if (sKey === "summary" && this.Property.TaskType === "ZT22") {
				this.byId("ApproveSWButton").setVisible(false);
				this.byId("RejectSWButton").setVisible(false);
				this.byId("submitSWButton").setVisible(true);
			}
			
			if (sKey === "summary" && this.Property.TaskType === "ZT26") {
				this.byId("ApproveSWButton").setVisible(true);
				this.byId("RejectSWButton").setVisible(true);
				this.byId("submitSWButton").setVisible(false);
			}
			
			if (this.Property.TaskType === "ZT28") {
				this.byId("ApproveSWButton").setVisible(false);
				this.byId("RejectSWButton").setVisible(false);
				this.byId("submitSWButton").setVisible(false);
			}
		},

		countGrandTotal: function() {
			var oTotal = 0;

			for (var i = 0; i < this.ProductsModel.getData().data.length; i++) {
				oTotal = oTotal + parseFloat(this.ProductsModel.getData().data[i].Totalamount);
			}

			this.getView().getModel("ViewModel").setProperty("/totalAmount", oTotal);
		}

	});

});