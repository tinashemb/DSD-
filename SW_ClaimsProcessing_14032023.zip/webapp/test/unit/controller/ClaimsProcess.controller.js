/*global QUnit*/

sap.ui.define([
	"gdsd/Claims_Processing/controller/ClaimsProcess.controller"
], function (Controller) {
	"use strict";

	QUnit.module("ClaimsProcess Controller");

	QUnit.test("I should test the ClaimsProcess controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});