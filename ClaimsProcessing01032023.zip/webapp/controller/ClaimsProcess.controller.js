sap.ui.define([
	"./BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox"
], function(BaseController, Filter, FilterOperator, History, Sorter, MessageBox) {
	"use strict";

	return BaseController.extend("gdsd.Claims_Processing.controller.ClaimsProcess", {
		onInit: function() {
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this._claimsModel = this.getOwnerComponent().getModel("MonthlyClaims");
			this.QuarterlyClaims = this.getOwnerComponent().getModel("QuarterlyClaims");
			this.Router.getRoute("ClaimsProcess").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function(oEvent) {
			this.sPath = "/" + window.decodeURIComponent(oEvent.getParameter("arguments").Path);
			this.processType = oEvent.getParameter("arguments").processType;
			this.Property = this.QuarterlyClaims.getProperty(this.sPath);

			if (this.sPath !== undefined) {
				if (this.Property.TaskType === "ZT26" || this.Property.TaskType === "ZT27" || this.Property.TaskType === "ZT28") {
					if (this.Property.InspectionGuid === "" || this.Property.InspectionGuid === undefined) {
					this.byId("inspection").setVisible(false);
					}else{
					 this.byId("inspection").setVisible(true);	
					}
				}
				this.getMonthlyClaims();
			}
		},
		
		onSiteInspectionLinkPress: function () {
			//this.Router.navTo("Prog_SupervisorDisplay");
			this.Router.navTo("Prog_SupervisorDisplay", {
				InspectionGuid: this.Property.InspectionGuid
			});
		},

		getMonthlyClaims: function() {
			sap.ui.core.BusyIndicator.show(0);

			var oFilterSLAGuid = new sap.ui.model.Filter("SlaGuid", "EQ", this.Property.sla_guid);
			var oFilterGuid = new sap.ui.model.Filter("Guid", "EQ", this.Property.Guid);
			
			this._oODataModel.read("/GetClaimsSet", {
				filters: [oFilterGuid, oFilterSLAGuid],
				success: function(odata) {
					var ApplicationJsonModel = new sap.ui.model.json.JSONModel({
						data: odata.results
					});

					this._claimsModel.getData().data = odata.results;

					//Set Binding Mode
					ApplicationJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

					this.getView().setModel(this._claimsModel);
					this.getView().getModel().refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve application details");
				}.bind(this)
			});
		},

		onItemPress: function(oEvent) {
			//var oItem = oEvent.getSource();
			//this.Router.navTo("TaskDetail");
			// this.Router.navTo("ApplicationDetails", {
			// 	taskPath: window.encodeURIComponent(oItem.getBindingContext().getPath().substr(1))
			// });

			this.Router.navTo("Claim", {
				//prepare object path to be passed on to target
				//Guid: oEvent.getSource().getBindingContext().getProperty("Guid"),
				Path: window.encodeURIComponent(oEvent.getSource().getBindingContext().getPath().substr(1)),
				MonthlyClaimPath: window.encodeURIComponent(this.sPath.substr(1))
			});
		},

		onSearch: function(oEvent) {
			// add filter for search
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var contains = sap.ui.model.FilterOperator.Contains;
				var aFilters = new Filter([
						new sap.ui.model.Filter("ObjectId", contains, sQuery)
						//	new sap.ui.model.Filter("But000/NameOrg2", contains, sQuery)
					],
					false);
			}
			// update list binding
			var oList = this.byId("List");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		onProcessPress: function() {
			if (this.Property.TaskType === "ZT22" || this.Property.TaskType === "ZT26") {
				this.Router.navTo("SWProcess", {
					Path: window.encodeURIComponent(this.sPath.substr(1))
				});
			} else if (this.Property.TaskType === "ZT23" || this.Property.TaskType === "ZT27") {
				this.Router.navTo("MEProcess", {
					Path: window.encodeURIComponent(this.sPath.substr(1))
				});
			}else if (this.Property.TaskType === "ZT28" && this.processType === "1") {
				this.Router.navTo("SWProcess", {
					Path: window.encodeURIComponent(this.sPath.substr(1))
				});
			}else if (this.Property.TaskType === "ZT28" && this.processType === "2") {
				this.Router.navTo("MEProcess", {
					Path: window.encodeURIComponent(this.sPath.substr(1))
				});
			}
		},

		onAgreement: function() {
			this.Router.navTo("Agreement", {
				Guid: this.Property.sla_guid
			});
		}

	});
});