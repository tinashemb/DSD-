sap.ui.define([
	"./BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("gdsd.Claims_Processing.controller.NPILandingPage", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.Claims_Processing.view.NPILandingPage
		 */
		onInit: function() {
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this._claimsModel = this.getOwnerComponent().getModel("MonthlyClaims");
			this.QuarterlyClaims = this.getOwnerComponent().getModel("QuarterlyClaims");
			this.Router.getRoute("NPILandingPage").attachPatternMatched(this._onObjectMatched, this);
		},
		
		_onObjectMatched: function(oEvent) {
			this.sPath = "/" + window.decodeURIComponent(oEvent.getParameter("arguments").Path);
			this.Property = this.QuarterlyClaims.getProperty(this.sPath);
		},

		onMonthlyClaimsForProgram: function() {
				this.Router.navTo("ClaimsProcess", {
					Path: window.encodeURIComponent(this.sPath.substr(1)),
					processType: "1"
				});
		},
		
		onMonthlyClaimsForME: function() {
				this.Router.navTo("ClaimsProcess", {
					Path: window.encodeURIComponent(this.sPath.substr(1)),
					processType: "2"
				});
		}
	});

});