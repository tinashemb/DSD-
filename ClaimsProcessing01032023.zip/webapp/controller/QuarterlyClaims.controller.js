sap.ui.define([
	"./BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel"
], function(BaseController, Filter, FilterOperator, MessageBox, JSONModel) {
	"use strict";

	return BaseController.extend("gdsd.Claims_Processing.controller.QuarterlyClaims", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.Claims_Processing.view.QuarterlyClaims
		 */
		onInit: function() {
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this.QuarterlyClaims = this.getOwnerComponent().getModel("QuarterlyClaims");
			this.Router.getRoute("QuarterlyClaims").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function() {
			this.getQuartelyClaims();
		},
		getQuartelyClaims: function() {
			sap.ui.core.BusyIndicator.show(0);
			this._oODataModel.read("/GetClaimsProcessingSet", {
				success: function(data) {
					if (data.results[0]) {
						var ClaimsJsonModel = new sap.ui.model.json.JSONModel({
							data: data.results[0]
						});
					}
					this.QuarterlyClaims.getData().data = data.results;

					this.getView().setModel();
					this.byId("headerNPO").setModel(ClaimsJsonModel);
					this.byId("headerNPO").bindElement({
						path: "/data"
					});
					this.getView().setModel(this.QuarterlyClaims);
					this.getView().getModel().refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(error) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve claim details");
				}.bind(this)
			});
		},
		onItemPress: function(e) {
			var oProperty = this.QuarterlyClaims.getProperty(e.getSource().getBindingContext().getPath());

			if (oProperty.TaskType === "ZT28") {
				this.Router.navTo("NPILandingPage", {
					Path: window.encodeURIComponent(e.getSource().getBindingContext().getPath().substr(1))
				});
			} else {
				this.Router.navTo("ClaimsProcess", {
					Path: window.encodeURIComponent(e.getSource().getBindingContext().getPath().substr(1))
				});
			}
		},

		onSearch: function(oEvent) {
			// add filter for search
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var contains = sap.ui.model.FilterOperator.Contains;
				var aFilters = new Filter([
						new sap.ui.model.Filter("ObjectId", contains, sQuery)
						//	new sap.ui.model.Filter("But000/NameOrg2", contains, sQuery)
					],
					false);
			}
			// update list binding
			var oList = this.byId("List");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		}

	});

});