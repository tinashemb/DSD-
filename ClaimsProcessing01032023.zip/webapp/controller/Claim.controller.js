sap.ui.define([
	"./BaseController",
	"sap/ui/Device",
	"sap/m/MessageBox"
], function(BaseController, Device, MessageBox) {
	"use strict";

	return BaseController.extend("gdsd.Claims_Processing.controller.Claim", {
		onInit: function() {

			this._mViewSettingsDialogs = {};
			//get the odata model from the component
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			//this._claimsModel = this.getOwnerComponent().getModel("ClaimsProcessing");
			this._claimsModel = this.getOwnerComponent().getModel("MonthlyClaims");

			this.SWPModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.SummaryStaffyModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.BeneficiaryModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.ChildrenHomeModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.PlacesModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.AttendanceModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.HBCModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.AwarenessModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.AgeingModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.ClaimsModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.SpecialServiceModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.HomesForPersonsModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.ProctiveWorkshopModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.HBCAnnexBModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.AnnexureAModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			//Set Binding Mode
			this.SWPModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.SummaryStaffyModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.HomesForPersonsModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.SpecialServiceModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.ClaimsModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.AgeingModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.AwarenessModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.HBCModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.AttendanceModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.PlacesModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.ChildrenHomeModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.BeneficiaryModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.ProctiveWorkshopModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.HBCAnnexBModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.AnnexureAModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

			this.Router.getRoute("Claim").attachPatternMatched(this._onObjectMatched, this);

		},

		_onObjectMatched: function(oEvent) {
			this.sPath = "/" + window.decodeURIComponent(oEvent.getParameter("arguments").Path);
			this.MonthlyClaimPath = "/" + window.decodeURIComponent(oEvent.getParameter("arguments").MonthlyClaimPath);

			if (oEvent.getParameter("arguments").Path !== undefined) {
				this.oProperty = this._claimsModel.getProperty(this.sPath);
				this.getTaskClaim(this.oProperty.Guid);
			}
		},

		createFormDialog: function(sDialogFragmentName) {

			// https://stackoverflow.com/questions/55667673/how-to-remove-duplicates-and-display-only-unique-values-in-viewsettingsitem
			var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
				this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;

				if (Device.system.desktop) {
					oDialog.addStyleClass("sapUiSizeCompact");
				}
			}
			return oDialog;
		},

		getTaskClaim: function(vGuid) {
			sap.ui.core.BusyIndicator.show(0);

			this._oODataModel.read("/GetTaskRelatedClaimSet(Guid='" + this.oProperty.Guid + "')", {
				success: function(odata) {

					var ClaimModel = new sap.ui.model.json.JSONModel({
						data: odata
					});

					this.byId("header").setModel(ClaimModel);
					this.byId("header").bindElement({
						path: "/data"
					});

					this.byId("particular").setModel(ClaimModel);
					this.byId("particular").bindElement({
						path: "/data"
					});

					this.byId("participantShelterChildren").setModel(ClaimModel);
					this.byId("participantShelterChildren").bindElement({
						path: "/data"
					});

					this.byId("particularShelterWoman").setModel(ClaimModel);
					this.byId("particularShelterWoman").bindElement({
						path: "/data"
					});

					this.byId("particularServiceCentre").setModel(ClaimModel);
					this.byId("particularServiceCentre").bindElement({
						path: "/data"
					});

					this.byId("particularsChildrenHome").setModel(ClaimModel);
					this.byId("particularsChildrenHome").bindElement({
						path: "/data"
					});

					this.byId("particularsPlaces").setModel(ClaimModel);
					this.byId("particularsPlaces").bindElement({
						path: "/data"
					});

					this.byId("particularsPatient").setModel(ClaimModel);
					this.byId("particularsPatient").bindElement({
						path: "/data"
					});

					this.byId("particularsHomePeopleDis").setModel(ClaimModel);
					this.byId("particularsHomePeopleDis").bindElement({
						path: "/data"
					});

					this.byId("particularsHBCAged").setModel(ClaimModel);
					this.byId("particularsHBCAged").bindElement({
						path: "/data"
					});

					this.SWPModel.getData().data = [];
					this.SummaryStaffyModel.getData().data = [];
					this.HomesForPersonsModel.getData().data = [];
					this.SpecialServiceModel.getData().data = [];
					this.ClaimsModel.getData().data = [];
					this.AgeingModel.getData().data = [];
					this.AwarenessModel.getData().data = [];
					this.HBCModel.getData().data = [];
					//this.AttendanceModel.getData().data = [];
					this.PlacesModel.getData().data = [];
					this.ChildrenHomeModel.getData().data = [];
					this.BeneficiaryModel.getData().data = [];
					this.ProctiveWorkshopModel.getData().data = [];
					this.HBCAnnexBModel.getData().data = [];
					this.AnnexureAModel.getData().data = [];

					//this.RestoreModels();

					this.getCapacities(this.oProperty.Guid);

					this.formatUI(odata.ClaimType);

				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve application details");
				}.bind(this)
			});
		},

		RestoreModels: function(oEvent) {

			var oTableAnnexureA = this.byId("tblhbcaAnnexA"),
				oTableAnnexB = this.byId("tblAnnexB"),
				oTableProtWorkshop = this.byId("tblProtWorkshop"),
				oTableHomePerson = this.byId("tblHPN"),
				oTableSpecialServices = this.byId("tblSpecialServices"),
				oTableClaimForm = this.byId("tblipcClaimForm"),
				oTableAgeing = this.byId("tblAAgeing"),
				oTableAwareness = this.byId("tblhbcaAwareness"),
				oTableHBC = this.byId("tlbHbcSummary"),
				oTablePlaceSafety = this.byId("tblCHPlaceofSafety"),
				oTableChildHome = this.byId("tblCHbeneficiaries"),
				oTableBeneficiary = this.byId("beneficiaries"),
				oTableStaffSummary = this.byId("tblSWPstaffsummary"),
				oTableSWP = this.byId("tblSWPdisability");

			oTableSWP.setModel();
			oTableSWP.setModel(this.SWPModel, "SocialWorkPostModel");
			oTableSWP.getModel("SocialWorkPostModel").refresh(true);

			oTableStaffSummary.setModel();
			oTableStaffSummary.setModel(this.SummaryStaffyModel, "StaffSummaryPostModel");
			oTableStaffSummary.getModel("StaffSummaryPostModel").refresh(true);

			oTableBeneficiary.setModel();
			oTableBeneficiary.setModel(this.BeneficiaryModel, "BeneficiaryPostModel");
			oTableBeneficiary.getModel("BeneficiaryPostModel").refresh(true);

			oTableChildHome.setModel();
			oTableChildHome.setModel(this.ChildrenHomeModel, "ChildrenHomeModel");
			oTableChildHome.getModel("ChildrenHomeModel").refresh(true);

			oTablePlaceSafety.setModel();
			oTablePlaceSafety.setModel(this.PlacesModel, "PlacesModel");
			oTablePlaceSafety.getModel("PlacesModel").refresh(true);

			oTableHBC.setModel();
			oTableHBC.setModel(this.HBCModel, "HBCModel");
			oTableHBC.getModel("HBCModel").refresh(true);

			oTableAwareness.setModel();
			oTableAwareness.setModel(this.AwarenessModel, "AwarenessModel");
			oTableAwareness.getModel("AwarenessModel").refresh(true);

			oTableAgeing.setModel();
			oTableAgeing.setModel(this.AgeingModel, "AgeingModel");
			oTableAgeing.getModel("AgeingModel").refresh(true);

			oTableClaimForm.setModel();
			oTableClaimForm.setModel(this.ClaimsModel, "ClaimsModel");
			oTableClaimForm.getModel("ClaimsModel").refresh(true);

			oTableSpecialServices.setModel();
			oTableSpecialServices.setModel(this.SpecialServiceModel, "SpecialServiceModel");
			oTableSpecialServices.getModel("SpecialServiceModel").refresh(true);

			oTableHomePerson.setModel();
			oTableHomePerson.setModel(this.HomesForPersonsModel, "HomesForPersonsModel");
			oTableHomePerson.getModel("HomesForPersonsModel").refresh(true);

			oTableProtWorkshop.setModel();
			oTableProtWorkshop.setModel(this.ProctiveWorkshopModel, "ProtectiveWorkshopModel");
			oTableProtWorkshop.getModel("ProtectiveWorkshopModel").refresh(true);

			sap.ui.core.BusyIndicator.hide();

		},

		distrubuteCapacity: function(arrCapacity) {
			for (var capacity = 0; capacity < arrCapacity.length; capacity++) {

				switch (arrCapacity[capacity].Zztype) {
					case "SWP":
						this.SWPModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "BENEF":
						this.BeneficiaryModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "CHILD":
						this.ChildrenHomeModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "CLAIM":
						this.ClaimsModel.getData().data.push(arrCapacity.data[capacity]);
						break;
					case "SUMMA":
						this.SummaryStaffyModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "PLACE":
						this.PlacesModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "HBC":
						this.HBCModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "AWARE":
						this.AwarenessModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "AGE":
						this.AgeingModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "SPEC":
						this.SpecialServiceModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "HOME":
						this.HomesForPersonsModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "PROT":
						this.ProctiveWorkshopModel.getData().data.push(arrCapacity[capacity]);
						break;
				}
			}

			this.RestoreModels();

		},

		getCapacities: function(vGuid) {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("RecordId", "EQ", vGuid);

			this._oODataModel.read("/GetCapacitySet", {
				filters: [oFilter],
				success: function(odata) {

					//Distribute capacity data
					this.distrubuteCapacity(odata.results);
					this.getClaimAnnexureA(vGuid);
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve capacity details");
				}.bind(this)
			});
		},

		getClaimAnnexureA: function(vGuid) {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("RecordId", "EQ", vGuid);
			var oTable = this.byId("tblhbcaAwareness");

			this._oODataModel.read("/GetClaimAnnexureASet", {
				filters: [oFilter],
				success: function(odata) {
					this.AnnexureAModel.getData().data = odata.results;
					oTable.setModel();
					oTable.setModel(this.AnnexureAModel, "AnnexAModel");
					oTable.getModel("AnnexAModel").refresh(true);

					this.getClaimAnnexureB(vGuid);
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve capacity details");
				}.bind(this)
			});
		},

		getClaimAnnexureB: function(vGuid) {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("RecordId", "EQ", vGuid);
			var oTable = this.byId("tblAnnexB");

			this._oODataModel.read("/GetClaimAnnexureBSet", {
				filters: [oFilter],
				success: function(odata) {
					this.HBCAnnexBModel.getData().data = odata.results;
					oTable.setModel();
					oTable.setModel(this.HBCAnnexBModel, "HBCAnnexModel");
					oTable.getModel("HBCAnnexModel").refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve capacity details");
				}.bind(this)
			});
		},

		formatUI: function(vFormNo) {

			if (vFormNo !== "") {
				switch (vFormNo) {
					case "1":
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("beneficiaries").setVisible(false);
						this.byId("awareness").setVisible(false);
						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(false);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(false);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("annexureA").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcsummary").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);

						this.byId("particularsChildrenHome").setVisible(true);
						this.byId("childrenHome").setVisible(true);
						this.byId("places").setVisible(true);
						this.byId("summary").setVisible(true);
						this.byId("header").setTitle("Children's Home");
						break;

					case "2":

						this.byId("participantShelterChildren").setVisible(true);
						this.byId("annexureA").setVisible(true);
						this.byId("beneficiaries").setVisible(true);
						this.byId("summary").setVisible(true);

						this.byId("attendence").setVisible(false);
						this.byId("awareness").setVisible(false);
						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(false);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(false);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcsummary").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);

						this.byId("header").setTitle("Shelter For Children");
						break;

					case "3":
						this.byId("particularShelterWoman").setVisible(true);
						this.byId("attendence").setVisible(false);
						this.byId("beneficiaries").setVisible(true);
						this.byId("summary").setVisible(true);
						this.byId("annexureA").setVisible(true);
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("awareness").setVisible(false);
						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(false);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(false);

						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcsummary").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("header").setTitle("Shelter For Women");
						break;

					case "4":
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("summary").setVisible(true);
						this.byId("beneficiaries").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(false);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(false);
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("ageing").setVisible(true);
						this.byId("hbcsummary").setVisible(true);
						this.byId("particularsHBCAged").setVisible(true);
						this.byId("annexureA").setVisible(true);
						this.byId("hbcannex").setVisible(true);
						this.byId("annexureA").setVisible(true);
						this.byId("awareness").setVisible(true);
						this.byId("header").setTitle("Home Based Care - Older Persons");
						break;

					case "5":
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("summary").setVisible(true);

						this.byId("ageing").setVisible(false);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("beneficiaries").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("hbcsummary").setVisible(false);

						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(false);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(false);
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(true);
						this.byId("personNeeds").setVisible(true);
						this.byId("specialServices").setVisible(true);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("annexureA").setVisible(false);
						this.byId("awareness").setVisible(false);
						this.byId("header").setTitle("Homes for People with Disabilities");
						break;

					case "7":
						this.byId("particularsPatient").setVisible(true);
						this.byId("claim").setVisible(true);
						this.byId("summary").setVisible(true);
						this.byId("awareness").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("beneficiaries").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("hbcsummary").setVisible(false);

						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(false);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(false);
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("annexureA").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("header").setTitle("In-Patient Centre");
						break;

					case "8":
						this.byId("particularsPatient").setVisible(true);
						this.byId("claim").setVisible(true);
						this.byId("summary").setVisible(true);

						this.byId("ageing").setVisible(false);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("beneficiaries").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("hbcsummary").setVisible(false);

						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(false);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(false);
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("annexureA").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("header").setTitle("Out-Patient Centre");
						break;

					case "9":
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("annexureA").setVisible(true);
						this.byId("summary").setVisible(true);
						this.byId("beneficiaries").setVisible(true);
						this.byId("awareness").setVisible(false);
						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(false);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(false);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcsummary").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularsPlaces").setVisible(true);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("header").setTitle("Places Of Care (Creches)");
						break;

					case "10":
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("summary").setVisible(true);

						this.byId("ageing").setVisible(false);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("beneficiaries").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(false);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(false);
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(true);
						this.byId("particularsProtectWorkshop").setVisible(true);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("annexureA").setVisible(false);
						this.byId("hbcsummary").setVisible(false);
						this.byId("awareness").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("header").setTitle("Programme: Protective Workshops");
						break;

					case "11":
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("annexureA").setVisible(true);
						this.byId("summary").setVisible(true);
						this.byId("hbcsummary").setVisible(true);
						this.byId("hbcannex").setVisible(true);
						this.byId("beneficiaries").setVisible(true);
						this.byId("particularServiceCentre").setVisible(true);
						this.byId("awareness").setVisible(false);
						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(false);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(false);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("header").setTitle("Programme: Service Centers and Luncheon Clubs");
						break;

					case "12":
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("summary").setVisible(true);
						this.byId("beneficiaries").setVisible(false);
						this.byId("awareness").setVisible(false);
						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(true);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(true);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("annexureA").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcsummary").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("header").setTitle("Social Work Posts - Disability");
						break;
					case "13":
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("summary").setVisible(false);
						this.byId("beneficiaries").setVisible(false);
						this.byId("awareness").setVisible(false);
						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(true);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(true);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("annexureA").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcsummary").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("header").setTitle("Social Work Posts - Children");
						break;
					case "14":
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("summary").setVisible(false);
						this.byId("beneficiaries").setVisible(false);
						this.byId("awareness").setVisible(false);
						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(true);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(true);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("annexureA").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcsummary").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("header").setTitle("Social Work Posts - Aged");
						break;
					case "15":
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("summary").setVisible(false);
						this.byId("beneficiaries").setVisible(true);
						this.byId("awareness").setVisible(false);
						this.byId("service").setVisible(true);
						this.byId("swposts").setVisible(false);
						this.byId("other").setVisible(true);
						this.byId("particular").setVisible(true);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("annexureA").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcsummary").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("header").setTitle("Social Work Posts - Crime Prevention");
						break;
					case "16":
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("summary").setVisible(false);
						this.byId("beneficiaries").setVisible(true);
						this.byId("awareness").setVisible(false);
						this.byId("service").setVisible(true);
						this.byId("swposts").setVisible(true);
						this.byId("other").setVisible(true);
						this.byId("particular").setVisible(true);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("annexureA").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcsummary").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("header").setTitle("Social Work Posts - Families");
						break;
					case "17":
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("summary").setVisible(false);
						this.byId("beneficiaries").setVisible(false);
						this.byId("awareness").setVisible(false);
						this.byId("service").setVisible(true);
						this.byId("swposts").setVisible(true);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(true);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("annexureA").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcsummary").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("header").setTitle("Social Work Posts - Substance Abuse");
						break;
					case "18":
						this.byId("participantShelterChildren").setVisible(false);
						this.byId("attendence").setVisible(false);
						this.byId("summary").setVisible(false);
						this.byId("beneficiaries").setVisible(false);
						this.byId("awareness").setVisible(false);
						this.byId("service").setVisible(false);
						this.byId("swposts").setVisible(true);
						this.byId("other").setVisible(false);
						this.byId("particular").setVisible(true);
						this.byId("particularShelterWoman").setVisible(false);
						this.byId("particularsPatient").setVisible(false);
						this.byId("claim").setVisible(false);
						this.byId("particularsHomePeopleDis").setVisible(false);
						this.byId("personNeeds").setVisible(false);
						this.byId("specialServices").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("protectiveWorkshop").setVisible(false);
						this.byId("particularsProtectWorkshop").setVisible(false);
						this.byId("particularsHBCAged").setVisible(false);
						this.byId("annexureA").setVisible(false);
						this.byId("particularServiceCentre").setVisible(false);
						this.byId("hbcsummary").setVisible(false);
						this.byId("hbcannex").setVisible(false);
						this.byId("ageing").setVisible(false);
						this.byId("particularsPlaces").setVisible(false);
						this.byId("particularsChildrenHome").setVisible(false);
						this.byId("childrenHome").setVisible(false);
						this.byId("places").setVisible(false);
						this.byId("header").setTitle("Social Work Posts - VEP");
						break;
				}
			} else {
				MessageBox.error("This claim was not submitted", {
					icon: sap.m.MessageBox.Icon.CONFIRMATION,
					title: "Confirmation",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function(oAction) {
						if (oAction === "OK") {
							this.onMonthlyClaims();
							return;
						}
					}.bind(this)
				});
			}
		},

		onPressSWPost: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogSocialWorkPost = this.createFormDialog("gdsd.Claims_Processing.view.fragment.SocialWorkPosts");

			this._DialogSocialWorkPost.setModel(this.SWPModel);
			this._DialogSocialWorkPost.bindElement(oBindingContextPath);

			this._DialogSocialWorkPost.open();

		},

		onPressHBCAnnexB: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogHCBAnnexB = this.createFormDialog("gdsd.Claims_Processing.view.fragment.HBCAnnexB");

			this._DialogHCBAnnexB.setModel(this.HBCAnnexBModel);
			this._DialogHCBAnnexB.bindElement(oBindingContextPath);

			this._DialogHCBAnnexB.open();

		},

		onPressSpecialServices: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogSpecialServices = this.createFormDialog("gdsd.Claims_Processing.view.fragment.SpecialServices");

			this._DialogSpecialServices.setModel(this.SpecialServiceModel);
			this._DialogSpecialServices.bindElement(oBindingContextPath);

			this._DialogSpecialServices.open();

		},

		onPressSummaryStaff: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogSummary = this.createFormDialog("gdsd.Claims_Processing.view.fragment.SummaryOfStaff");

			this._DialogSummary.setModel(this.SummaryStaffyModel);
			this._DialogSummary.bindElement(oBindingContextPath);

			this._DialogSummary.open();

		},

		onPressBeneficiary: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogBeneficiary = this.createFormDialog("gdsd.Claims_Processing.view.fragment.Beneficiary");

			this._DialogBeneficiary.setModel(this.BeneficiaryModel);
			this._DialogBeneficiary.bindElement(oBindingContextPath);

			this._DialogBeneficiary.open();

		},

		onPressChildrenHome: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogChildren = this.createFormDialog("gdsd.Claims_Processing.view.fragment.ChildrenHome");

			this._DialogChildren.setModel(this.ChildrenHomeModel);
			this._DialogChildren.bindElement(oBindingContextPath);

			this._DialogChildren.open();

		},

		onPressHBCSummary: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogHBC = this.createFormDialog("gdsd.Claims_Processing.view.fragment.HBCSummary");

			this._DialogHBC.setModel(this.HBCModel);
			this._DialogHBC.bindElement(oBindingContextPath);

			this._DialogHBC.open();

		},

		onPressHomesForPerson: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogHomesPersons = this.createFormDialog("gdsd.Claims_Processing.view.fragment.HomeForPersons");

			this._DialogHomesPersons.setModel(this.HomesForPersonsModel);
			this._DialogHomesPersons.bindElement(oBindingContextPath);

			this._DialogHomesPersons.open();

		},

		onPressPlaces: function(oEvent) {
			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogPlaces = this.createFormDialog("gdsd.Claims_Processing.view.fragment.PlacesOfStay");

			this._DialogPlaces.setModel(this.PlacesModel);
			this._DialogPlaces.bindElement(oBindingContextPath);

			this._DialogPlaces.open();

		},

		onPressAwareness: function(oEvent) {
			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogAwareness = this.createFormDialog("gdsd.Claims_Processing.view.fragment.Awareness");

			this._DialogAwareness.setModel(this.AwarenessModel);
			this._DialogAwareness.bindElement(oBindingContextPath);

			this._DialogAwareness.open();

		},

		onPressAgeing: function(oEvent) {
			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogAgeing = this.createFormDialog("gdsd.Claims_Processing.view.fragment.ActiveAgeing");

			this._DialogAgeing.setModel(this.AgeingModel);
			this._DialogAgeing.bindElement(oBindingContextPath);

			this._DialogAgeing.open();

		},

		onPressClaim: function(oEvent) {
			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogClaim = this.createFormDialog("gdsd.Claims_Processing.view.fragment.ClaimForm");

			this._DialogClaim.setModel(this.ClaimsModel);
			this._DialogClaim.bindElement(oBindingContextPath);

			this._DialogClaim.open();

		},

		onPressProtectiveWorkshops: function(oEvent) {
			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogProtective = this.createFormDialog("gdsd.Claims_Processing.view.fragment.ProtectiveWorkshops");

			this._DialogProtective.setModel(this.ProctiveWorkshopModel);
			this._DialogProtective.bindElement(oBindingContextPath);

			this._DialogProtective.open();

		},

		onPressAnnexureA: function(oEvent) {
			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogAnnexureA = this.createFormDialog("gdsd.Claims_Processing.view.fragment.AnnexureA");

			this._DialogAnnexureA.setModel(this.AnnexureAModel);
			this._DialogAnnexureA.bindElement(oBindingContextPath);

			this._DialogAnnexureA.open();

		},

		onNavBack: function() {
			this.Router.navTo("ClaimsProcess");
		},

		onProcess: function() {
			this.Router.navTo("Process", {
				//prepare object path to be passed on to target
				Path: window.encodeURIComponent(this.sPath.substr(1))
			});
		},
		
		onMonthlyClaims: function() {
			this.Router.navTo("ClaimsProcess", {
				Path: window.encodeURIComponent(this.MonthlyClaimPath.substr(1))
			});
		}

	});

});