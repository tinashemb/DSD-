sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/Text"
], function (BaseController, MessageBox, Dialog, DialogType, Button, ButtonType, Text) {
	"use strict";

	return BaseController.extend("gdsd.Claims_Processing.controller.Process", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.Claims_Processing.view.Process
		 */
		onInit: function () {

			this._claimsModel = this.getOwnerComponent().getModel("ClaimsProcessing");
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this._mViewSettingsDialogs = {};

			this.Router.getRoute("Process").attachPatternMatched(this._onObjectMatched, this);

		},

		_onObjectMatched: function (oEvent) {
			this.sPath = "/" + window.decodeURIComponent(oEvent.getParameter("arguments").Path);
			this.Property = this._claimsModel.getProperty(this.sPath);

			var ClaimsProcessModel = new sap.ui.model.json.JSONModel({
				data: this.Property
			});

			//Set Binding Mode
			ClaimsProcessModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

			this.byId("notes").setModel(ClaimsProcessModel);
			this.byId("notes").bindElement({
				path: "/data"
			});

			this.getView().setModel(ClaimsProcessModel);

			this.formatUI(this.Property.TaskType);
		},

		formatUI: function (vTaskType) {

			switch (vTaskType) {
			case "ZT21":
			case "ZT24":
				this.byId("zt21").setVisible(true);
				this.byId("zt22").setVisible(false);
				this.byId("zt23").setVisible(false);
				this.byId("zt21").setEnabled(true);
				this.byId("btnProcessSubmit").setVisible(true);
				this.byId("btnProcessApprove").setVisible(false);
				this.byId("btnProcessReject").setVisible(false);
				this.byId("HdrProcess").setTitle("Quartely Report");
				break;
			case "ZT22":
				this.byId("zt21").setVisible(true);
				this.byId("zt22").setVisible(true);
				this.byId("zt23").setVisible(false);
				this.byId("zt21").setEnabled(false);
				this.byId("zt22").setEnabled(true);
				this.byId("btnProcessSubmit").setVisible(true);
				this.byId("btnProcessApprove").setVisible(false);
				this.byId("btnProcessReject").setVisible(false);
				this.byId("HdrProcess").setTitle("6 Montly Report");
				break;
			case "ZT23":
				this.byId("zt21").setVisible(true);
				this.byId("zt22").setVisible(true);
				this.byId("zt23").setVisible(true);
				this.byId("zt21").setEnabled(false);
				this.byId("zt22").setEnabled(false);
				this.byId("zt23").setEnabled(true);
				this.byId("btnProcessSubmit").setVisible(true);
				this.byId("btnProcessApprove").setVisible(false);
				this.byId("btnProcessReject").setVisible(false);
				this.byId("HdrProcess").setTitle("Multi-Task Team");
				break;
			}
		},

		onNavBack: function () {

			this.Router.navTo("Claim", {
				//prepare object path to be passed on to target
				Path: window.encodeURIComponent(this.sPath.substr(1))
			});
		},

		onApproveTask: function () {
			if (!this.oApproveDialog) {
				this.oApproveDialog = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({
						text: "Are you sure you want to Approve the task?"
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Approve",
						press: function () {
							this.getView().getModel().getData().data.Status = "E0003";
							this.onUpdate();
							this.oApproveDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oApproveDialog.close();
						}.bind(this)
					})
				});
			}

			this.oApproveDialog.open();

		},
		onRejectTask: function () {
			if (!this.oRejectDialog) {
				this.oRejectDialog = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({
						text: "Are you sure you want to Reject the task?"
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Reject",
						press: function () {
							this.getView().getModel().getData().data.Status = "E0007";
							this.onUpdate();
							this.oRejectDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oRejectDialog.close();
						}.bind(this)
					})
				});
			}

			this.oRejectDialog.open();

		},

		onUpdate: function () {
			sap.ui.core.BusyIndicator.show(0);
			var oProperties = this.getView().getModel().getData().data;
			this._oODataModel.update("/GetClaimsProcessingSet(Guid='" + oProperties.Guid + "',ObjectId='" +
				oProperties.ObjectId + "')", oProperties, {

					success: function (results) {

						sap.ui.core.BusyIndicator.hide();
						this.successAndNavigate();

					}.bind(this),
					error: function (results) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error("Error occured while trying to process a claim");
					}

				});
		},

		successAndNavigate: function (oEvent) {

			MessageBox.success("Task " + this.Property.ObjectId + " has been successfully updated", {
				icon: sap.m.MessageBox.Icon.CONFIRMATION,
				title: "Confirmation",
				actions: [sap.m.MessageBox.Action.OK],
				onClose: function (oAction) {
					if (oAction === "OK") {
						this.Router.navTo("ClaimsProcess");
						return;
					}
				}.bind(this)
			});
		},

		onSubmit: function () {
			this.getView().getModel().getData().data.Status = "E0003";
			this.onUpdate();
		}
		
	});

});