sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox",
	"sap/ui/Device",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/MessageToast",
	"sap/m/Text"
], function(BaseController, MessageBox, Device, Filter, FilterOperator, Fragment, Dialog, DialogType, Button, ButtonType, MessageToast,
	Text) {
	"use strict";

	return BaseController.extend("gdsd.Claims_Processing.controller.MEProcess", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.Claims_Processing.view.SWProcess
		 */
		onInit: function() {
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this.QuarterlyClaims = this.getOwnerComponent().getModel("QuarterlyClaims");

			var oViewModel = new sap.ui.model.json.JSONModel({
				totalAmount: 0
			});

			this.ProductsModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.getView().setModel(oViewModel, "ViewModel");
			this.Router.getRoute("MEProcess").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function(oEvent) {
			this.sPath = "/" + window.decodeURIComponent(oEvent.getParameter("arguments").Path);
			this.Property = this.QuarterlyClaims.getProperty(this.sPath);
			//this.byId("SubmitButton").setVisible(false);

			this.Property.NPIFlagM = "X";

			var ClaimProcessModel = new sap.ui.model.json.JSONModel({
				data: this.Property
			});

			//Set Binding Mode
			ClaimProcessModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

			this.getView().setModel(ClaimProcessModel);

			this.byId("previous").setModel(ClaimProcessModel);
			this.byId("previous").bindElement({
				path: "/data"
			});
			this.byId("financial").setModel(ClaimProcessModel);
			this.byId("financial").bindElement({
				path: "/data"
			});
			this.byId("assets").setModel(ClaimProcessModel);
			this.byId("assets").bindElement({
				path: "/data"
			});
			this.byId("financialcost").setModel(ClaimProcessModel);
			this.byId("financialcost").bindElement({
				path: "/data"
			});
			this.byId("overall").setModel(ClaimProcessModel);
			this.byId("overall").bindElement({
				path: "/data"
			});

			switch (this.Property.TaskType) {
				case "ZT23":
					this.byId("me_prevfin").setVisible(true);
					this.byId("sup_prevfin").setVisible(false);
					this.byId("me_finplan").setVisible(true);
					this.byId("sup_finplan").setVisible(false);
					this.byId("me_assetsproc").setVisible(true);
					this.byId("sup_assetsproc").setVisible(false);
					this.byId("me_fincost").setVisible(true);
					this.byId("sup_fincost").setVisible(false);
					this.byId("me_overallapp").setVisible(true);
					this.byId("sup_overallapp").setVisible(false);
					this.byId("score").setVisible(true);
					this.byId("GroupA").setVisible(true);
					this.byId("sup_score1").setVisible(false);
					this.byId("sup_score2").setVisible(false);
					this.byId("recommend1").setVisible(false);
					this.byId("recommend2").setVisible(false);
					this.byId("recommend").setVisible(true);
					this.byId("GroupB").setVisible(true);
					this.byId("SubmitButton").setVisible(false);
					this.byId("ApproveButton").setVisible(false);
					this.byId("RejectButton").setVisible(false);

					this.byId("npi_prevfin").setVisible(false);
					this.byId("npi_finplan").setVisible(false);
					this.byId("npi_assetsproc").setVisible(false);
					this.byId("npi_fincost").setVisible(false);
					this.byId("npi_overallapp").setVisible(false);

					this.byId("me_prevfin").setEnabled(true);
					this.byId("me_finplan").setEnabled(true);
					this.byId("me_assetsproc").setEnabled(true);
					this.byId("me_fincost").setEnabled(true);
					this.byId("me_overallapp").setEnabled(true);
					break;
				case "ZT27":
					this.byId("me_prevfin").setVisible(true);
					this.byId("sup_prevfin").setVisible(true);
					this.byId("me_finplan").setVisible(true);
					this.byId("sup_finplan").setVisible(true);
					this.byId("me_assetsproc").setVisible(true);
					this.byId("sup_assetsproc").setVisible(true);
					this.byId("me_fincost").setVisible(true);
					this.byId("sup_fincost").setVisible(true);
					this.byId("me_overallapp").setVisible(true);
					this.byId("sup_overallapp").setVisible(true);
					this.byId("score").setVisible(false);
					this.byId("GroupA").setVisible(false);
					this.byId("sup_score1").setVisible(true);
					this.byId("sup_score2").setVisible(true);
					this.byId("recommend1").setVisible(true);
					this.byId("recommend2").setVisible(true);
					this.byId("recommend").setVisible(false);
					this.byId("GroupB").setVisible(false);

					this.byId("SubmitButton").setVisible(true);
					this.byId("ApproveButton").setVisible(false);
					this.byId("RejectButton").setVisible(false);

					this.byId("npi_prevfin").setVisible(false);
					this.byId("npi_finplan").setVisible(false);
					this.byId("npi_assetsproc").setVisible(false);
					this.byId("npi_fincost").setVisible(false);
					this.byId("npi_overallapp").setVisible(false);

					this.byId("me_prevfin").setEnabled(false);
					this.byId("me_finplan").setEnabled(false);
					this.byId("me_assetsproc").setEnabled(false);
					this.byId("me_fincost").setEnabled(false);
					this.byId("me_overallapp").setEnabled(false);
					break;
				case "ZT28":
					this.byId("me_prevfin").setVisible(true);
					this.byId("sup_prevfin").setVisible(true);
					this.byId("me_finplan").setVisible(true);
					this.byId("sup_finplan").setVisible(true);
					this.byId("me_assetsproc").setVisible(true);
					this.byId("sup_assetsproc").setVisible(true);
					this.byId("me_fincost").setVisible(true);
					this.byId("sup_fincost").setVisible(true);
					this.byId("me_overallapp").setVisible(true);
					this.byId("sup_overallapp").setVisible(true);
					this.byId("score").setVisible(false);
					this.byId("GroupA").setVisible(false);
					this.byId("sup_score1").setVisible(true);
					this.byId("sup_score2").setVisible(true);
					this.byId("recommend1").setVisible(true);
					this.byId("recommend2").setVisible(true);
					this.byId("recommend").setVisible(false);
					this.byId("GroupB").setVisible(false);

					this.byId("SubmitButton").setVisible(false);
					this.byId("ApproveButton").setVisible(false);
					this.byId("RejectButton").setVisible(false);

					this.byId("npi_prevfin").setVisible(true);
					this.byId("npi_finplan").setVisible(true);
					this.byId("npi_assetsproc").setVisible(true);
					this.byId("npi_fincost").setVisible(true);
					this.byId("npi_overallapp").setVisible(true);

					this.byId("me_prevfin").setEnabled(false);
					this.byId("me_finplan").setEnabled(false);
					this.byId("me_assetsproc").setEnabled(false);
					this.byId("me_fincost").setEnabled(false);
					this.byId("me_overallapp").setEnabled(false);

					this.byId("sup_prevfin").setEnabled(false);
					this.byId("sup_finplan").setEnabled(false);
					this.byId("sup_assetsproc").setEnabled(false);
					this.byId("sup_fincost").setEnabled(false);
					this.byId("sup_overallapp").setEnabled(false);
					break;
			}
			this.getProducts(this.Property.parent_guid);
		},

		getProducts: function(vGuid) {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("Applicationguid", "EQ", vGuid);
			var oTable = this.byId("LineItemsTable2");
			//	oTable2 = this.byId("LineItemsTable2");

			this._oODataModel.read("/GetApplicationItemsSet", {
				filters: [oFilter],
				success: function(odata) {
					// var ProductsModel = new sap.ui.model.json.JSONModel({
					// 	data: odata.results
					// });

					this.ProductsModel.getData().data = odata.results;

					oTable.setModel();
					oTable.setModel(this.ProductsModel, "ProductLineItemsModel");
					oTable.getModel("ProductLineItemsModel").refresh(true);

					this.countGrandTotal();
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve product details");
				}.bind(this)
			});
		},

		onSubmit: function() {
			if (this.getView().getModel().getData().data.TaskType === "ZT23") {
				if (!this.oInspectionDialog) {
					this.oInspectionDialog = new Dialog({
						type: DialogType.Message,
						title: "Confirm",
						content: new Text({
							text: "Is an inspection required?"
						}),
						customHeader: [
							new sap.m.Bar({
								contentRight: new sap.ui.core.Icon({
									type: ButtonType.Reject,
									text: "Confirm",
									src: "sap-icon://decline",
									useIconTooltip: false,
									color: "#f33334",
									press: function(oEvent) {
										this.oInspectionDialog.close();
										this.oInspectionDialog = null;
									}.bind(this)
								}).addStyleClass("sapUiMediumMarginBottom"),
								contentMiddle: [
									new sap.m.Title({
										text: "Confirm"
									}),
									new sap.ui.core.Icon({
										src: "sap-icon://message-warning",
										useIconTooltip: false,
										color: "#E69A17"
									})
								]
							})

						],
						beginButton: new Button({
							type: ButtonType.Emphasized,
							text: "Yes",
							press: function() {
								this.getView().getModel().getData().data.Status = "E0019";
								this.onUpdateClaim();
								this.oInspectionDialog.close();
							}.bind(this)
						}),
						endButton: new Button({
							text: "No",
							press: function() {
								this.getView().getModel().getData().data.Status = "E0027";
								this.onUpdateClaim();
								this.oInspectionDialog.close();
							}.bind(this)
						})

					});
				}

				this.oInspectionDialog.open();
			} else {
				this.getView().getModel().getData().data.Status = "E0019";
				this.onUpdateClaim();
			}
		},

		onUpdateClaim: function() {
			sap.ui.core.BusyIndicator.show(0);
			var oProperties = this.getView().getModel().getData().data;

			if (oProperties.TaskType === "ZT23") {
				switch (this.byId("GroupA").getSelectedIndex()) {
					case 0:
						oProperties.Zgc8 = "Low";
						break;
					case 1:
						oProperties.Zgc8 = "Medium";
						break;
					case 2:
						oProperties.Zgc8 = "High";
						break;
				}

				switch (this.byId("GroupB").getSelectedIndex()) {
					case 0:
						oProperties.Zgf7 = "Yes";
						break;
					case 1:
						oProperties.Zgf7 = "No";
						break;
				}
			}

			if (oProperties.TaskType === "ZT28" && oProperties.NPIFlagP !== "X") {
				MessageBox.error("Please also review Monitoring and Evaluation section before processing");
				return;
			}

			this._oODataModel.update("/GetClaimsProcessingSet(Guid='" + oProperties.Guid + "',ObjectId='" + oProperties.ObjectId + "')",
				oProperties, {
					success: function(results) {
						sap.ui.core.BusyIndicator.hide();
						this.successAndNavigate();
					}.bind(this),
					error: function(results) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error("Error occured while trying to process a claim");
					}

				});
		},

		successAndNavigate: function() {

			MessageBox.success("Claim " + this.Property.ObjectId + " has been successfully updated", {
				icon: sap.m.MessageBox.Icon.CONFIRMATION,
				title: "Confirmation",
				actions: [sap.m.MessageBox.Action.OK],
				onClose: function(oAction) {
					if (oAction === "OK") {
						this.Router.navTo("QuarterlyClaims");
						return;
					}
				}.bind(this)
			});
		},

		onApprove: function() {
			if (!this.oApproveDialog) {
				this.oApproveDialog = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({
						text: "Are you sure you want to approve the claim?"
					}),
					customHeader: [
						new sap.m.Bar({
							contentRight: new sap.ui.core.Icon({
								type: ButtonType.Reject,
								text: "Confirm",
								src: "sap-icon://decline",
								useIconTooltip: false,
								color: "#f33334",
								press: function(oEvent) {
									this.oApproveDialog.close();
									this.oApproveDialog = null;
								}.bind(this)
							}).addStyleClass("sapUiMediumMarginBottom"),
							contentMiddle: [
								new sap.m.Title({
									text: "Confirm"
								}),
								new sap.ui.core.Icon({
									src: "sap-icon://message-warning",
									useIconTooltip: false,
									color: "#E69A17"
								})
							]
						})

					],
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Yes",
						press: function() {
							this.getView().getModel().getData().data.Status = "E0019";
							this.onUpdateClaim();
							this.oApproveDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "No",
						press: function() {
							this.oApproveDialog.close();
						}.bind(this)
					})
				});
			}

			this.oApproveDialog.open();
		},

		onReject: function() {
			if (!this.oRejectDialog) {
				this.oRejectDialog = new Dialog({
					type: DialogType.Message,
					title: "Reject",
					content: new Text({
						text: "Are you sure you want to reject the claim? A rejection letter will be sent to the NPO"
					}),
					customHeader: [
						new sap.m.Bar({
							contentRight: new sap.ui.core.Icon({
								type: ButtonType.Reject,
								text: "Reject",
								src: "sap-icon://decline",
								useIconTooltip: false,
								color: "#f33334",
								press: function(oEvent) {
									this.oRejectDialog.close();
									this.oRejectDialog = null;
								}.bind(this)
							}).addStyleClass("sapUiMediumMarginBottom"),
							contentMiddle: [
								new sap.m.Title({
									text: "Reject"
								}),
								new sap.ui.core.Icon({
									src: "sap-icon://message-warning",
									useIconTooltip: false,
									color: "#E69A17"
								})
							]
						})

					],
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Yes",
						press: function() {
							this.getView().getModel().getData().data.Status = "E0027";
							this.onUpdateClaim();
							this.oRejectDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "No",
						press: function() {
							this.oRejectDialog.close();
						}.bind(this)
					})
				});
			}

			this.oRejectDialog.open();
		},

		onProductsNextPress: function() {
			//this.byId("SubmitButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("previousfinancials");
			this.byId("me_processPage").scrollTo(0, 0);
		},

		onPreviousFinancialPerformancePrevPress: function() {
			//this.byId("SubmitButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("LineItems");
			this.byId("me_processPage").scrollTo(0, 0);
		},

		onPreviousFinancialPerformanceNextPress: function() {
			//this.byId("SubmitButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("financialPlanning");
			this.byId("me_processPage").scrollTo(0, 0);
		},

		onFinancialPlanningPrevPress: function() {
			//this.byId("SubmitButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("previousfinancials");
			this.byId("me_processPage").scrollTo(0, 0);
		},

		onFinancialPlanningNextPress: function() {
			//this.byId("SubmitButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("assets");
			this.byId("me_processPage").scrollTo(0, 0);
		},

		onAssetsProcuredPrevPress: function() {
			//this.byId("SubmitButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("financialPlanning");
			this.byId("me_processPage").scrollTo(0, 0);
		},

		onAssetsProcuredNextPress: function() {
			//this.byId("SubmitButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("financialcost");
			this.byId("me_processPage").scrollTo(0, 0);
		},

		onFinancialCostPrevPress: function() {
			//this.byId("SubmitButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("assets");
			this.byId("me_processPage").scrollTo(0, 0);
		},

		onFinancialCostNextPress: function() {
			
			this.byId("SubmitButton").setVisible(true);
			this.byId("ApproveButton").setVisible(false);
			this.byId("RejectButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("summary");
			this.byId("me_processPage").scrollTo(0, 0);
			
		},

		onSummaryPrevPress: function() {
			this.byId("SubmitButton").setVisible(false);
			this.byId("ApproveButton").setVisible(false);
			this.byId("RejectButton").setVisible(false);
			this.byId("IconBar").setSelectedKey("financialcost");
			this.byId("me_processPage").scrollTo(0, 0);
		},

		handleIconTabBarSelect: function(oEvent) {
			var sKey = oEvent.getParameter("key");

			if (sKey === "summary") {

				this.byId("ApproveButton").setVisible(true);
				this.byId("RejectButton").setVisible(true);
			} else {

				this.byId("ApproveButton").setVisible(false);
				this.byId("RejectButton").setVisible(false);
			}

		},

		countGrandTotal: function() {
			var oTotal = 0;

			for (var i = 0; i < this.ProductsModel.getData().data.length; i++) {
				oTotal = oTotal + parseFloat(this.ProductsModel.getData().data[i].Totalamount);
			}

			this.getView().getModel("ViewModel").setProperty("/totalAmount", oTotal);
		}

	});

});