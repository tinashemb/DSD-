sap.ui.define([
	"gdsd/Claims_Processing/test/unit/controller/ClaimsProcess.controller"
], function () {
	"use strict";
});