sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/Device",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/MessageToast",
	"sap/m/Text",
	"sap/ui/model/json/JSONModel"
], function(Controller, MessageBox, Device, Filter, FilterOperator, Fragment, Dialog, DialogType, Button, ButtonType, MessageToast, Text, JSONModel) {
	"use strict";

	return Controller.extend("gdsd.FundingApplicationProcess.ApplicationFundProcess.controller.SWMETechNPI_Processing", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.FundingApplicationProcess.ApplicationFundProcess.view.SWMETechNPI_Processing
		 */
		onInit: function() {
			this._processModel = this.getOwnerComponent().getModel("ApplicationProcessing");
			this._productModel = this.getOwnerComponent().getModel("ProductLineItems");
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this._mViewSettingsDialogs = {};

			this.TechCommiteeModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			
			var oViewModel = new JSONModel({
				totalAmount: 0
			});
			
			this.getView().setModel(oViewModel, "ViewModel");

			this.Router.getRoute("SWMETechNPI_Processing").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function(oEvent) {
			this.TaskType = oEvent.getParameter("arguments").TaskType;
			this.sPath = "/" + window.decodeURIComponent(oEvent.getParameter("arguments").Path);
			this.ApplicGuid = oEvent.getParameter("arguments").ApplicGuid;
			this.Property = this._processModel.getProperty(this.sPath);

			//this.TaskType = "ZT03";

			var ApplicationProcessModel = new sap.ui.model.json.JSONModel({
				data: this.Property
			});

			var oTable = this.byId("LineItemsTable"),
				oTable2 = this.byId("LineItemsTable");

			//Set Binding Mode
			ApplicationProcessModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

			this.byId("admincomp").setModel(ApplicationProcessModel);
			this.byId("admincomp").bindElement({
				path: "/data"
			});

			this.byId("progViability").setModel(ApplicationProcessModel);
			this.byId("progViability").bindElement({
				path: "/data"
			});

			this.byId("prevProg").setModel(ApplicationProcessModel);
			this.byId("prevProg").bindElement({
				path: "/data"
			});

			this.byId("prevFin").setModel(ApplicationProcessModel);
			this.byId("prevFin").bindElement({
				path: "/data"
			});

			// this.byId("overallRec").setModel(ApplicationProcessModel);
			// this.byId("overallRec").bindElement({
			// 	path: "/data"
			// });

			// this.byId("prevFinPerf").setModel(ApplicationProcessModel);
			// this.byId("prevFinPerf").bindElement({
			// 	path: "/data"
			// });

			this.byId("benefTrack").setModel(ApplicationProcessModel);
			this.byId("benefTrack").bindElement({
				path: "/data"
			});

			this.byId("benefTrack").setModel(ApplicationProcessModel);
			this.byId("benefTrack").bindElement({
				path: "/data"
			});

			this.byId("financialPlan").setModel(ApplicationProcessModel);
			this.byId("financialPlan").bindElement({
				path: "/data"
			});

			this.byId("assetsProc").setModel(ApplicationProcessModel);
			this.byId("assetsProc").bindElement({
				path: "/data"
			});

			this.byId("capacityBuild").setModel(ApplicationProcessModel);
			this.byId("capacityBuild").bindElement({
				path: "/data"
			});

			this.byId("overallApp").setModel(ApplicationProcessModel);
			this.byId("overallApp").bindElement({
				path: "/data"
			});

			this.byId("overallApp").setModel(ApplicationProcessModel);
			this.byId("overallApp").bindElement({
				path: "/data"
			});

			this.getView().setModel(ApplicationProcessModel);

			this.formatUI(this.TaskType);

			this._productModel.getData().data = [];

			oTable.setModel();
			oTable.setModel(this._productModel, "ProductLineItemsModel");
			oTable.getModel("ProductLineItemsModel").refresh(true);

			oTable2.setModel();
			oTable2.setModel(this._productModel, "ProductLineItemsModel2");
			oTable2.getModel("ProductLineItemsModel2").refresh(true);

			if (this.TaskType === "ZT01") {
				this.byId("SubmitButton").setVisible(true);
				this.byId("ApproveButton").setVisible(false);
				this.byId("RejectButton").setVisible(false);
			} else {
				this.byId("SubmitButton").setVisible(false);
				this.byId("ApproveButton").setVisible(false);
				this.byId("RejectButton").setVisible(false);
			}

			this.byId("IconBar").setSelectedKey("LineItems");
			this.byId("detailPage").scrollTo(0, 0);

			this.getProducts(this.ApplicGuid);

		},

		formatUI: function(vTaskType) {

			switch (vTaskType) {
				case "ZT01":

					this.byId("product").setVisible(true);
					this.byId("adminCompl").setVisible(false);
					this.byId("programme").setVisible(false);
					this.byId("previous").setVisible(false);
					this.byId("previousperfomance").setVisible(false);
					//					this.byId("overall").setVisible(false);
					//					this.byId("previousfinancial").setVisible(false);
					this.byId("beneficiariesTrackingTab").setVisible(false);
					this.byId("financialPlanningTab").setVisible(false);
					this.byId("assetsTab").setVisible(false);
					this.byId("capacityBTab").setVisible(false);
					this.byId("summaryTab").setVisible(false);
					this.byId("HdrProcess").setTitle("Social Work Evaluation");
					this.byId("ApproveButton").setVisible(false);
					this.byId("RejectButton").setVisible(false);
					this.byId("SubmitButton").setVisible(true);
					break;
				case "ZT03":
					this.byId("product").setVisible(true);
					this.byId("adminCompl").setVisible(true);
					this.byId("programme").setVisible(true);
					this.byId("previous").setVisible(true);
					this.byId("previousperfomance").setVisible(true);
					//					this.byId("overall").setVisible(true);
					//					this.byId("previousfinancial").setVisible(true);
					this.byId("beneficiariesTrackingTab").setVisible(true);
					this.byId("financialPlanningTab").setVisible(true);
					this.byId("assetsTab").setVisible(true);
					this.byId("capacityBTab").setVisible(true);

					//this.byId("products").setVisible(false);
					this.byId("HdrProcess").setTitle("Monitoring and Evaluation");
					this.byId("ApproveButton").setVisible(false);
					this.byId("RejectButton").setVisible(false);
					//this.byId("SubmitButton").setVisible(true);

					this.byId("adminComplME").setVisible(true);
					this.byId("adminComplME").setEnabled(true);
					this.byId("adminComplTC").setVisible(false);
					this.byId("adminComplNPI").setVisible(false);
					this.byId("programmeME").setVisible(true);
					this.byId("programmeME").setEnabled(true);
					this.byId("programmeTC").setVisible(false);
					this.byId("programmeNPI").setVisible(false);
					this.byId("previousME").setVisible(true);
					this.byId("previousME").setEnabled(true);
					this.byId("previousTC").setVisible(false);
					this.byId("previousNPI").setVisible(false);
					this.byId("previousperfomanceME").setVisible(true);
					this.byId("previousperfomanceME").setEnabled(true);
					this.byId("previousperfomanceTC").setVisible(false);
					this.byId("previousperfomanceNPI").setVisible(false);
					// this.byId("overallME").setVisible(true);
					// this.byId("overallME").setEnabled(true);
					// this.byId("overallTC").setVisible(false);
					// this.byId("overallNPI").setVisible(false);
					// this.byId("previousfinancialME").setVisible(true);
					// this.byId("previousfinancialME").setEnabled(true);
					// this.byId("previousfinancialTC").setVisible(false);
					// this.byId("previousfinancialNPI").setVisible(false);
					this.byId("beneficiariesTrackingTabME").setVisible(true);
					this.byId("beneficiariesTrackingTabME").setEnabled(true);
					this.byId("beneficiariesTrackingTabTC").setVisible(false);
					this.byId("beneficiariesTrackingTabNPI").setVisible(false);
					this.byId("financialPlanningTabME").setVisible(true);
					this.byId("financialPlanningTabME").setEnabled(true);
					this.byId("financialPlanningTabTC").setVisible(false);
					this.byId("financialPlanningTabNPI").setVisible(false);
					this.byId("assetsTabME").setVisible(true);
					this.byId("assetsTabME").setEnabled(true);
					this.byId("assetsTabTC").setVisible(false);
					this.byId("assetsTabNPI").setVisible(false);
					this.byId("capacityBTabME").setVisible(true);
					this.byId("capacityBTabME").setEnabled(true);
					this.byId("capacityBTabTC").setVisible(false);
					this.byId("capacityBTabNPI").setVisible(false);
					this.byId("summaryTabTC").setVisible(false);
					this.byId("summaryTabME").setVisible(true);
					this.byId("summaryTabME").setEnabled(true);
					this.byId("summaryTabNPI").setVisible(false);
					break;
				case "ZT04":
					this.byId("product").setVisible(true);
					this.byId("adminCompl").setVisible(true);
					this.byId("programme").setVisible(true);
					this.byId("previous").setVisible(true);
					this.byId("previousperfomance").setVisible(true);
					//this.byId("overall").setVisible(true);
					//this.byId("previousfinancial").setVisible(true);
					this.byId("beneficiariesTrackingTab").setVisible(true);
					this.byId("financialPlanningTab").setVisible(true);
					this.byId("assetsTab").setVisible(true);
					this.byId("capacityBTab").setVisible(true);
					this.byId("summaryTab").setVisible(true);

					this.byId("LineItemsTable").setVisible(true);
					//this.byId("LineItemsTable2").setVisible(true);
					//this.byId("HdrProcess").setTitle("NPI Budget Evaluation");
					this.byId("HdrProcess").setTitle("Technical Committe");
					this.byId("ApproveButton").setVisible(false);
					this.byId("RejectButton").setVisible(false);
					//this.byId("SubmitButton").setVisible(true);

					this.byId("adminComplME").setVisible(true);
					this.byId("adminComplME").setEnabled(false);
					this.byId("adminComplTC").setVisible(true);
					this.byId("adminComplTC").setEnabled(true);
					this.byId("adminComplNPI").setVisible(false);
					this.byId("programmeME").setVisible(true);
					this.byId("programmeME").setEnabled(false);
					this.byId("programmeTC").setVisible(true);
					this.byId("programmeTC").setEnabled(true);
					this.byId("programmeNPI").setVisible(false);
					this.byId("previousME").setVisible(true);
					this.byId("previousME").setEnabled(false);
					this.byId("previousTC").setVisible(true);
					this.byId("previousTC").setEnabled(true);
					this.byId("previousNPI").setVisible(false);
					this.byId("previousperfomanceME").setVisible(true);
					this.byId("previousperfomanceME").setEnabled(false);
					this.byId("previousperfomanceTC").setVisible(true);
					this.byId("previousperfomanceTC").setEnabled(true);
					this.byId("previousperfomanceNPI").setVisible(false);
					// this.byId("overallME").setVisible(true);
					// this.byId("overallME").setEnabled(false);
					// this.byId("overallTC").setVisible(true);
					// this.byId("overallTC").setEnabled(true);
					// this.byId("overallNPI").setVisible(false);
					// this.byId("previousfinancialME").setVisible(true);
					// this.byId("previousfinancialME").setEnabled(false);
					// this.byId("previousfinancialTC").setVisible(true);
					// this.byId("previousfinancialTC").setEnabled(true);
					// this.byId("previousfinancialNPI").setVisible(false);
					this.byId("beneficiariesTrackingTabME").setVisible(true);
					this.byId("beneficiariesTrackingTabME").setEnabled(false);
					this.byId("beneficiariesTrackingTabTC").setVisible(true);
					this.byId("beneficiariesTrackingTabTC").setEnabled(true);
					this.byId("beneficiariesTrackingTabNPI").setVisible(false);
					this.byId("financialPlanningTabME").setVisible(true);
					this.byId("financialPlanningTabME").setEnabled(false);
					this.byId("financialPlanningTabTC").setVisible(true);
					this.byId("financialPlanningTabTC").setEnabled(true);
					this.byId("financialPlanningTabNPI").setVisible(false);
					this.byId("assetsTabME").setVisible(true);
					this.byId("assetsTabME").setEnabled(false);
					this.byId("assetsTabTC").setVisible(true);
					this.byId("assetsTabTC").setEnabled(true);
					this.byId("assetsTabNPI").setVisible(false);
					this.byId("capacityBTabME").setVisible(true);
					this.byId("capacityBTabME").setEnabled(false);
					this.byId("capacityBTabTC").setVisible(true);
					this.byId("capacityBTabTC").setEnabled(true);
					this.byId("capacityBTabNPI").setVisible(false);
					this.byId("summaryTabTC").setVisible(true);
					this.byId("summaryTabTC").setEnabled(true);
					this.byId("summaryTabME").setVisible(true);
					this.byId("summaryTabME").setEnabled(false);
					this.byId("summaryTabNPI").setVisible(false);
					break;

				case "ZT05":
					this.byId("product").setVisible(true);
					this.byId("adminCompl").setVisible(true);
					this.byId("programme").setVisible(true);
					this.byId("previous").setVisible(true);
					this.byId("previousperfomance").setVisible(true);
					//					this.byId("overall").setVisible(true);
					//this.byId("previousfinancial").setVisible(true);
					this.byId("beneficiariesTrackingTab").setVisible(true);
					this.byId("financialPlanningTab").setVisible(true);
					this.byId("assetsTab").setVisible(true);
					this.byId("capacityBTab").setVisible(true);
					this.byId("summaryTab").setVisible(true);

					this.byId("LineItemsTable").setVisible(true);
					//this.byId("LineItemsTable2").setVisible(true);
					this.byId("HdrProcess").setTitle("NPI Budget Evaluation");
					//this.getTechicalCommitee(this.Property.Guid);

					this.byId("adminComplME").setVisible(true);
					this.byId("adminComplME").setEnabled(false);
					this.byId("adminComplTC").setVisible(true);
					this.byId("adminComplTC").setEnabled(false);
					this.byId("adminComplNPI").setVisible(true);
					this.byId("programmeME").setVisible(true);
					this.byId("programmeME").setEnabled(false);
					this.byId("programmeTC").setVisible(true);
					this.byId("programmeTC").setEnabled(false);
					this.byId("programmeNPI").setVisible(true);
					this.byId("previousME").setVisible(true);
					this.byId("previousME").setEnabled(false);
					this.byId("previousTC").setVisible(true);
					this.byId("previousTC").setEnabled(false);
					this.byId("previousNPI").setVisible(true);
					this.byId("previousperfomanceME").setVisible(true);
					this.byId("previousperfomanceME").setEnabled(false);
					this.byId("previousperfomanceTC").setVisible(true);
					this.byId("previousperfomanceTC").setEnabled(false);
					this.byId("previousperfomanceNPI").setVisible(true);
					// this.byId("overallME").setVisible(true);
					// this.byId("overallME").setEnabled(false);
					// this.byId("overallTC").setVisible(true);
					// this.byId("overallTC").setEnabled(false);
					// this.byId("overallNPI").setVisible(true);
					// this.byId("previousfinancialME").setVisible(true);
					// this.byId("previousfinancialME").setEnabled(false);
					// this.byId("previousfinancialTC").setVisible(true);
					// this.byId("previousfinancialTC").setEnabled(false);
					// this.byId("previousfinancialNPI").setVisible(true);
					this.byId("beneficiariesTrackingTabME").setVisible(true);
					this.byId("beneficiariesTrackingTabME").setEnabled(false);
					this.byId("beneficiariesTrackingTabTC").setVisible(true);
					this.byId("beneficiariesTrackingTabTC").setEnabled(false);
					this.byId("beneficiariesTrackingTabNPI").setVisible(true);
					this.byId("financialPlanningTabME").setVisible(true);
					this.byId("financialPlanningTabME").setEnabled(false);
					this.byId("financialPlanningTabTC").setVisible(true);
					this.byId("financialPlanningTabTC").setEnabled(false);
					this.byId("financialPlanningTabNPI").setVisible(true);
					this.byId("assetsTabME").setVisible(true);
					this.byId("assetsTabME").setEnabled(false);
					this.byId("assetsTabTC").setVisible(true);
					this.byId("assetsTabTC").setEnabled(false);
					this.byId("assetsTabNPI").setVisible(true);
					this.byId("capacityBTabME").setVisible(true);
					this.byId("capacityBTabME").setEnabled(false);
					this.byId("capacityBTabTC").setVisible(true);
					this.byId("capacityBTabTC").setEnabled(false);
					this.byId("capacityBTabNPI").setVisible(true);
					this.byId("summaryTabTC").setVisible(true);
					this.byId("summaryTabTC").setEnabled(false);
					this.byId("summaryTabME").setVisible(true);
					this.byId("summaryTabME").setEnabled(false);
					this.byId("summaryTabNPI").setVisible(true);
					break;
			}

			if (vTaskType === "ZT01") {
				this.byId("btnProductNext").setVisible(false);
			} else {
				this.byId("btnProductNext").setVisible(true);
			}
		},

		getProducts: function(vGuid) {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("Applicationguid", "EQ", vGuid);
			var oTable = this.byId("LineItemsTable");
			//	oTable2 = this.byId("LineItemsTable2");

			this._oODataModel.read("/GetApplicationItemsSet", {
				filters: [oFilter],
				success: function(odata) {
					this._productModel.getData().data = odata.results;

					oTable.setModel();
					this.countGrandTotal();
					oTable.setModel(this._productModel, "ProductLineItemsModel");
					oTable.getModel("ProductLineItemsModel").refresh(true);
					
					// oTable2.setModel();
					// oTable2.setModel(this._productModel, "ProductLineItemsModel2");
					// oTable2.getModel("ProductLineItemsModel2").refresh(true);

					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve product details");
				}.bind(this)
			});
		},

		onNavBack: function() {

			this.Router.navTo("ApplicationInfo", {
				//prepare object path to be passed on to target
				Path: window.encodeURIComponent(this.sPath.substr(1))
			});
		},

		checkStatusAndAllocateStatus: function() {
			if (this.Property.TaskType === "ZT01" || this.Property.TaskType === "ZT02") {
				this.getView().getModel().getData().data.Status = "E0002";
				this.onUpdate();
			}
		},

		onApproveTask: function() {
			if (!this.oApproveDialog) {
				this.oApproveDialog = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({
						text: "Are you sure you want to Approve the task?"
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Approve",
						press: function() {
							this.getView().getModel().getData().data.Status = "E0002";
							//this.onUpdate();
							this.onSubmitCapacity();
							this.oApproveDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "Cancel",
						press: function() {
							this.oApproveDialog.close();
						}.bind(this)
					})
				});
			}

			this.oApproveDialog.open();

		},
		onRejectTask: function() {
			if (!this.oRejectDialog) {
				this.oRejectDialog = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({
						text: "Are you sure you want to Reject the task?"
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Reject",
						press: function() {
							this.getView().getModel().getData().data.Status = "E0007";
							//this.onUpdate();
							this.onSubmitCapacity();
							this.oRejectDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "Cancel",
						press: function() {
							this.oRejectDialog.close();
						}.bind(this)
					})
				});
			}

			this.oRejectDialog.open();

		},

		onUpdate: function() {
			sap.ui.core.BusyIndicator.show(0);
			var oProperties = this.getView().getModel().getData().data;
			this._oODataModel.update("/GEtApplicationProcessingSet(BpNo='" + oProperties.BpNo + "',Guid='" + oProperties.Guid + "',ObjectId='" +
				oProperties.ObjectId + "')", oProperties, {

					success: function(results) {
						//this.onSubmitCapacity();
						this.successAndNavigate();
					}.bind(this),
					error: function(results) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error("Error occured while trying to process an application");
					}

				});
		},

		successAndNavigate: function(oEvent) {

			MessageBox.success("Task " + this.Property.ObjectId + " has been successfully updated", {
				icon: sap.m.MessageBox.Icon.CONFIRMATION,
				title: "Confirmation",
				actions: [sap.m.MessageBox.Action.OK],
				onClose: function(oAction) {
					if (oAction === "OK") {
						this.Router.navTo("ApplicationProcess");
						return;
					}
				}.bind(this)
			});
		},

		onSaveBP: function() {
			var oTable = this.byId("tblPanelMembers");

			if (sap.ui.getCore().byId("BpNo").getValue() === "") {
				MessageBox.error("Please select BP");
			} else {
				this.TechCommiteeModel.getData().data.push({
					"RefGuid": this.Property.Guid,
					"RefPartnerFct": "",
					"RefPartnerNo": sap.ui.getCore().byId("BpNo").getValue(),
					"Name1Text": sap.ui.getCore().byId("BpName").getValue(),
					"Indicator": true
				});

				oTable.setModel();

				oTable.setModel(this.TechCommiteeModel, "CommitteModel");
				oTable.getModel("CommitteModel").refresh(true);

				sap.ui.getCore().byId("BpNo").setValue();
				sap.ui.getCore().byId("BpName").setValue();
				this.onCancel();
			}
		},

		onCancel: function() {
			//Cater for the age group selected 
			var oDialogKey,
				oDialogValue;

			for (oDialogKey in this._mViewSettingsDialogs) {
				oDialogValue = this._mViewSettingsDialogs[oDialogKey];

				if (oDialogValue) {
					oDialogValue.close();
					// oDialogValue = null;
				}
			}
		},

		createFormDialog: function(sDialogFragmentName) {

			// https://stackoverflow.com/questions/55667673/how-to-remove-duplicates-and-display-only-unique-values-in-viewsettingsitem
			var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
				this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;

				if (Device.system.desktop) {
					oDialog.addStyleClass("sapUiSizeCompact");
				}
			}
			return oDialog;
		},

		onAddBP: function() {
			this.createFormDialog("gdsd.FundingApplicationProcess.ApplicationFundProcess.view.fragments.BusinessPartner").open();
		},

		onAddProduct: function(oEvent) {
			if (!this._ProductDialog) {
				this._ProductDialog = sap.ui.xmlfragment(
					"gdsd.FundingApplicationProcess.ApplicationFundProcess.view.fragments.Products", this);
				this.getView().addDependent(this._ProductDialog);
				this._ProductDialog.open();
			} else {
				this._ProductDialog.open();
			}
		},

		onValueHelpRequest: function(oEvent) {

			if (!this._oValueHelpDialog) {
				this._oValueHelpDialog = sap.ui.xmlfragment(
					"gdsd.FundingApplicationProcess.ApplicationFundProcess.view.fragments.BusinessPartnerList", this);
				this.getView().addDependent(this._oValueHelpDialog);
				this._oValueHelpDialog.open();
			} else {
				this._oValueHelpDialog.open();
			}
		},

		onValueHelpSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("BpName", FilterOperator.Contains, sValue);

			oEvent.getSource().getBinding("items").filter([oFilter]);
		},

		onValueHelpClose: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}

			sap.ui.getCore().byId("BpNo").setValue(oSelectedItem.getTitle());
			sap.ui.getCore().byId("BpName").setValue(oSelectedItem.getDescription());
		},

		onSubmitCapacity: function() {

			var aItems = [],
				oItem = {},
				oItemsProducts = {},
				aItemProducts = [];

			var batchChanges = [],
				batchModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDSD_CRM_UI5_APP_SRV/");

			for (var i = 0; i < this._productModel.getData().data.length; i++) {
				oItemsProducts.Applicationguid = this._productModel.getData().data[i].Applicationguid;
				oItemsProducts.Itemguid = this._productModel.getData().data[i].Itemguid;
				oItemsProducts.Quantity = this._productModel.getData().data[i].Quantity;
				oItemsProducts.Uom = this._productModel.getData().data[i].Uom;
				oItemsProducts.Productguid = this._productModel.getData().data[i].Productguid;
				oItemsProducts.Productid = this._productModel.getData().data[i].Productid;
				oItemsProducts.Description = this._productModel.getData().data[i].Productid;
				oItemsProducts.Amount = this._productModel.getData().data[i].Amount;
				oItemsProducts.Producttype = this._productModel.getData().data[i].Producttype;
				oItemsProducts.Totalamount = this._productModel.getData().data[i].Totalamount;
				aItemProducts.push(oItemsProducts);
				oItemsProducts = {};
			}

			if (aItemProducts.length > 0) {
				for (var k = 0; k < aItemProducts.length; k++) {
					batchChanges.push(batchModel.createBatchOperation("/GetApplicationItemsSet", "POST", aItemProducts[k]));
				}

				batchModel.addBatchChangeOperations(batchChanges);
				batchModel.setUseBatch(true);

				sap.ui.core.BusyIndicator.show();
				//submit Batch and refresh the table
				batchModel.submitBatch(function(data) {
					var parser = new DOMParser(),
						xmlDoc;

					sap.ui.core.BusyIndicator.hide();

					if (data.__batchResponses[0]) {
						if (data.__batchResponses[0].__changeResponses) {
							if (data.__batchResponses[0].__changeResponses[0].statusCode.startsWith('2')) {
								//this.successAndNavigate();
								this.onUpdate();
							} else {
								MessageBox.error("Error occured while processing product line items");
							}
						} else {
							MessageBox.error("Error occured while processing product line items");
						}
					}
					batchModel.resetChanges();
					batchModel.refresh();
				}.bind(this), function(err) {
					MessageBox.error("Error occured while processing product line items");
					sap.ui.core.BusyIndicator.hide();
				});
			} else {
				sap.ui.core.BusyIndicator.hide();
				//this.successAndNavigate();
				this.onUpdate();
			}

		},

		getTechicalCommitee: function(vGuid) {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("RefGuid", "EQ", vGuid);
			var oTable = this.byId("tblPanelMembers");

			this._oODataModel.read("/GetTechnicalCommitteeSet", {
				filters: [oFilter],
				success: function(odata) {
					this.TechCommiteeModel.getData().data = odata.results;
					oTable.setModel();
					oTable.setModel(this.TechCommiteeModel, "CommitteModel");
					oTable.getModel("CommitteModel").refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve technical commitee details");
				}.bind(this)
			});
		},

		onPressProduct: function(oEvent) {
			this.Router.navTo("ProductLineItems", {
				//prepare object path to be passed on to target
				ProductPath: window.encodeURIComponent(oEvent.getSource().getBindingContext("ZDSD_CRM_UI5").getPath().substr(1)),
				ProcessPath: window.encodeURIComponent(this.sPath.substr(1)),
				TaskType: this.TaskType
			});
		},

		onSelectProduct: function(oEvent) {

			var oTable = this.byId("LineItemsTable");
			var oSelectedItem = oEvent.getParameter("selectedItem");

			var oPath = oSelectedItem.getBindingContext("ZDSD_CRM_UI5").getPath();
			var oProperty = this._oODataModel.getProperty(oPath);

			this._productModel.getData().data.push({
				"Applicationguid": this.ApplicGuid,
				"Itemguid": "",
				"Productguid": oProperty.ProductGuid,
				"Productid": oProperty.ProductId,
				"Description": oProperty.ProductId,
				"Amount": oProperty.Kbetr,
				"Producttype": "",
				"Totalamount": "",
				"Qty": "",
				"Uom": oProperty.Kmein
			});

			oTable.setModel();

			oTable.setModel(this._productModel, "ProductLineItemsModel");
			oTable.getModel("ProductLineItemsModel").refresh(true);
		},

		onProductSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("ProductId", FilterOperator.Contains, sValue);

			oEvent.getSource().getBinding("items").filter([oFilter]);
		},

		onDeleteLineItems: function(oEvent) {
			//Delete Row 
			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("ProductLineItemsModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("ProductLineItemsModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this._productModel.refresh();
		},

		onCalculateTotal: function(oEvent) {
			var Qty = parseFloat(oEvent.getSource().getParent().getCells()[4].getValue());
			//var Price = parseFloat(oEvent.getSource().getParent().getCells()[3].getText());

			var oNumberFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
				maxFractionDigits: 2,
				groupingEnabled: false
			});

			var Price = oNumberFormat.parse(oEvent.getSource().getParent().getCells()[3].getText());
			
			if (isNaN(Qty)) {
				Qty = 0;
			}

			var total = Price * Qty;

			if (isNaN(total)) {
				oEvent.getSource().getParent().getCells()[5].setText();
			} else {
				oEvent.getSource().getParent().getCells()[5].setText(total);
			}
			
			this.countGrandTotal();

		},

		validateLineItemsAndTechCommiteeNotes: function(oEvent) {
			var oTable = this.byId("LineItemsTable");
			var oRows = oTable.getItems();

			if (oRows.length > 0) {
				for (var counter = 0; counter < oRows.length; ++counter) {
					if (oRows[counter].getCells()[0].getValue() === "") {
						MessageBox.error("Select Product type in all the rows");
						return;
					}

					if (oRows[counter].getCells()[4].getValue() === "") {
						MessageBox.error("Please input quantity in all the rows");
						return;
					}
				}
			} else {
				MessageBox.error("Please make sure you capture line items under Products");
				return;
			}

			//Validate Technical Committee Notes
			if (this.byId("adminComplNotes").getValue() === "") {
				MessageBox.error("Please capture notes under Administrative Compliance");
				return;
			}

			if (this.byId("programmeViabilityNotes").getValue() === "") {
				MessageBox.error("Please capture notes under Programme Viability & Eligibility");
				return;
			}

			if (this.byId("previousprogNotes").getValue() === "") {
				MessageBox.error("Please capture notes under Previous Programme Performance");
				return;
			}

			if (this.byId("previousperfomanceNotes").getValue() === "") {
				MessageBox.error("Please capture notes under Previous Financial Performance");
				return;
			}

			if (this.byId("overallRecommendationsNotes").getValue() === "") {
				MessageBox.error("Please capture notes under Overall Recommendations");
				return;
			}

			this.onApproveTask();

		},

		onDeleteCommitte: function(oEvent) {

			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("CommitteModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("CommitteModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this.TechCommiteeModel.refresh(true);

			//alert("Entry Successfully Deleted");
		},

		validateApprove: function() {
			if (this.Property.TaskType === "ZT03") {
				this.validateLineItemsAndTechCommiteeNotes();
			} else {
				this.onApproveTask();
			}
		},

		validateReject: function() {
			if (this.Property.TaskType === "ZT03") {
				//Validate Technical Committee Notes
				if (this.byId("adminComplNotes").getValue() === "") {
					MessageBox.error("Please capture notes under Administrative Compliance");
					return;
				}

				if (this.byId("programmeViabilityNotes").getValue() === "") {
					MessageBox.error("Please capture notes under Programme Viability & Eligibility");
					return;
				}

				if (this.byId("previousprogNotes").getValue() === "") {
					MessageBox.error("Please capture notes under Previous Programme Performance");
					return;
				}

				if (this.byId("previousperfomanceNotes").getValue() === "") {
					MessageBox.error("Please capture notes under Previous Financial Performance");
					return;
				}

				if (this.byId("overallRecommendationsNotes").getValue() === "") {
					MessageBox.error("Please capture notes under Overall Recommendations");
					return;
				}

				this.onRejectTask();
			} else {
				this.onRejectTask();
			}
		},

		onSubmit: function() {
			// this.getView().getModel().getData().data.Status = "E0003";
			// this.onUpdate();

			if (this.getView().getModel().getData().data.TaskType === "ZT01") {
				if (!this.oInspectionDialog) {
					this.oInspectionDialog = new Dialog({
						type: DialogType.Message,
						title: "Confirm",
						content: new Text({
							text: "Is an inspection required?"
						}),
						customHeader: [
							new sap.m.Bar({
								contentRight: new sap.ui.core.Icon({
									type: ButtonType.Reject,
									text: "Confirm",
									src: "sap-icon://decline",
									useIconTooltip: false,
									color: "#f33334",
									press: function(oEvent) {
										this.oInspectionDialog.close();
										this.oInspectionDialog = null;
									}.bind(this)
								}).addStyleClass("sapUiMediumMarginBottom"),
								contentMiddle: [
									new sap.m.Title({
										text: "Confirm"
									}),
									new sap.ui.core.Icon({
										src: "sap-icon://message-warning",
										useIconTooltip: false,
										color: "#E69A17"
									})
								]
							})

						],
						beginButton: new Button({
							type: ButtonType.Emphasized,
							text: "Yes",
							press: function() {
								this.getView().getModel().getData().data.Status = "E0007";
								//this.onUpdate();
								this.onSubmitCapacity();

								this.oInspectionDialog.close();
							}.bind(this)
						}),
						endButton: new Button({
							text: "No",
							press: function() {
								this.getView().getModel().getData().data.Status = "E0002";
								//this.onUpdate();
								this.onSubmitCapacity();
								this.oInspectionDialog.close();
							}.bind(this)
						})
					});
				}

				this.oInspectionDialog.open();
			} else {
				this.getView().getModel().getData().data.Status = "E0002";
				//this.onUpdate();
				this.onSubmitCapacity();
			}
		},

		onProductsNextPress: function() {
			this.byId("IconBar").setSelectedKey("admin");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onAdminCompPreviousPress: function() {
			this.byId("IconBar").setSelectedKey("LineItems");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onAdminCompNextPress: function() {
			this.byId("IconBar").setSelectedKey("programmeV");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onViabilityPrevPress: function() {
			this.byId("IconBar").setSelectedKey("admin");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onViabilityNextPress: function() {
			this.byId("IconBar").setSelectedKey("previousPF");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onPerformancePrevPress: function() {
			this.byId("IconBar").setSelectedKey("programmeV");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onPerformanceNextPress: function() {
			this.byId("IconBar").setSelectedKey("previousFP");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onFinancialPrevPress: function() {
			this.byId("IconBar").setSelectedKey("previousPF");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onFinancialNextPress: function() {
			this.byId("IconBar").setSelectedKey("beneficiariestracking");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onOverallPrevPress: function() {
			this.byId("IconBar").setSelectedKey("previousFP");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onOverallNextPress: function() {
			this.byId("IconBar").setSelectedKey("pfp");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onPrevFinancialPreviousPress: function() {
			this.byId("IconBar").setSelectedKey("overallR");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onPrevFinancialNextPress: function() {
			this.byId("IconBar").setSelectedKey("beneficiariestracking");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onBeneficiariesTrackingPreviousPress: function() {
			this.byId("IconBar").setSelectedKey("previousFP");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onBeneficiariesTrackingNextPress: function() {
			this.byId("IconBar").setSelectedKey("financialPlanning");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onFinancialPlanningPrevPress: function() {
			this.byId("IconBar").setSelectedKey("beneficiariestracking");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onFinancialPlanningNextPress: function() {
			this.byId("IconBar").setSelectedKey("assets");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onAssetsProcuredPrevPress: function() {
			this.byId("IconBar").setSelectedKey("financialPlanning");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onAssetsProcuredNextPress: function() {
			this.byId("IconBar").setSelectedKey("capacityB");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onCapacityBuildingNeedsPrevPress: function() {
			this.byId("IconBar").setSelectedKey("assets");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onCapacityBuildingNeedsNextPress: function() {
			this.byId("IconBar").setSelectedKey("summary");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},
		onSummaryPrevPress: function() {
			this.byId("IconBar").setSelectedKey("capacityB");
			this.byId("detailPage").scrollTo(0, 0);
			this.handleIconTabBarSelect();
		},

		handleIconTabBarSelect: function() {
			this.byId("SubmitButton").setVisible(false);
			this.byId("ApproveButton").setVisible(false);
			this.byId("RejectButton").setVisible(false);
			if (this.byId("IconBar").getSelectedKey() === "summary") {
				if (this.TaskType === "ZT01" || this.TaskType === "ZT03" ||
					this.TaskType === "ZT04") {
					this.byId("SubmitButton").setVisible(true);
					this.byId("ApproveButton").setVisible(false);
					this.byId("RejectButton").setVisible(false);
				} else if (this.TaskType === "ZT05") {
					this.byId("SubmitButton").setVisible(false);
					this.byId("ApproveButton").setVisible(true);
					this.byId("RejectButton").setVisible(true);
				}
			}
		},

		countGrandTotal: function() {
			var oTotal = 0;
			
			for (var i = 0; i < this._productModel.getData().data.length; i++) {
				oTotal = oTotal + parseFloat(this._productModel.getData().data[i].Totalamount);
			}
			
			this.getView().getModel("ViewModel").setProperty("/totalAmount", oTotal);
			//this.oViewModel.setProperty("/totalAmount");
		}

	});

});