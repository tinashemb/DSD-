sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/Device",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/MessageToast",
	"sap/m/Text"
], function (Controller, MessageBox, Device, Filter, FilterOperator, Fragment, Dialog, DialogType, Button, ButtonType, MessageToast, Text) {
	"use strict";

	return Controller.extend("gdsd.FundingApplicationProcess.ApplicationFundProcess.controller.Processing", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.FundingApplicationProcess.ApplicationFundProcess.view.Processing
		 */
		onInit: function () {
			this._processModel = this.getOwnerComponent().getModel("ApplicationProcessing");
			this._productModel = this.getOwnerComponent().getModel("ProductLineItems");
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this._mViewSettingsDialogs = {};

			this.TechCommiteeModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.Router.getRoute("Processing").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function (oEvent) {
			this.TaskType = oEvent.getParameter("arguments").TaskType;
			this.sPath = "/" + window.decodeURIComponent(oEvent.getParameter("arguments").Path);
			this.ApplicGuid = oEvent.getParameter("arguments").ApplicGuid;
			this.Property = this._processModel.getProperty(this.sPath);

			//this.TaskType = "ZT03";

			var ApplicationProcessModel = new sap.ui.model.json.JSONModel({
				data: this.Property
			});

			var oTable = this.byId("LineItemsTable"),
				oTable2 = this.byId("LineItemsTable");

			//Set Binding Mode
			ApplicationProcessModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

			this.byId("notes").setModel(ApplicationProcessModel);
			this.byId("notes").bindElement({
				path: "/data"
			});

			this.byId("overall").setModel(ApplicationProcessModel);
			this.byId("overall").bindElement({
				path: "/data"
			});

			this.byId("previousperfomance").setModel(ApplicationProcessModel);
			this.byId("previousperfomance").bindElement({
				path: "/data"
			});

			this.byId("previous").setModel(ApplicationProcessModel);
			this.byId("previous").bindElement({
				path: "/data"
			});

			this.byId("programme").setModel(ApplicationProcessModel);
			this.byId("programme").bindElement({
				path: "/data"
			});

			this.byId("admin").setModel(ApplicationProcessModel);
			this.byId("admin").bindElement({
				path: "/data"
			});

			this.getView().setModel(ApplicationProcessModel);

			this.formatUI(this.TaskType);

			this._productModel.getData().data = [];

			oTable.setModel();
			oTable.setModel(this._productModel, "ProductLineItemsModel");
			oTable.getModel("ProductLineItemsModel").refresh(true);

			oTable2.setModel();
			oTable2.setModel(this._productModel, "ProductLineItemsModel2");
			oTable2.getModel("ProductLineItemsModel2").refresh(true);

			if (this.TaskType === "ZT04") {
				this.getProducts(this.ApplicGuid);
			}
		},

		formatUI: function (vTaskType) {

			switch (vTaskType) {
			case "ZT01":
				this.byId("notes").setVisible(true);
				this.byId("attend").setVisible(false);
				this.byId("overall").setVisible(false);
				this.byId("previousperfomance").setVisible(false);
				this.byId("previous").setVisible(false);
				this.byId("programme").setVisible(false);
				this.byId("admin").setVisible(false);
				//this.byId("commitee").setVisible(false);
				this.byId("particulars").setVisible(false);
				this.byId("zp01").setVisible(true);
				this.byId("zp02").setVisible(false);
				this.byId("zp04").setVisible(false);
				this.byId("zp01").setEnabled(true);
				this.byId("products").setVisible(false);
				this.byId("HdrProcess").setTitle("NPO Evaluation");
				this.byId("btnProcessApprove").setVisible(false);
				this.byId("btnProcessReject").setVisible(false);
				this.byId("btnProcessSubmit").setVisible(true);
				// this.byId("notes").setVisible(false);
				// this.byId("attend").setVisible(false);
				// this.byId("overall").setVisible(true);
				// this.byId("previousperfomance").setVisible(true);
				// this.byId("previous").setVisible(true);
				// this.byId("programme").setVisible(true);
				// this.byId("admin").setVisible(true);
				// this.byId("commitee").setVisible(true);
				// this.byId("particulars").setVisible(false);
				// this.byId("zp01").setVisible(false);
				// this.byId("zp02").setVisible(false);
				// this.byId("zp04").setVisible(false);
				break;
			case "ZT02":
				this.byId("notes").setVisible(true);
				this.byId("attend").setVisible(false);
				this.byId("overall").setVisible(false);
				this.byId("previousperfomance").setVisible(false);
				this.byId("previous").setVisible(false);
				this.byId("programme").setVisible(false);
				this.byId("admin").setVisible(false);
				//this.byId("commitee").setVisible(false);
				this.byId("particulars").setVisible(false);
				this.byId("zp01").setVisible(true);
				this.byId("zp02").setVisible(true);
				this.byId("zp04").setVisible(false);
				this.byId("products").setVisible(false);
				this.byId("HdrProcess").setTitle("NPO Onsite Inspection");
				this.byId("zp01").setEnabled(false);
				this.byId("zp02").setEnabled(true);
				this.byId("btnProcessApprove").setVisible(false);
				this.byId("btnProcessReject").setVisible(false);
				this.byId("btnProcessSubmit").setVisible(true);
				break;
			case "ZT04":
				this.byId("notes").setVisible(true);
				this.byId("attend").setVisible(false);
				this.byId("overall").setVisible(true);
				this.byId("previousperfomance").setVisible(true);
				this.byId("previous").setVisible(true);
				this.byId("programme").setVisible(true);
				this.byId("admin").setVisible(true);
				//this.byId("commitee").setVisible(false);
				this.byId("particulars").setVisible(false);
				this.byId("zp01").setVisible(true);
				this.byId("zp02").setVisible(true);
				this.byId("zp04").setVisible(true);
				this.byId("products").setVisible(true);
				this.byId("LineItemsTable").setVisible(false);
				this.byId("LineItemsTable2").setVisible(true);
				this.byId("HdrProcess").setTitle("NPI Budget Evaluation");
				this.byId("zp01").setEnabled(false);
				this.byId("zp02").setEnabled(false);
				this.byId("zp04").setEnabled(true);
				this.byId("btnProcessApprove").setVisible(true);
				this.byId("btnProcessReject").setVisible(true);
				this.byId("btnProcessSubmit").setVisible(false);
				this.byId("adminComplNotes").setEnabled(false);
                this.byId("programmeViabilityNotes").setEnabled(false);
                this.byId("previousprogNotes").setEnabled(false);
                this.byId("previousperfomanceNotes").setEnabled(false);
                this.byId("overallRecommendationsNotes").setEnabled(false);
				break;

			case "ZT03":
				this.byId("notes").setVisible(true);
				this.byId("attend").setVisible(false);
				this.byId("overall").setVisible(true);
				this.byId("previousperfomance").setVisible(true);
				this.byId("previous").setVisible(true);
				this.byId("programme").setVisible(true);
				this.byId("admin").setVisible(true);
				//this.byId("commitee").setVisible(true);
				this.byId("particulars").setVisible(false);
				this.byId("zp01").setVisible(true);
				this.byId("zp02").setVisible(true);
				this.byId("zp04").setVisible(false);
				this.byId("products").setVisible(true);
				this.byId("LineItemsTable").setVisible(true);
				this.byId("LineItemsTable2").setVisible(false);
				this.byId("HdrProcess").setTitle("Technical Committe");
				this.byId("zp01").setEnabled(false);
				this.byId("zp02").setEnabled(false);
				this.byId("btnProcessApprove").setVisible(true);
				this.byId("btnProcessReject").setVisible(true);
				this.byId("btnProcessSubmit").setVisible(false);
				this.byId("adminComplNotes").setEnabled(true);
                this.byId("programmeViabilityNotes").setEnabled(true);
                this.byId("previousprogNotes").setEnabled(true);
                this.byId("previousperfomanceNotes").setEnabled(true);
                this.byId("overallRecommendationsNotes").setEnabled(true);
				//this.getTechicalCommitee(this.Property.Guid);
				break;
			}
		},

		getProducts: function (vGuid) {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("Applicationguid", "EQ", vGuid);
			var oTable = this.byId("LineItemsTable"),
				oTable2 = this.byId("LineItemsTable2");

			this._oODataModel.read("/GetApplicationItemsSet", {
				filters: [oFilter],
				success: function (odata) {
					this._productModel.getData().data = odata.results;

					// oTable.setModel();
					// oTable.setModel(this._productModel, "ProductLineItemsModel");
					// oTable.getModel("ProductLineItemsModel").refresh(true);

					oTable2.setModel();
					oTable2.setModel(this._productModel, "ProductLineItemsModel2");
					oTable2.getModel("ProductLineItemsModel2").refresh(true);

					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve product details");
				}.bind(this)
			});
		},

		onNavBack: function () {

			this.Router.navTo("ApplicationInfo", {
				//prepare object path to be passed on to target
				Path: window.encodeURIComponent(this.sPath.substr(1))
			});
		},

		checkStatusAndAllocateStatus: function () {
			if (this.Property.TaskType === "ZT01" || this.Property.TaskType === "ZT02") {
				this.getView().getModel().getData().data.Status = "E0003";
				this.onUpdate();
			}
		},

		onApproveTask: function () {
			if (!this.oApproveDialog) {
				this.oApproveDialog = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({
						text: "Are you sure you want to Approve the task?"
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Approve",
						press: function () {
							this.getView().getModel().getData().data.Status = "E0003";
							this.onUpdate();
							this.oApproveDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oApproveDialog.close();
						}.bind(this)
					})
				});
			}

			this.oApproveDialog.open();

		},
		onRejectTask: function () {
			if (!this.oRejectDialog) {
				this.oRejectDialog = new Dialog({
					type: DialogType.Message,
					title: "Confirm",
					content: new Text({
						text: "Are you sure you want to Reject the task?"
					}),
					beginButton: new Button({
						type: ButtonType.Emphasized,
						text: "Reject",
						press: function () {
							this.getView().getModel().getData().data.Status = "E0007";
							this.onUpdate();
							this.oRejectDialog.close();
						}.bind(this)
					}),
					endButton: new Button({
						text: "Cancel",
						press: function () {
							this.oRejectDialog.close();
						}.bind(this)
					})
				});
			}

			this.oRejectDialog.open();

		},

		onUpdate: function () {
			sap.ui.core.BusyIndicator.show(0);
			var oProperties = this.getView().getModel().getData().data;
			this._oODataModel.update("/GEtApplicationProcessingSet(BpNo='" + oProperties.BpNo + "',Guid='" + oProperties.Guid + "',ObjectId='" +
				oProperties.ObjectId + "')", oProperties, {

					success: function (results) {
						if (this.Property.TaskType === "ZT03") {
							this.onSubmitCapacity();
						}else{
							sap.ui.core.BusyIndicator.hide();
							this.successAndNavigate();
						}
						
					}.bind(this),
					error: function (results) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error("Error occured while trying to process an application");
					}

				});
		},

		successAndNavigate: function (oEvent) {

			MessageBox.success("Task " + this.Property.ObjectId + " has been successfully updated", {
				icon: sap.m.MessageBox.Icon.CONFIRMATION,
				title: "Confirmation",
				actions: [sap.m.MessageBox.Action.OK],
				onClose: function (oAction) {
					if (oAction === "OK") {
						this.Router.navTo("ApplicationProcess");
						return;
					}
				}.bind(this)
			});
		},

		onSaveBP: function () {
			var oTable = this.byId("tblPanelMembers");

			if (sap.ui.getCore().byId("BpNo").getValue() === "") {
				MessageBox.error("Please select BP");
			} else {
				this.TechCommiteeModel.getData().data.push({
					"RefGuid": this.Property.Guid,
					"RefPartnerFct": "",
					"RefPartnerNo": sap.ui.getCore().byId("BpNo").getValue(),
					"Name1Text": sap.ui.getCore().byId("BpName").getValue(),
					"Indicator": true
				});

				oTable.setModel();

				oTable.setModel(this.TechCommiteeModel, "CommitteModel");
				oTable.getModel("CommitteModel").refresh(true);

				sap.ui.getCore().byId("BpNo").setValue();
				sap.ui.getCore().byId("BpName").setValue();
				this.onCancel();
			}
		},

		onCancel: function () {
			//Cater for the age group selected 
			var oDialogKey,
				oDialogValue;

			for (oDialogKey in this._mViewSettingsDialogs) {
				oDialogValue = this._mViewSettingsDialogs[oDialogKey];

				if (oDialogValue) {
					oDialogValue.close();
					// oDialogValue = null;
				}
			}
		},

		createFormDialog: function (sDialogFragmentName) {

			// https://stackoverflow.com/questions/55667673/how-to-remove-duplicates-and-display-only-unique-values-in-viewsettingsitem
			var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
				this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;

				if (Device.system.desktop) {
					oDialog.addStyleClass("sapUiSizeCompact");
				}
			}
			return oDialog;
		},

		onAddBP: function () {
			this.createFormDialog("gdsd.FundingApplicationProcess.ApplicationFundProcess.view.fragments.BusinessPartner").open();
		},

		onAddProduct: function (oEvent) {
			if (!this._ProductDialog) {
				this._ProductDialog = sap.ui.xmlfragment(
					"gdsd.FundingApplicationProcess.ApplicationFundProcess.view.fragments.Products", this);
				this.getView().addDependent(this._ProductDialog);
				this._ProductDialog.open();
			} else {
				this._ProductDialog.open();
			}
		},

		onValueHelpRequest: function (oEvent) {

			if (!this._oValueHelpDialog) {
				this._oValueHelpDialog = sap.ui.xmlfragment(
					"gdsd.FundingApplicationProcess.ApplicationFundProcess.view.fragments.BusinessPartnerList", this);
				this.getView().addDependent(this._oValueHelpDialog);
				this._oValueHelpDialog.open();
			} else {
				this._oValueHelpDialog.open();
			}
		},

		onValueHelpSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("BpName", FilterOperator.Contains, sValue);

			oEvent.getSource().getBinding("items").filter([oFilter]);
		},

		onValueHelpClose: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			oEvent.getSource().getBinding("items").filter([]);

			if (!oSelectedItem) {
				return;
			}

			sap.ui.getCore().byId("BpNo").setValue(oSelectedItem.getTitle());
			sap.ui.getCore().byId("BpName").setValue(oSelectedItem.getDescription());
		},

		onSubmitCapacity: function () {

			var aItems = [],
				oItem = {},
				oItemsProducts = {},
				aItemProducts = [];

			var batchChanges = [],
				batchModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDSD_CRM_UI5_APP_SRV/");

			// for (var i = 0; i < this.TechCommiteeModel.getData().data.length; i++) {
			// 	oItem = this.TechCommiteeModel.getData().data[i];
			// 	//oItem.ParentId = this._ObjectGuid;
			// 	aItems.push(oItem);
			// }

			// if (aItems.length > 0) {
			// 	for (var t = 0; t < aItems.length; t++) {
			// 		batchChanges.push(batchModel.createBatchOperation("/GetTechnicalCommitteeSet", "POST", aItems[t]));
			// 	}
			// }

			for (var i = 0; i < this._productModel.getData().data.length; i++) {
				oItemsProducts.Applicationguid = this._productModel.getData().data[i].Applicationguid;
				oItemsProducts.Itemguid = "";
				oItemsProducts.Quantity = this._productModel.getData().data[i].Qty;
				oItemsProducts.Uom = this._productModel.getData().data[i].UoM;
				oItemsProducts.Productguid = this._productModel.getData().data[i].Productguid;
				oItemsProducts.Productid = this._productModel.getData().data[i].Productid;
				oItemsProducts.Description = this._productModel.getData().data[i].Productid;
				oItemsProducts.Amount = this._productModel.getData().data[i].Amount;
				oItemsProducts.Producttype = this._productModel.getData().data[i].Producttype;
				oItemsProducts.Totalamount = this._productModel.getData().data[i].Totalamount;
				aItemProducts.push(oItemsProducts);
				oItemsProducts = {};
			}

			if (aItemProducts.length > 0) {
				for (var k = 0; k < aItemProducts.length; k++) {
					batchChanges.push(batchModel.createBatchOperation("/GetApplicationItemsSet", "POST", aItemProducts[k]));
				}

				batchModel.addBatchChangeOperations(batchChanges);
				batchModel.setUseBatch(true);

				sap.ui.core.BusyIndicator.show();
				//submit Batch and refresh the table
				batchModel.submitBatch(function (data) {
					var parser = new DOMParser(),
						xmlDoc;

					sap.ui.core.BusyIndicator.hide();

					if (data.__batchResponses[0]) {
						if (data.__batchResponses[0].__changeResponses) {
							if (data.__batchResponses[0].__changeResponses[0].statusCode.startsWith('2')) {
								this.successAndNavigate();
							} else {
								MessageBox.error("Error occured while processing an application");
							}
						} else {
							MessageBox.error("Error occured while processing an application");
						}
					}
					batchModel.resetChanges();
					batchModel.refresh();
				}.bind(this), function (err) {
					//MessageBox.error("Connection error. Check if you're connected.");
					sap.ui.core.BusyIndicator.hide();
				});
			} else {
				sap.ui.core.BusyIndicator.hide();
				this.successAndNavigate();
			}

		},

		getTechicalCommitee: function (vGuid) {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("RefGuid", "EQ", vGuid);
			var oTable = this.byId("tblPanelMembers");

			this._oODataModel.read("/GetTechnicalCommitteeSet", {
				filters: [oFilter],
				success: function (odata) {
					this.TechCommiteeModel.getData().data = odata.results;
					oTable.setModel();
					oTable.setModel(this.TechCommiteeModel, "CommitteModel");
					oTable.getModel("CommitteModel").refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve technical commitee details");
				}.bind(this)
			});
		},

		onPressProduct: function (oEvent) {
			this.Router.navTo("ProductLineItems", {
				//prepare object path to be passed on to target
				ProductPath: window.encodeURIComponent(oEvent.getSource().getBindingContext("ZDSD_CRM_UI5").getPath().substr(1)),
				ProcessPath: window.encodeURIComponent(this.sPath.substr(1)),
				TaskType: this.TaskType
			});
		},

		onSelectProduct: function (oEvent) {

			var oTable = this.byId("LineItemsTable");
			var oSelectedItem = oEvent.getParameter("selectedItem");

			var oPath = oSelectedItem.getBindingContext("ZDSD_CRM_UI5").getPath();
			var oProperty = this._oODataModel.getProperty(oPath);

			this._productModel.getData().data.push({
				"Applicationguid": this.ApplicGuid,
				"Itemguid": "",
				"Productguid": oProperty.ProductGuid,
				"Productid": oProperty.ProductId,
				"Description": oProperty.ProductId,
				"Amount": oProperty.Kbetr,
				"Producttype": "",
				"Totalamount": "",
				"Qty": "",
				"UoM": oProperty.Kmein
			});

			oTable.setModel();

			oTable.setModel(this._productModel, "ProductLineItemsModel");
			oTable.getModel("ProductLineItemsModel").refresh(true);
		},

		onProductSearch: function (oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilter = new Filter("ProductId", FilterOperator.Contains, sValue);

			oEvent.getSource().getBinding("items").filter([oFilter]);
		},

		onDeleteLineItems: function (oEvent) {
			//Delete Row 
			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("ProductLineItemsModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("ProductLineItemsModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this._productModel.refresh();
		},

		onCalculateTotal: function (oEvent) {
			var Qty = parseFloat(oEvent.getSource().getParent().getCells()[4].getValue());
			var Price = parseFloat(oEvent.getSource().getParent().getCells()[3].getText());

			var total = Price * Qty;

			if (isNaN(total)) {
				oEvent.getSource().getParent().getCells()[5].setText();
			} else {
				oEvent.getSource().getParent().getCells()[5].setText(total);
			}

		},

		validateLineItemsAndTechCommiteeNotes: function (oEvent) {
			var oTable = this.byId("LineItemsTable");
			var oRows = oTable.getItems();

			if (oRows.length > 0) {
				for (var counter = 0; counter < oRows.length; ++counter) {
					if (oRows[counter].getCells()[0].getValue() === "") {
						MessageBox.error("Select Product type in all the rows");
						return;
					}

					if (oRows[counter].getCells()[4].getValue() === "") {
						MessageBox.error("Please input quantity in all the rows");
						return;
					}
				}
			} else {
				MessageBox.error("Please make sure you capture line items under Products");
				return;
			}

			//Validate Technical Committee Notes
			if (this.byId("adminComplNotes").getValue() === "") {
				MessageBox.error("Please capture notes under Administrative Compliance");
				return;
			}

			if (this.byId("programmeViabilityNotes").getValue() === "") {
				MessageBox.error("Please capture notes under Programme Viability & Eligibility");
				return;
			}

			if (this.byId("previousprogNotes").getValue() === "") {
				MessageBox.error("Please capture notes under Previous Programme Performance");
				return;
			}

			if (this.byId("previousperfomanceNotes").getValue() === "") {
				MessageBox.error("Please capture notes under Previous Financial Performance");
				return;
			}

			if (this.byId("overallRecommendationsNotes").getValue() === "") {
				MessageBox.error("Please capture notes under Overall Recommendations");
				return;
			}

			this.onApproveTask();

		},

		onDeleteCommitte: function (oEvent) {

			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("CommitteModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("CommitteModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this.TechCommiteeModel.refresh(true);

			//alert("Entry Successfully Deleted");
		},

		validateApprove: function () {
			if (this.Property.TaskType === "ZT03") {
				this.validateLineItemsAndTechCommiteeNotes();
			} else {
				this.onApproveTask();
			}
		},

		validateReject: function () {
			if (this.Property.TaskType === "ZT03") {
				//Validate Technical Committee Notes
				if (this.byId("adminComplNotes").getValue() === "") {
					MessageBox.error("Please capture notes under Administrative Compliance");
					return;
				}

				if (this.byId("programmeViabilityNotes").getValue() === "") {
					MessageBox.error("Please capture notes under Programme Viability & Eligibility");
					return;
				}

				if (this.byId("previousprogNotes").getValue() === "") {
					MessageBox.error("Please capture notes under Previous Programme Performance");
					return;
				}

				if (this.byId("previousperfomanceNotes").getValue() === "") {
					MessageBox.error("Please capture notes under Previous Financial Performance");
					return;
				}

				if (this.byId("overallRecommendationsNotes").getValue() === "") {
					MessageBox.error("Please capture notes under Overall Recommendations");
					return;
				}

				this.onRejectTask();
			} else {
				this.onRejectTask();
			}
		},

		onSubmit: function () {
			this.getView().getModel().getData().data.Status = "E0003";
			this.onUpdate();
		}

	});

});