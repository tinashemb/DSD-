sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/Device"
], function(Controller, Filter, FilterOperator, MessageBox, Device) {
	"use strict";

	return Controller.extend("gdsd.FundingApplicationProcess.ApplicationFundProcess.controller.ApplicationInfo", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.FundingApplicationProcess.ApplicationFundProcess.view.ApplicationInfo
		 */
		onInit: function() {
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this._processModel = this.getOwnerComponent().getModel("ApplicationProcessing");
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this._mViewSettingsDialogs = {};
			this.TargetGroupModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.BeneficiariesModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.CapacityModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.Router.getRoute("ApplicationInfo").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function(e) {

			this.CapacityModel.getData().data = [];
			this.BeneficiariesModel.getData().data = [];
			this.TargetGroupModel.getData().data = [];

			//this.RestoreModels();

			this.sPath = "/" + window.decodeURIComponent(e.getParameter("arguments").Path);

			if (e.getParameter("arguments").Path !== undefined) {
				this.oProperty = this._processModel.getProperty(this.sPath);
				this.RestoreModels();
				this.getApplicationData(this.Guid);

				var ApplicationProcessModel = new sap.ui.model.json.JSONModel({
					data: this.oProperty
				});

				//Set Binding Mode
				ApplicationProcessModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
				
				this.byId("TaskNumber").setText(this.oProperty.ObjectId);

				this.byId("formCommentNPODet").setModel(ApplicationProcessModel);
				this.byId("formCommentNPODet").bindElement({
					path: "/data"
				});

				this.byId("formCommentApplicDet").setModel(ApplicationProcessModel);
				this.byId("formCommentApplicDet").bindElement({
					path: "/data"
				});

				this.byId("formCommentProgV").setModel(ApplicationProcessModel);
				this.byId("formCommentProgV").bindElement({
					path: "/data"
				});

				this.byId("formCommentArchiev").setModel(ApplicationProcessModel);
				this.byId("formCommentArchiev").bindElement({
					path: "/data"
				});

				this.byId("formCommentChallenge").setModel(ApplicationProcessModel);
				this.byId("formCommentChallenge").bindElement({
					path: "/data"
				});

				this.byId("formCommentCapacity").setModel(ApplicationProcessModel);
				this.byId("formCommentCapacity").bindElement({
					path: "/data"
				});

				this.byId("formCommentFund").setModel(ApplicationProcessModel);
				this.byId("formCommentFund").bindElement({
					path: "/data"
				});

				this.byId("formCommentCost").setModel(ApplicationProcessModel);
				this.byId("formCommentCost").bindElement({
					path: "/data"
				});

				this.byId("formCommentSust").setModel(ApplicationProcessModel);
				this.byId("formCommentSust").bindElement({
					path: "/data"
				});

				this.byId("formCommentMonitor").setModel(ApplicationProcessModel);
				this.byId("formCommentMonitor").bindElement({
					path: "/data"
				});

				this.byId("formCommentNetworks").setModel(ApplicationProcessModel);
				this.byId("formCommentNetworks").bindElement({
					path: "/data"
				});
				
				this.formatUI();
			}
		},

		getApplicationData: function() {

			sap.ui.core.BusyIndicator.show(0);
			this._oODataModel.read("/GetCRAGRelatedApplicationSet(Guid='" + this.oProperty.Guid + "')", {
				success: function(odata) {
					if (odata) {
						var ApplicationJsonModel = new sap.ui.model.json.JSONModel({
							data: odata
						});

						//Get Application Guid
						this.ApplicGuid = odata.Guid;

						//Set Binding Mode
						ApplicationJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

						this.byId("headerNPO").setTitle("Application: " + odata.ObjectId);

						this.byId("detailPage").setTitle(odata.But000.McName1);
						if (odata.Statu.Status === "I1002") {
							this.byId("Status").setText(odata.Statu.Txt30);
							this.byId("Status").setState("Success");
						} else {
							this.byId("Status").setText(odata.Statu.Txt30);
							this.byId("Status").setState("Error");
						}

						this.byId("BankName").setValue(odata.Bankname.Banka);

						if (odata.Banking.Bkont === "01") {
							this.byId("BankType").setValue("Current Account");
						} else if (odata.Banking.Bkont === "02") {
							this.byId("BankType").setValue("Savings Account");
						} else if (odata.Banking.Bkont === "03") {
							this.byId("BankType").setValue("Loan Account");
						} else if (odata.Banking.Bkont === "04") {
							this.byId("BankType").setValue("General Ledger");
						}
					}

					//this.byId("btnSubmit").setVisible(false);

					this.byId("headerNPO").setModel(ApplicationJsonModel);
					this.byId("headerNPO").bindElement({
						path: "/data"
					});

					this.byId("formOrg").setModel(ApplicationJsonModel);
					this.byId("formOrg").bindElement({
						path: "/data"
					});

					this.byId("formAdrc").setModel(ApplicationJsonModel);
					this.byId("formAdrc").bindElement({
						path: "/data"
					});

					this.byId("formContacts").setModel(ApplicationJsonModel);
					this.byId("formContacts").bindElement({
						path: "/data"
					});

					this.byId("formBank").setModel(ApplicationJsonModel);
					this.byId("formBank").bindElement({
						path: "/data"
					});

					this.byId("formApplication").setModel(ApplicationJsonModel);
					this.byId("formApplication").bindElement({
						path: "/data"
					});

					this.byId("formViability").setModel(ApplicationJsonModel);
					this.byId("formViability").bindElement({
						path: "/data"
					});

					this.byId("formSustain").setModel(ApplicationJsonModel);
					this.byId("formSustain").bindElement({
						path: "/data"
					});

					this.byId("formMonitorNPO").setModel(ApplicationJsonModel);
					this.byId("formMonitorNPO").bindElement({
						path: "/data"
					});

					this.byId("formCapacity").setModel(ApplicationJsonModel);
					this.byId("formCapacity").bindElement({
						path: "/data"
					});

					this.byId("formFundingReq").setModel(ApplicationJsonModel);
					this.byId("formFundingReq").bindElement({
						path: "/data"
					});

					this.byId("formAchievements").setModel(ApplicationJsonModel);
					this.byId("formAchievements").bindElement({
						path: "/data"
					});

					this.byId("formChallenges").setModel(ApplicationJsonModel);
					this.byId("formChallenges").bindElement({
						path: "/data"
					});

					this.byId("formNetworks").setModel(ApplicationJsonModel);
					this.byId("formNetworks").bindElement({
						path: "/data"
					});

					this.byId("formOverviewAppDet").setModel(ApplicationJsonModel);
					this.byId("formOverviewAppDet").bindElement({
						path: "/data"
					});

					this.byId("formOverviewProgramV").setModel(ApplicationJsonModel);
					this.byId("formOverviewProgramV").bindElement({
						path: "/data"
					});

					this.byId("formOverviewAchievements").setModel(ApplicationJsonModel);
					this.byId("formOverviewAchievements").bindElement({
						path: "/data"
					});

					this.byId("formOverviewChallenges").setModel(ApplicationJsonModel);
					this.byId("formOverviewChallenges").bindElement({
						path: "/data"
					});

					this.byId("formOverviewCapacityB").setModel(ApplicationJsonModel);
					this.byId("formOverviewCapacityB").bindElement({
						path: "/data"
					});

					this.byId("formOverviewFunding").setModel(ApplicationJsonModel);
					this.byId("formOverviewFunding").bindElement({
						path: "/data"
					});

					this.byId("formOverviewSummaryC").setModel(ApplicationJsonModel);
					this.byId("formOverviewSummaryC").bindElement({
						path: "/data"
					});

					this.byId("formOverviewSustain").setModel(ApplicationJsonModel);
					this.byId("formOverviewSustain").bindElement({
						path: "/data"
					});

					this.byId("formOverviewMonitor").setModel(ApplicationJsonModel);
					this.byId("formOverviewMonitor").bindElement({
						path: "/data"
					});

					this.byId("formOverviewNetworks").setModel(ApplicationJsonModel);
					this.byId("formOverviewNetworks").bindElement({
						path: "/data"
					});

					this.getView().setModel(ApplicationJsonModel);

					//ECM Intergration
					var SAPObj, ObjId;
					SAPObj = 'BUS2000270';
					ObjId = this.ApplicGuid;
					//destroy content on the attachment Icon Tab Filer 
					this.byId("WPFilter").destroyContent();
					//create an HTML object so that an iFrame can be added
					var html = new sap.ui.core.HTML();
					//adding a standard Fiori ECM application to the iframe and pass necessary url parameters 
					html.setContent("<div class='FrameWrapper'><iframe id='EcmFrame' src='/sap/bc/ui5_ui5/sap/zrmf_bws_ui/index.html?SAPObj=" +
						SAPObj +
						"&ObjId=" + ObjId + "' width='1200px' height='500px'></iframe></div>");
					//adding the html object to the Icon Tab filter
					this.byId("WPFilter").addContent(html);
					this.getCapacities(odata.Guid);

				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve application details");
				}.bind(this)
			});
		},

		getCapacities: function(vGuid) {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("RecordId", "EQ", vGuid);

			this._oODataModel.read("/GetCapacitySet", {
				filters: [oFilter],
				success: function(odata) {

					//Distribute capacity data
					this.distrubuteCapacity(odata.results);
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve capacity details");
				}.bind(this)
			});
		},

		distrubuteCapacity: function(arrCapacity) {
			for (var capacity = 0; capacity < arrCapacity.length; capacity++) {

				switch (arrCapacity[capacity].Zztype) {
					case "BENEF":
						this.BeneficiariesModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "TARG":
						this.TargetGroupModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "STAFF":
					case "BOARD":
						this.CapacityModel.getData().data.push(arrCapacity[capacity]);
						break;
				}
			}

			this.RestoreModels();

		},

		RestoreModels: function(oEvent) {

			var oTableTarget = this.byId("targetTable");
			var oTableCapacity = this.byId("BoardCapacity");
			var oTableBeneficiary = this.byId("beneficiariesTable");

			oTableBeneficiary.setModel(this.BeneficiariesModel, "BeneficiariesModel");
			oTableBeneficiary.getModel("BeneficiariesModel").refresh(true);

			oTableCapacity.setModel(this.CapacityModel, "CapacityModel");
			oTableCapacity.getModel("CapacityModel").refresh(true);

			oTableTarget.setModel(this.TargetGroupModel, "TargetModel");
			oTableTarget.getModel("TargetModel").refresh(true);

			//sap.ui.core.BusyIndicator.hide();
			this.getOnceOffCosts();

		},

		onNpoNextPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("application");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onApplicationDeteailsPrevPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("npo");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onApplicationDetailsNextPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("programme");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onProgramViabilityPrevPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("application");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onProgramViabilityNextPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("achievements");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAchievementNextPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("challenges");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAchievementPrevPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("programme");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onChallengesNextPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("capacity");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onChallengesPrevPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("achievements");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCapacityNextPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("funding");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCapacityPrevPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("challenges");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onFundingNextPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("cost");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onFundingPrevPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("capacity");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCostNextPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("sustainability");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCostPrevPress: function() {
			//.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("funding");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSustanabilityNextPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("monitoring");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSustanabilityPrevPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("cost");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onMonitoringNextPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("networks");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onMonitoringPrevPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("sustainability");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onNetworksNextPress: function() {
			//this.byId("btnSubmit").setVisible(true);
			this.byId("IconBar").setSelectedKey("attachments");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onNetworksPrevPress: function() {
			//this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("monitoring");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAttachmentsNextPress: function() {
			this.byId("IconBar").setSelectedKey("beneficiary");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAttachmentsPrevPress: function() {
			this.byId("IconBar").setSelectedKey("particular");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCRNextPress: function() {
			this.byId("IconBar").setSelectedKey("particular");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCRPrevPress: function() {
			this.byId("IconBar").setSelectedKey("particular");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSummary: function() {

			var oTableTarget = this.byId("targetTable");
			var oTableCapacity = this.byId("BoardCapacity");
			var oTableBeneficiary = this.byId("beneficiariesTable");

			this.byId("btnSubmit").setVisible(true);
			this.byId("IconBar").setSelectedKey("overview");
			this.byId("detailPage").scrollTo(0, 0);

			this.byId("AppTargetGroup1").setText(oTableTarget.getModel("TargetModel").getData().data.length);
			this.byId("AppNumberofBeneficiaries1").setText(oTableBeneficiary.getModel("BeneficiariesModel").getData().data.length);
			this.byId("AppCapacityofBoardStaff1").setText(oTableCapacity.getModel("CapacityModel").getData().data.length);
		},

		handleIconTabBarSelect: function(oEvent) {
			var sKey = oEvent.getParameter("key");

			//	if (sKey === "attachments") {
			//	this.byId("btnSubmit").setVisible(false);
			//	} else {
			//	this.byId("btnSubmit").setVisible(false);
			//	}
			if (sKey === "overview") {
				this.onSummary();
			}
		},

		onNavBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ApplicationProcess", true);
		},

		onProcess: function() {

//			this.Router.navTo("Processing", {
			this.Router.navTo("SWMETechNPI_Processing", {
				//prepare object path to be passed on to target
				TaskType: this.oProperty.TaskType,
				Path: window.encodeURIComponent(this.sPath.substr(1)),
				ApplicGuid: this.ApplicGuid
			});
		},

		onPressBeneficiary: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogBeneficiary = this.createFormDialog(
				"gdsd.FundingApplicationProcess.ApplicationFundProcess.view.fragments.Beneficiariers");

			this._DialogBeneficiary.setModel(this.BeneficiariesModel);
			this._DialogBeneficiary.bindElement(oBindingContextPath);

			this._DialogBeneficiary.open();

		},

		onPressTarget: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogTarget = this.createFormDialog("gdsd.FundingApplicationProcess.ApplicationFundProcess.view.fragments.TargetGroup");

			this._DialogTarget.setModel(this.TargetGroupModel);
			this._DialogTarget.bindElement(oBindingContextPath);

			this._DialogTarget.open();

		},

		onPressCapacity: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogTarget = this.createFormDialog("gdsd.FundingApplicationProcess.ApplicationFundProcess.view.fragments.Capacity");

			this._DialogTarget.setModel(this.CapacityModel);
			this._DialogTarget.bindElement(oBindingContextPath);

			this._DialogTarget.open();

		},

		createFormDialog: function(sDialogFragmentName) {

			// https://stackoverflow.com/questions/55667673/how-to-remove-duplicates-and-display-only-unique-values-in-viewsettingsitem
			var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
				this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;

				if (Device.system.desktop) {
					oDialog.addStyleClass("sapUiSizeCompact");
				}
			}
			return oDialog;
		},

		formatUI: function() {

			switch (this.oProperty.TaskType) {
				case "ZT01":
					this.byId("NPOSWNotes").setVisible(true);
					this.byId("NPOSWNotes").setEnabled(true);
					this.byId("NPOSupNotes").setVisible(false);
					this.byId("NPOTechNotes").setVisible(false);

					this.byId("AppDetSWNotes").setVisible(true);
					this.byId("AppDetSWNotes").setEnabled(true);
					this.byId("AppDetSupNotes").setVisible(false);
					this.byId("AppDetTechNotes").setVisible(false);

					this.byId("ProgVSWNotes").setVisible(true);
					this.byId("ProgVSWNotes").setEnabled(true);
					this.byId("ProgVSupNotes").setVisible(false);
					this.byId("ProgVTechNotes").setVisible(false);

					this.byId("AchievSWNotes").setVisible(true);
					this.byId("AchievSWNotes").setEnabled(true);
					this.byId("AchievSupNotes").setVisible(false);
					this.byId("AchievTechNotes").setVisible(false);

					this.byId("ChallSWNotes").setVisible(true);
					this.byId("ChallSWNotes").setEnabled(true);
					this.byId("ChallSupNotes").setVisible(false);
					this.byId("ChallTechNotes").setVisible(false);

					this.byId("CapacitySWNotes").setVisible(true);
					this.byId("CapacitySWNotes").setEnabled(true);
					this.byId("CapacitySupNotes").setVisible(false);
					this.byId("CapacityTechNotes").setVisible(false);

					this.byId("FundSWNotes").setVisible(true);
					this.byId("FundSWNotes").setEnabled(true);
					this.byId("FundSupNotes").setVisible(false);
					this.byId("FundTechNotes").setVisible(false);

					this.byId("CostSWNotes").setVisible(true);
					this.byId("CostSWNotes").setEnabled(true);
					this.byId("CostSupNotes").setVisible(false);
					this.byId("CostTechNotes").setVisible(false);

					this.byId("SustSWNotes").setVisible(true);
					this.byId("SustSWNotes").setEnabled(true);
					this.byId("SustSupNotes").setVisible(false);
					this.byId("SustTechNotes").setVisible(false);

					this.byId("MonSWNotes").setVisible(true);
					this.byId("MonSWNotes").setEnabled(true);
					this.byId("MonSupNotes").setVisible(false);
					this.byId("MonTechNotes").setVisible(false);

					this.byId("NetSWNotes").setVisible(true);
					this.byId("NetSWNotes").setEnabled(true);
					this.byId("NetSupNotes").setVisible(false);
					this.byId("NetTechNotes").setVisible(false);

					break;
				case "ZT03":
					this.byId("NPOSWNotes").setVisible(true);
					this.byId("NPOSWNotes").setEnabled(false);
					this.byId("NPOSupNotes").setVisible(true);
					this.byId("NPOSupNotes").setEnabled(true);
					this.byId("NPOTechNotes").setVisible(false);

					this.byId("AppDetSWNotes").setVisible(true);
					this.byId("AppDetSWNotes").setEnabled(false);
					this.byId("AppDetSupNotes").setVisible(true);
					this.byId("AppDetSupNotes").setEnabled(true);
					this.byId("AppDetTechNotes").setVisible(false);

					this.byId("ProgVSWNotes").setVisible(true);
					this.byId("ProgVSWNotes").setEnabled(false);
					this.byId("ProgVSupNotes").setVisible(true);
					this.byId("ProgVSupNotes").setEnabled(true);
					this.byId("ProgVTechNotes").setVisible(false);

					this.byId("AchievSWNotes").setVisible(true);
					this.byId("AchievSWNotes").setEnabled(false);
					this.byId("AchievSupNotes").setVisible(true);
					this.byId("AchievSupNotes").setEnabled(true);
					this.byId("AchievTechNotes").setVisible(false);

					this.byId("ChallSWNotes").setVisible(true);
					this.byId("ChallSWNotes").setEnabled(false);
					this.byId("ChallSupNotes").setVisible(true);
					this.byId("ChallSupNotes").setEnabled(true);
					this.byId("ChallTechNotes").setVisible(false);

					this.byId("CapacitySWNotes").setVisible(true);
					this.byId("CapacitySWNotes").setEnabled(false);
					this.byId("CapacitySupNotes").setVisible(true);
					this.byId("CapacitySupNotes").setEnabled(true);
					this.byId("CapacityTechNotes").setVisible(false);

					this.byId("FundSWNotes").setVisible(true);
					this.byId("FundSWNotes").setEnabled(false);
					this.byId("FundSupNotes").setVisible(true);
					this.byId("FundSupNotes").setEnabled(true);
					this.byId("FundTechNotes").setVisible(false);

					this.byId("CostSWNotes").setVisible(true);
					this.byId("CostSWNotes").setEnabled(false);
					this.byId("CostSupNotes").setVisible(true);
					this.byId("CostSupNotes").setEnabled(true);
					this.byId("CostTechNotes").setVisible(false);

					this.byId("SustSWNotes").setVisible(true);
					this.byId("SustSWNotes").setEnabled(false);
					this.byId("SustSupNotes").setVisible(true);
					this.byId("SustSupNotes").setEnabled(true);
					this.byId("SustTechNotes").setVisible(false);

					this.byId("MonSWNotes").setVisible(true);
					this.byId("MonSWNotes").setEnabled(false);
					this.byId("MonSupNotes").setVisible(true);
					this.byId("MonSupNotes").setEnabled(true);
					this.byId("MonTechNotes").setVisible(false);

					this.byId("NetSWNotes").setVisible(true);
					this.byId("NetSWNotes").setEnabled(false);
					this.byId("NetSupNotes").setVisible(true);
					this.byId("NetSupNotes").setEnabled(true);
					this.byId("NetTechNotes").setVisible(false);

					break;
				case "ZT04":
					this.byId("NPOSWNotes").setVisible(true);
					this.byId("NPOSWNotes").setEnabled(false);
					this.byId("NPOSupNotes").setVisible(true);
					this.byId("NPOSupNotes").setEnabled(false);
					this.byId("NPOTechNotes").setVisible(true);
					this.byId("NPOTechNotes").setEnabled(true);

					this.byId("AppDetSWNotes").setVisible(true);
					this.byId("AppDetSWNotes").setEnabled(false);
					this.byId("AppDetSupNotes").setVisible(true);
					this.byId("AppDetSupNotes").setEnabled(false);
					this.byId("AppDetTechNotes").setVisible(true);
					this.byId("AppDetTechNotes").setEnabled(true);

					this.byId("ProgVSWNotes").setVisible(true);
					this.byId("ProgVSWNotes").setEnabled(false);
					this.byId("ProgVSupNotes").setVisible(true);
					this.byId("ProgVSupNotes").setEnabled(false);
					this.byId("ProgVTechNotes").setVisible(true);
					this.byId("ProgVTechNotes").setEnabled(true);

					this.byId("AchievSWNotes").setVisible(true);
					this.byId("AchievSWNotes").setEnabled(false);
					this.byId("AchievSupNotes").setVisible(true);
					this.byId("AchievSupNotes").setEnabled(false);
					this.byId("AchievTechNotes").setVisible(true);
					this.byId("AchievTechNotes").setEnabled(true);

					this.byId("ChallSWNotes").setVisible(true);
					this.byId("ChallSWNotes").setEnabled(false);
					this.byId("ChallSupNotes").setVisible(true);
					this.byId("ChallSupNotes").setEnabled(false);
					this.byId("ChallTechNotes").setVisible(true);
					this.byId("ChallTechNotes").setEnabled(true);

					this.byId("CapacitySWNotes").setVisible(true);
					this.byId("CapacitySWNotes").setEnabled(false);
					this.byId("CapacitySupNotes").setVisible(true);
					this.byId("CapacitySupNotes").setEnabled(false);
					this.byId("CapacityTechNotes").setVisible(true);
					this.byId("CapacityTechNotes").setEnabled(true);

					this.byId("FundSWNotes").setVisible(true);
					this.byId("FundSWNotes").setEnabled(false);
					this.byId("FundSupNotes").setVisible(true);
					this.byId("FundSupNotes").setEnabled(false);
					this.byId("FundTechNotes").setVisible(true);
					this.byId("FundTechNotes").setEnabled(true);

					this.byId("CostSWNotes").setVisible(true);
					this.byId("CostSWNotes").setEnabled(false);
					this.byId("CostSupNotes").setVisible(true);
					this.byId("CostSupNotes").setEnabled(false);
					this.byId("CostTechNotes").setVisible(true);
					this.byId("CostTechNotes").setEnabled(true);

					this.byId("SustSWNotes").setVisible(true);
					this.byId("SustSWNotes").setEnabled(false);
					this.byId("SustSupNotes").setVisible(true);
					this.byId("SustSupNotes").setEnabled(false);
					this.byId("SustTechNotes").setVisible(true);
					this.byId("SustTechNotes").setEnabled(true);

					this.byId("MonSWNotes").setVisible(true);
					this.byId("MonSWNotes").setEnabled(false);
					this.byId("MonSupNotes").setVisible(true);
					this.byId("MonSupNotes").setEnabled(false);
					this.byId("MonTechNotes").setVisible(true);
					this.byId("MonTechNotes").setEnabled(true);

					this.byId("NetSWNotes").setVisible(true);
					this.byId("NetSWNotes").setEnabled(false);
					this.byId("NetSupNotes").setVisible(true);
					this.byId("NetSupNotes").setEnabled(false);
					this.byId("NetTechNotes").setVisible(true);
					this.byId("NetTechNotes").setEnabled(true);
					break;

				case "ZT05":

                    this.byId("NPOSWNotes").setVisible(true);
					this.byId("NPOSWNotes").setEnabled(false);
					this.byId("NPOSupNotes").setVisible(true);
					this.byId("NPOSupNotes").setEnabled(false);
					this.byId("NPOTechNotes").setVisible(true);
					this.byId("NPOTechNotes").setEnabled(false);

					this.byId("AppDetSWNotes").setVisible(true);
					this.byId("AppDetSWNotes").setEnabled(false);
					this.byId("AppDetSupNotes").setVisible(true);
					this.byId("AppDetSupNotes").setEnabled(false);
					this.byId("AppDetTechNotes").setVisible(true);
					this.byId("AppDetTechNotes").setEnabled(false);

					this.byId("ProgVSWNotes").setVisible(true);
					this.byId("ProgVSWNotes").setEnabled(false);
					this.byId("ProgVSupNotes").setVisible(true);
					this.byId("ProgVSupNotes").setEnabled(false);
					this.byId("ProgVTechNotes").setVisible(true);
					this.byId("ProgVTechNotes").setEnabled(false);

					this.byId("AchievSWNotes").setVisible(true);
					this.byId("AchievSWNotes").setEnabled(false);
					this.byId("AchievSupNotes").setVisible(true);
					this.byId("AchievSupNotes").setEnabled(false);
					this.byId("AchievTechNotes").setVisible(true);
					this.byId("AchievTechNotes").setEnabled(false);

					this.byId("ChallSWNotes").setVisible(true);
					this.byId("ChallSWNotes").setEnabled(false);
					this.byId("ChallSupNotes").setVisible(true);
					this.byId("ChallSupNotes").setEnabled(false);
					this.byId("ChallTechNotes").setVisible(true);
					this.byId("ChallTechNotes").setEnabled(false);

					this.byId("CapacitySWNotes").setVisible(true);
					this.byId("CapacitySWNotes").setEnabled(false);
					this.byId("CapacitySupNotes").setVisible(true);
					this.byId("CapacitySupNotes").setEnabled(false);
					this.byId("CapacityTechNotes").setVisible(true);
					this.byId("CapacityTechNotes").setEnabled(false);

					this.byId("FundSWNotes").setVisible(true);
					this.byId("FundSWNotes").setEnabled(false);
					this.byId("FundSupNotes").setVisible(true);
					this.byId("FundSupNotes").setEnabled(false);
					this.byId("FundTechNotes").setVisible(true);
					this.byId("FundTechNotes").setEnabled(false);

					this.byId("CostSWNotes").setVisible(true);
					this.byId("CostSWNotes").setEnabled(false);
					this.byId("CostSupNotes").setVisible(true);
					this.byId("CostSupNotes").setEnabled(false);
					this.byId("CostTechNotes").setVisible(true);
					this.byId("CostTechNotes").setEnabled(false);

					this.byId("SustSWNotes").setVisible(true);
					this.byId("SustSWNotes").setEnabled(false);
					this.byId("SustSupNotes").setVisible(true);
					this.byId("SustSupNotes").setEnabled(false);
					this.byId("SustTechNotes").setVisible(true);
					this.byId("SustTechNotes").setEnabled(false);

					this.byId("MonSWNotes").setVisible(true);
					this.byId("MonSWNotes").setEnabled(false);
					this.byId("MonSupNotes").setVisible(true);
					this.byId("MonSupNotes").setEnabled(false);
					this.byId("MonTechNotes").setVisible(true);
					this.byId("MonTechNotes").setEnabled(false);

					this.byId("NetSWNotes").setVisible(true);
					this.byId("NetSWNotes").setEnabled(false);
					this.byId("NetSupNotes").setVisible(true);
					this.byId("NetSupNotes").setEnabled(false);
					this.byId("NetTechNotes").setVisible(true);
					this.byId("NetTechNotes").setEnabled(false);
					break;
			}
		},
		
		getOnceOffCosts: function() {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("RecordId", "EQ", this.ApplicGuid);

			this._oODataModel.read("/GetOnceOffCostSet", {
				filters: [oFilter],
				success: function(odata) {
				   var CostModel = new sap.ui.model.json.JSONModel({
							data: odata.results
						});
					var oTable = this.byId("tableCostImplications1");
					
					oTable.setModel();
					oTable.setModel(CostModel, "CostImplicationsModel");
					oTable.getModel("CostImplicationsModel").refresh(true);
					//sap.ui.core.BusyIndicator.hide();
					this.getCost();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve once off details");
				}.bind(this)
			});
		},

		getCost: function() {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("RecordId", "EQ", this.ApplicGuid);

			this._oODataModel.read("/GetCostSet", {
				filters: [oFilter],
				success: function(odata) {
					var OnceOffCostModel = new sap.ui.model.json.JSONModel({
							data: odata.results
						});
					var oTable = this.byId("OnceOffCostsTable1");
					
					oTable.setModel();
					oTable.setModel(OnceOffCostModel, "OnceOffModel");
					oTable.getModel("OnceOffModel").refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve once off details");
				}.bind(this)
			});
		}

	});

});