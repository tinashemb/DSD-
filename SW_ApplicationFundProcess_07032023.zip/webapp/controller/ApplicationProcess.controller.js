sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox"
], function(Controller, Filter, FilterOperator, History, Sorter, MessageBox) {
	"use strict";

	return Controller.extend("gdsd.FundingApplicationProcess.ApplicationFundProcess.controller.ApplicationProcess", {
			onInit: function() {
				this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
				this._processModel = this.getOwnerComponent().getModel("ApplicationProcessing");
				this._productModel = this.getOwnerComponent().getModel("ProductLineItems");
				this.Router = sap.ui.core.UIComponent.getRouterFor(this);

				this.Router.getRoute("ApplicationProcess").attachPatternMatched(this._onObjectMatched, this);
			},

			_onObjectMatched: function() {
				this._productModel.getData().data = [];
				//this.getView().setModel(this._processModel);
				this.getApplicationProcessData();
			},

			getApplicationProcessData: function() {
				sap.ui.core.BusyIndicator.show(0);

				//var oFilter = new sap.ui.model.Filter("BpNo", "EQ", '1600000202');

				this._oODataModel.read("/GEtApplicationProcessingSet", {
					//filters: [oFilter],
					success: function(odata) {
						var ApplicationJsonModel = new sap.ui.model.json.JSONModel({
							data: odata.results
						});

						this._processModel.getData().data = odata.results;

						//Set Binding Mode
						ApplicationJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

						this.getView().setModel(this._processModel);
						this.getView().getModel().refresh(true);

						sap.ui.core.BusyIndicator.hide();
					}.bind(this),
					error: function(oError) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error("Error occured in the server while trying to retrieve application details");
					}.bind(this)
				});
			},

			onItemPress: function(oEvent) {
				var oProperty = this._processModel.getProperty(oEvent.getSource().getBindingContext().getPath());

				if (oProperty.TaskType === "ZT00") {
					this.Router.navTo("ProgramManager", {
						//prepare object path to be passed on to target
						//Guid: oEvent.getSource().getBindingContext().getProperty("Guid"),
						Path: window.encodeURIComponent(oEvent.getSource().getBindingContext().getPath().substr(1))
					});
				} else {
					this.Router.navTo("ApplicationInfo", {
						//prepare object path to be passed on to target
						//Guid: oEvent.getSource().getBindingContext().getProperty("Guid"),
						Path: window.encodeURIComponent(oEvent.getSource().getBindingContext().getPath().substr(1))
					});
				}
			},
	//	},

		onSearch: function(oEvent) {
			// add filter for search
			//var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var contains = sap.ui.model.FilterOperator.Contains;
				var aFilters = new Filter([
						new sap.ui.model.Filter("ObjectId", contains, sQuery)
						//	new sap.ui.model.Filter("But000/NameOrg2", contains, sQuery)
					],
					false);
			}
			// update list binding
			var oList = this.byId("TaskList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		},

		onNavBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ApplicationInfo", true);
		}
	});
});