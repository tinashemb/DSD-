sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("gdsd.FundingApplicationProcess.ApplicationFundProcess.controller.ProductLineItems", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.FundingApplicationProcess.ApplicationFundProcess.view.ProductLineItems
		 */
		onInit: function () {
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this._productModel = this.getOwnerComponent().getModel("ProductLineItems");
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this._mViewSettingsDialogs = {};

			this.Router.getRoute("ProductLineItems").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function (e) {
            var oTable = this.byId("LineItemsTable");
            
			this.sProductPath = "/" + window.decodeURIComponent(e.getParameter("arguments").ProductPath);
			this.sProcessPath = "/" + window.decodeURIComponent(e.getParameter("arguments").ProcessPath);
			this.TaskType = e.getParameter("arguments").TaskType;
			this.oProperty = this._oODataModel.getProperty(this.sProductPath);
			oTable.setModel();
			oTable.setModel(this._productModel, "ProductLineItemsModel");
			oTable.getModel("ProductLineItemsModel").refresh(true);

		},

		onAddLineItems: function () {

			var oTable = this.byId("LineItemsTable");

			this._productModel.getData().data.push({
				"Applicationguid": "",
				"Itemguid": "",
				"Productguid": this.oProperty.ProductGuid,
				"Productid": this.oProperty.ProductId,
				"Description": this.oProperty.ProductId,
				"Amount": this.oProperty.Kbetr,
				"Producttype": "",
				"Totalamount": "",
				"Qty": "",
				"UoM": this.oProperty.Kmein

			});

			oTable.setModel();

			oTable.setModel(this._productModel, "ProductLineItemsModel");
			oTable.getModel("ProductLineItemsModel").refresh(true);
		},

		onNavBack: function (oEvent) {

			//Validate product line items
			if (this._productModel.getData().data.length === 0) {
				this.Router.navTo("Processing", {
					//prepare object path to be passed on to target
					TaskType: this.TaskType,
					Path: window.encodeURIComponent(this.sProcessPath.substr(1))
				});
			} else {
				this.validateLineItems(oEvent);
			}
		},

		onCalculateTotal: function (oEvent) {
			var Qty = parseFloat(oEvent.getSource().getParent().getCells()[4].getValue());
			var Price = parseFloat(oEvent.getSource().getParent().getCells()[3].getText());

			var total = Price * Qty;

			if (isNaN(total)) {
				oEvent.getSource().getParent().getCells()[5].setText();
			} else {
				oEvent.getSource().getParent().getCells()[5].setText(total);
			}

		},

		validateLineItems: function (oEvent) {
			var oTable = this.byId("LineItemsTable");
			var oRows = oTable.getItems();

			for (var counter = 0; counter < oRows.length; ++counter) {
				if (oRows[counter].getCells()[0].getValue() === "") {
					MessageBox.error("Select Product type in all the rows");
					return;
				}

				if (oRows[counter].getCells()[4].getValue() === "") {
					MessageBox.error("Please input quantity in all the rows");
					return;
				}
			}

			this.Router.navTo("Processing", {
				//prepare object path to be passed on to target
				TaskType: this.TaskType,
				Path: window.encodeURIComponent(this.sProcessPath.substr(1))
			});

		},
		
	  onDeleteLineItems: function(oEvent) {
			//Delete Row 
			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("ProductLineItemsModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("ProductLineItemsModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this._productModel.refresh();
		}


	});

});