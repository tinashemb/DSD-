sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";

	return Controller.extend("gdsd.FundingApplicationProcess.ApplicationFundProcess.controller.ApplicationDetails", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.FundingApplicationProcess.ApplicationFundProcess.view.ApplicationDetails
		 */
		onInit: function () {
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this.Router.getRoute("ApplicationDetails").attachPatternMatched(this._onObjectMatched, this);
			this._oODataModel = this.getOwnerComponent().getModel("ZDSD_CRM_UI5");
			this._processModel = this.getOwnerComponent().getModel("ApplicationProcessing");
		},

		_onObjectMatched: function (oEvent) {

			this.sPath = "/" + window.decodeURIComponent(oEvent.getParameter("arguments").taskPath);
			this.getView().bindElement({
				path: this.sPath
			});

		},

		onNavBack: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ApplicationProcess", true);
		},

		onSelectFilter: function (oEvent) {
			var oItem = oEvent.getSource();
			var skey = oItem.getSelectedKey();
			if (skey === "workspace") {
				this.onAddWorkSpace('BUS2000125', "");
			}
		},

		onAddWorkSpace: function (SAPObj, ObjId) {
			//ECM Intergration
			SAPObj = 'BUS2000270';
			ObjId = '0050569545C51EDB85F0B3462B7E511D';

			this.byId("WPFilter").destroyContent();
			var html = new sap.ui.core.HTML();
			html.setContent("<div class='FrameWrapper'><iframe id='EcmFrame' src='/sap/bc/ui5_ui5/sap/zrmf_bws_ui/index.html?SAPObj=" + SAPObj +
				"&ObjId=" +
				ObjId + "' width='1200px' height='500px'></iframe></div>");
			this.byId("WPFilter").addContent(html);
		},

		onSubmit: function () {
			
			 var oProperty = this._processModel.getProperty(this.sPath);

			var sPath = "/GEtApplicationProcessingSet(BpNo='" + oProperty.BpNo + "',Guid='" + oProperty.Guid + "',ObjectId='" + oProperty.ObjectId +
				"')";
				
		   var oEntry = oProperty;

            sap.ui.core.BusyIndicator.show(0);
			this._oODataModel.update(sPath, oEntry, {
				success: function (oData) {
					sap.ui.core.BusyIndicator.hide();
					this._oODataModel.resetChanges();
						MessageBox.success("Application successfully submited", {
							icon: sap.m.MessageBox.Icon.CONFIRMATION,
							title: "Confirmation",
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function (oAction) {
                              this.onNavBack();
							}.bind(this)
						});

				}.bind(this),
				error: function (results) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to save application details");
				}.bind(this)
			});
		}

	});

});