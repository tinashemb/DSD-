sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"gdsd/FundingApplicationProcess/ApplicationFundProcess/model/models",
	"sap/ui/model/json/JSONModel"
], function (UIComponent, Device, models, JSONModel) {
	"use strict";

	return UIComponent.extend("gdsd.FundingApplicationProcess.ApplicationFundProcess.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			//Global model to store Batch Details
			this.oModelApplicationProcessing = new JSONModel({
				data: []
			});
			
			this.oModelProductLineItems = new sap.ui.model.json.JSONModel({
				data: []
			});
			
			//Set Binding Mode
			this.oModelApplicationProcessing.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.oModelProductLineItems.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			
			//Set the models
			this.setModel(this.oModelApplicationProcessing, "ApplicationProcessing");
			this.setModel(this.oModelProductLineItems, "ProductLineItems");
		}
	});
});