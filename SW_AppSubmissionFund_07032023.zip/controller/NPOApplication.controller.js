sap.ui.define([
	"./BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/Device"
], function (BaseController, Filter, FilterOperator, MessageBox, Device) {
	"use strict";

	return BaseController.extend("gdsd.FundingApplication.controller.NPOApplication", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.FundingApplication.view.NPOApplication
		 */
		onInit: function () {
			//get the odata model from the component
			this._oODataModel = this.getOwnerComponent().getModel();
			this._oODataModel.setSizeLimit(25);
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			
			this.Router.getRoute("NPOApplication").attachPatternMatched(this._onObjectMatched, this);
			
		},
		
		_onObjectMatched: function (oEvent) {
		   var oTable = this.getView().byId("ApplicationList");	
		   //oTable.getBinding("items").refresh(true);
		   //location.reload();
		},

		//searching the table
		onSearch: function (oEvent) {
			// add filter for search
			var aFilters = [];
			var Bp = this.getView().byId("searchBp").getValue().trim();
			var BpName = this.getView().byId("searchBpName").getValue().trim();
			//var sQuery = oEvent.getSource().getValue();
			if ((BpName !== "" && BpName.length > 0) || (Bp !== "" && Bp.length > 0)) {
				// var filterBp = new Filter("BpNo", sap.ui.model.FilterOperator.EQ, Bp);
				// var filterBpName = new Filter("BpName", sap.ui.model.FilterOperator.EQ, BpName);
				// aFilters.push(filterBp);
			 //   aFilters.push(filterBpName);
			   
			   this.getBPData(Bp, BpName);
			}

			// update list binding
			// var oTable = this.getView().byId("ApplicationList");
			// var oBinding = oTable.getBinding("items");
			// oBinding.filter(aFilters, "Application");
		},

		onItemPress: function (oEvent) {
			this.Router.navTo("NewApplication", {
				BpNo: oEvent.getSource().getBindingContext("BPModel").getProperty("BpNo")
			});
		},
		
		onPressNavButton: function (oEvent) {
			this.Router.navTo("ListOfApplications");
		},
		
		getBPData: function (vBP, vBPName) {
			var filterBp = new Filter("BpNo", sap.ui.model.FilterOperator.EQ, vBP);
			var filterBpName = new Filter("BpName", sap.ui.model.FilterOperator.EQ, vBPName);
			
			sap.ui.core.BusyIndicator.show(0);
			this._oODataModel.read("/GET_BPSet", {
				filters: [filterBp, filterBpName],
				success: function(odata) {

					var BPJsonModel = new sap.ui.model.json.JSONModel({
						data: odata.results
					});
					
					this.getView().setModel(BPJsonModel, "BPModel");
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function() {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve BP details");
				}.bind(this)
			});
		}

	});

});