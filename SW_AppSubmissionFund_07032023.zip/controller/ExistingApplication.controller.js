sap.ui.define([
	"./BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/Device",
	"sap/ui/core/library"
], function(BaseController, Filter, FilterOperator, MessageBox, Device, coreLibrary) {
	"use strict";

	return BaseController.extend("gdsd.FundingApplication.controller.ExistingApplication", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf gdsd.FundingApplication.view.ExistingApplication
		 */
		onInit: function() {
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this.Router.getRoute("ExistingApplication").attachPatternMatched(this._onObjectMatched, this);
			this._mViewSettingsDialogs = {};
			//get the odata model from the component
			this._oODataModel = this.getOwnerComponent().getModel();
			this._ApplicationModel = this.getOwnerComponent().getModel("Applications");

			this.CapacityModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.TargetGroupModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.BeneficiariesModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			
			this.CostImplicationsModel = new sap.ui.model.json.JSONModel({
				data: []

			});
			
			this.OnceOffModel= new sap.ui.model.json.JSONModel({
				data: []
			});

			//Set Binding Mode
			this.CapacityModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.TargetGroupModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.BeneficiariesModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
		//	this.CostImplicationsModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.OnceOffModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
		},

		_onObjectMatched: function(oEvent) {

			this.sPath = "/" + window.decodeURIComponent(oEvent.getParameter("arguments").ApplicationPath);
			var oProperty = this._ApplicationModel.getProperty(this.sPath);

			var ApplicationJsonModel = new sap.ui.model.json.JSONModel({
				data: oProperty
			});
			
		//	this.CostImplicationsJsonModel = new sap.ui.model.json.JSONModel({
		//		data: oProperty
		//	});

			this.Guid = oProperty.Guid;
			this.ObjectId = oProperty.ObjectId;

			//Set Binding Mode
			ApplicationJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
		//	this.CostImplicationsJsonModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);

			this.byId("headerNPO").setTitle("Application: " + oProperty.ObjectId);
			this.byId("detailPage").setTitle(oProperty.But000.McName1);
			if (oProperty.Statu.Status === "I1002") {
				this.byId("Status").setText(oProperty.Statu.Txt30);
				this.byId("Status").setState("Success");
			} else {
				this.byId("Status").setText(oProperty.Statu.Txt30);
				this.byId("Status").setState("Error");
			}

			this.byId("BankName").setValue(oProperty.BankingName.BankName);

			if (oProperty.Banking.BankType === "01") {
				this.byId("BankType").setValue("Current Account");
			} else if (oProperty.Banking.BankType === "02") {
				this.byId("BankType").setValue("Savings Account");
			} else if (oProperty.Banking.BankType === "03") {
				this.byId("BankType").setValue("Loan Account");
			} else if (oProperty.Banking.BankType === "04") {
				this.byId("BankType").setValue("General Ledger");
			}

			//this.byId("btnSubmit").setVisible(false);

			this.byId("headerNPO").setModel(ApplicationJsonModel);
			this.byId("headerNPO").bindElement({
				path: "/data"
			});

			this.byId("formOrg").setModel(ApplicationJsonModel);
			this.byId("formOrg").bindElement({
				path: "/data"
			});

			this.byId("formAdrc").setModel(ApplicationJsonModel);
			this.byId("formAdrc").bindElement({
				path: "/data"
			});

			this.byId("formContacts").setModel(ApplicationJsonModel);
			this.byId("formContacts").bindElement({
				path: "/data"
			});

			this.byId("formBank").setModel(ApplicationJsonModel);
			this.byId("formBank").bindElement({
				path: "/data"
			});

			this.byId("formApplication").setModel(ApplicationJsonModel);
			this.byId("formApplication").bindElement({
				path: "/data"
			});

			this.byId("formViability").setModel(ApplicationJsonModel);
			this.byId("formViability").bindElement({
				path: "/data"
			});

		/*	this.byId("FCItable1").setModel(ApplicationJsonModel);
			this.byId("FCItable1").bindElement({
				path: "/data"
			});*/

			this.byId("formMonitorNPO").setModel(ApplicationJsonModel);
			this.byId("formMonitorNPO").bindElement({
				path: "/data"
			});

			this.byId("formCapacity").setModel(ApplicationJsonModel);
			this.byId("formCapacity").bindElement({
				path: "/data"
			});

			this.byId("formFundingReq").setModel(ApplicationJsonModel);
			this.byId("formFundingReq").bindElement({
				path: "/data"
			});

			this.byId("formAchievements").setModel(ApplicationJsonModel);
			this.byId("formAchievements").bindElement({
				path: "/data"
			});

			this.byId("formChallenges").setModel(ApplicationJsonModel);
			this.byId("formChallenges").bindElement({
				path: "/data"
			});

			this.byId("formSustain").setModel(ApplicationJsonModel);
			this.byId("formSustain").bindElement({
				path: "/data"
			});

			this.byId("formNetworks").setModel(ApplicationJsonModel);
			this.byId("formNetworks").bindElement({
				path: "/data"
			});

			this.byId("formOverviewAppDet").setModel(ApplicationJsonModel);
			this.byId("formOverviewAppDet").bindElement({
				path: "/data"
			});

			this.byId("formOverviewProgramV").setModel(ApplicationJsonModel);
			this.byId("formOverviewProgramV").bindElement({
				path: "/data"
			});

			this.byId("formOverviewAchievements").setModel(ApplicationJsonModel);
			this.byId("formOverviewAchievements").bindElement({
				path: "/data"
			});

			this.byId("formOverviewChallenges").setModel(ApplicationJsonModel);
			this.byId("formOverviewChallenges").bindElement({
				path: "/data"
			});

			this.byId("formOverviewCapacityB").setModel(ApplicationJsonModel);
			this.byId("formOverviewCapacityB").bindElement({
				path: "/data"
			});

			this.byId("formOverviewFunding").setModel(ApplicationJsonModel);
			this.byId("formOverviewFunding").bindElement({
				path: "/data"
			});

			this.byId("formOverviewSummaryC").setModel(this.CostImplicationsModel);
			this.byId("formOverviewSummaryC").bindElement({
				path: "/data"
			});

			this.byId("formOverviewSustain").setModel(ApplicationJsonModel);
			this.byId("formOverviewSustain").bindElement({
				path: "/data"
			});

			this.byId("formOverviewMonitor").setModel(ApplicationJsonModel);
			this.byId("formOverviewMonitor").bindElement({
				path: "/data"
			});

			this.byId("formOverviewNetworks").setModel(ApplicationJsonModel);
			this.byId("formOverviewNetworks").bindElement({
				path: "/data"
			});

			this.getView().setModel(ApplicationJsonModel);

			//ECM Intergration
			var SAPObj, ObjId;
			SAPObj = 'BUS2000270';
			ObjId = this.Guid;
			//destroy content on the attachment Icon Tab Filer 
			this.byId("WPFilter").destroyContent();
			//create an HTML object so that an iFrame can be added
			var html = new sap.ui.core.HTML();
			//adding a standard Fiori ECM application to the iframe and pass necessary url parameters 
			html.setContent("<div class='FrameWrapper'><iframe id='EcmFrame' src='/sap/bc/ui5_ui5/sap/zrmf_bws_ui/index.html?SAPObj=" +
				SAPObj +
				"&ObjId=" + ObjId + "' width='1200px' height='500px'></iframe></div>");
			//adding the html object to the Icon Tab filter
			this.byId("WPFilter").addContent(html);

			if (ApplicationJsonModel.getData().data.But0id.ValidDateTo !== null) {
				MessageBox.error("BP No " + ApplicationJsonModel.getData().data.BpNo + " is not valid", {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: "Warning",
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function(oAction) {
						if (oAction === "OK") {
                            this.getCapacities(this.Guid);
							return;
						}
					}.bind(this)
				});
			} else {
				this.getCapacities(this.Guid);
			}

		},

		onNpoNextPress: function() {
			this.byId("IconBar").setSelectedKey("application");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onApplicationDeteailsPrevPress: function() {
			this.byId("IconBar").setSelectedKey("npo");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onApplicationDetailsNextPress: function() {
			this.byId("IconBar").setSelectedKey("programme");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onProgramViabilityPrevPress: function() {
			this.byId("IconBar").setSelectedKey("application");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onProgramViabilityNextPress: function() {
			this.byId("IconBar").setSelectedKey("achievements");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAchievementNextPress: function() {
			this.byId("IconBar").setSelectedKey("challenges");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAchievementPrevPress: function() {
			this.byId("IconBar").setSelectedKey("programme");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onChallengesNextPress: function() {
			this.byId("IconBar").setSelectedKey("capacity");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onChallengesPrevPress: function() {
			this.byId("IconBar").setSelectedKey("achievements");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCapacityNextPress: function() {
			this.byId("IconBar").setSelectedKey("funding");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCapacityPrevPress: function() {
			this.byId("IconBar").setSelectedKey("challenges");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onFundingNextPress: function() {
			this.byId("IconBar").setSelectedKey("cost");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onFundingPrevPress: function() {
			this.byId("IconBar").setSelectedKey("capacity");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCostNextPress: function() {
			var oProp = {};
		
			//Structure: ZOBJ00000M
            oProp.ZZAFLD00008D = this.byId("fciBeneficiaries1").getValue();
            oProp.ZZAFLD00008F = this.byId("fciSubRate1").getValue();
            oProp.ZZAFLD00008I = this.byId("fciPersonnelType1").getValue();
            oProp.ZZAFLD00008J= this.byId("fciBudgetCost1").getValue();
            oProp.ZZAFLD00008L = this.byId("spBeneficiaries1").getValue();
            oProp.ZZAFLD00008N = this.byId("spSubRate1").getValue();
            oProp.ZZAFLD00008P = this.byId("spPersonnelType1").getValue();
            oProp.ZZAFLD00008Q = this.byId("spBudgetCosts1").getValue();
 
             //Structure: ZOBJ00000N
           oProp.ZZAFLD00008S = this.byId("benefBeneficiaries1").getValue();
           oProp.ZZAFLD00008U = this.byId("benefSubRate1").getValue();
            oProp.ZZAFLD00008W = this.byId("benefPersonnelType1").getValue();
            oProp.ZZAFLD00008X = this.byId("benefBudgetCost1").getValue();
 
             //Structure: ZOBJ00000O
            oProp.ZZAFLD000090 = this.byId("personnelBeneficiaries1").getValue();
            oProp.ZZAFLD000092 = this.byId("personnelSubRate1").getValue();
            oProp.ZZAFLD000095 = this.byId("personnelPType1").getValue();
            oProp.ZZAFLD000096 = this.byId("personnelBudgetCost1").getValue();
 
             //Structure: ZOBJ00000P
            oProp.ZZAFLD000098 = this.byId("admincostBeneficiaries1").getValue();
            oProp.ZZAFLD00009A = this.byId("admincostSubRate1").getValue();
            oProp.ZZAFLD00009C = this.byId("admincostsPersonnelType1").getValue();
        	oProp.ZZAFLD00009D = this.byId("adminBudgetCost1").getValue();

            this.CostImplicationsJsonModel.setData({data:oProp});
            
            this.byId("btnSubmit").setVisible(false);
			this.byId("IconBar").setSelectedKey("sustainability");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onCostPrevPress: function() {
			this.byId("IconBar").setSelectedKey("funding");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSustanabilityNextPress: function() {
			this.byId("IconBar").setSelectedKey("monitoring");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSustanabilityPrevPress: function() {
			this.byId("IconBar").setSelectedKey("cost");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onMonitoringNextPress: function() {
			this.byId("IconBar").setSelectedKey("networks");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onMonitoringPrevPress: function() {
			this.byId("IconBar").setSelectedKey("sustainability");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onNetworksNextPress: function() {
			this.byId("IconBar").setSelectedKey("attachments");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onNetworksPrevPress: function() {
			this.byId("IconBar").setSelectedKey("monitoring");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAttachmentsNextPress: function() {
			this.byId("IconBar").setSelectedKey("beneficiary");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onAttachmentsPrevPress: function() {
			this.byId("IconBar").setSelectedKey("particular");
			this.byId("detailPage").scrollTo(0, 0);
		},

		//Edit buttons for the Overview Tab

		onEditApplicationDetails: function() {
			this.byId("IconBar").setSelectedKey("application");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onEditProgrammeViability: function() {
			this.byId("IconBar").setSelectedKey("programme");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onEditAchievements: function() {
			this.byId("IconBar").setSelectedKey("achievements");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onEditChallenges: function() {
			this.byId("IconBar").setSelectedKey("challenges");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onEditCapacityBuildingNeeds: function() {
			this.byId("IconBar").setSelectedKey("capacity");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onEditFundingRequest: function() {
			this.byId("IconBar").setSelectedKey("funding");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onEditCostImplications: function() {
			this.byId("IconBar").setSelectedKey("cost");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onEditSustainability: function() {
			this.byId("IconBar").setSelectedKey("sustainability");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onEditMonitoring: function() {
			this.byId("IconBar").setSelectedKey("monitoring");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onEditNetworks: function() {
			this.byId("IconBar").setSelectedKey("networks");
			this.byId("detailPage").scrollTo(0, 0);
		},

		onSummary: function() {
			var oTableTarget = this.byId("targetTable21");
			var oTableCapacity = this.byId("BoardCapacity21");
			var oTableBeneficiary = this.byId("beneficiariesTable21");

			this.byId("btnSubmit").setVisible(true);
			this.byId("IconBar").setSelectedKey("overview");
			this.byId("detailPage").scrollTo(0, 0);

			this.byId("AppTargetGroup1").setText(oTableTarget.getModel("TargetModel").getData().data.length);
			this.byId("AppNumberofBeneficiaries1").setText(oTableBeneficiary.getModel("BeneficiariesModel").getData().data.length);
			this.byId("AppCapacityofBoardStaff1").setText(oTableCapacity.getModel("CapacityModel").getData().data.length);
		},

		handleIconTabBarSelect: function(oEvent) {
			var sKey = oEvent.getParameter("key");

			if (sKey === "overview") {
				this.onSummary();
			}

		},

		onUpdate: function() {
			sap.ui.core.BusyIndicator.show(0);
			var oProperties = this.getView().getModel().getData().data;
			oProperties.Status = "E0002";
			this._oODataModel.update("/GETApplicationFundingSet(BpNo='" + oProperties.BpNo + "',Guid='" + oProperties.Guid + "',ObjectId='" +
				oProperties.ObjectId + "')", oProperties, {

					success: function(results) {
						//                  sap.ui.core.BusyIndicator.hide();
						// MessageBox.success("Application successfully submited", {
						// 	icon: sap.m.MessageBox.Icon.CONFIRMATION,
						// 	title: "Confirmation",
						// 	actions: [sap.m.MessageBox.Action.OK],
						// 	onClose: function (oAction) {
						//                        this.Router.navTo("ListOfApplications");
						// 	}.bind(this)
						// });

						sap.ui.core.BusyIndicator.hide();
						this.successAndNavigate();

					}.bind(this),
					error: function(results) {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error("Error occured when submiting Application");
					}

				});
		},

		onSubmitCapacity: function() {

			var aItems = [],
			    aItemsOnceOff = [],
				oItem = {};

			var batchChanges = [],
				batchModel = new sap.ui.model.odata.ODataModel("/DSD/sap/opu/odata/sap/ZDSD_CRM_UI5_APP_SRV/");

				for (var i = 0; i < this.CapacityModel.getData().data.length; i++) {
				oItem = this.CapacityModel.getData().data[i];
				oItem.ParentId = this._ObjectGuid;
				aItems.push(oItem);
			}

			for (var j = 0; j < this.TargetGroupModel.getData().data.length; j++) {
				oItem = this.TargetGroupModel.getData().data[j];
				oItem.ParentId = this._ObjectGuid;
				aItems.push(oItem);
			}

			for (var k = 0; k < this.BeneficiariesModel.getData().data.length; k++) {
				oItem = this.BeneficiariesModel.getData().data[k];
				oItem.ParentId = this._ObjectGuid;
				aItems.push(oItem);
			}

			for (var l = 0; l < this.OnceOffModel.getData().data.length; l++) {
				oItem = this.OnceOffModel.getData().data[l];
				oItem.ParentId = this._ObjectGuid;
				aItemsOnceOff.push(oItem);
			}

			if (aItems.length > 0) {
				for (var t = 0; t < aItems.length; t++) {
					batchChanges.push(batchModel.createBatchOperation("/GetCapacitySet", "POST", aItems[t]));
				}
			}

			if (aItemsOnceOff.length > 0) {
				for (var m = 0; m < aItemsOnceOff.length; m++) {
					batchChanges.push(batchModel.createBatchOperation("/GetOnceOffCostSet", "POST", aItemsOnceOff[m]));
				}
			}

			if (batchChanges.length > 0) {

				batchModel.addBatchChangeOperations(batchChanges);
				batchModel.setUseBatch(true);

				sap.ui.core.BusyIndicator.show();
				//submit Batch and refresh the table
				batchModel.submitBatch(function(data) {
					var parser = new DOMParser(),
						xmlDoc;

					sap.ui.core.BusyIndicator.hide();

					if (data.__batchResponses[0].__changeResponses[0].statusCode.startsWith('2')) {

						this.successAndNavigate();

					} else {

						// xmlDoc = parser.parseFromString(data.__batchResponses[0].response.body, "text/xml");
						// MessageBox.error(xmlDoc.documentElement.children[1].innerHTML);
						// sap.ui.core.BusyIndicator.hide();

						// xmlDoc = parser.parseFromString(data.__batchResponses[0].response.body, "text/xml");
						MessageBox.error("Error occured when submiting Application");

					}

					batchModel.resetChanges();
					batchModel.refresh();
				}.bind(this), function(err) {
					//MessageBox.error("Connection error. Check if you're connected.");
					sap.ui.core.BusyIndicator.hide();
				});
			} else {
				sap.ui.core.BusyIndicator.hide();
				this.successAndNavigate();
			}
		},

		successAndNavigate: function(oEvent) {
			MessageBox.success("Application " + this.ObjectId + " submitted successfully", {
				icon: sap.m.MessageBox.Icon.CONFIRMATION,
				title: "Confirmation",
				actions: [sap.m.MessageBox.Action.OK],
				onClose: function(oAction) {
					if (oAction === "OK") {
						this.byId("Objective").setValue();
						this.byId("Region2").setSelectedKey();
						this.byId("Region2").setSelectedItem();
						this.Router.navTo("ListOfApplications");
						location.reload();
						return;
					}
				}.bind(this)
			});
		},

		onAddBeneficiariesPressed: function() {
			this.createFormDialog("gdsd.FundingApplication.view.fragments.ExistingBeneficiariers").open();
		},
		onAddStaffCapacity: function() {
			this.createFormDialog("gdsd.FundingApplication.Fragments.CapacityofStaff").open();
		},

		onAddBoardCapacity: function() {
			this.createFormDialog("gdsd.FundingApplication.view.fragments.Capacity").open();
		},
		onAddTargetPressed: function() {
			this.createFormDialog("gdsd.FundingApplication.view.fragments.ExistingTargetGroup").open();
		},
		onAddCapacityPressed: function() {
			this.createFormDialog("gdsd.FundingApplication.view.fragments.ExistingCapacity").open();
		},
		onAddFinancialCostImplications: function () {
			this.createFormDialog("gdsd.FundingApplication.view.fragments.FinancialCosts").open();
		},

		createFormDialog: function(sDialogFragmentName) {

			// https://stackoverflow.com/questions/55667673/how-to-remove-duplicates-and-display-only-unique-values-in-viewsettingsitem
			var oDialog = this._mViewSettingsDialogs[sDialogFragmentName];
			if (!oDialog) {
				oDialog = sap.ui.xmlfragment(sDialogFragmentName, this);
				this._mViewSettingsDialogs[sDialogFragmentName] = oDialog;

				if (Device.system.desktop) {
					oDialog.addStyleClass("sapUiSizeCompact");
				}
			}
			return oDialog;
		},

		onCancel: function() {
			//Cater for the age group selected 
			var oDialogKey,
				oDialogValue;

			for (oDialogKey in this._mViewSettingsDialogs) {
				oDialogValue = this._mViewSettingsDialogs[oDialogKey];

				if (oDialogValue) {
					oDialogValue.close();
					// oDialogValue = null;
				}
			}
		},

		onSaveBeneficiaries: function(oEvent) {
			var oTable = this.byId("beneficiariesTable21");

			if (sap.ui.getCore().byId("bgender1").getSelectedItem() === null || sap.ui.getCore().byId("brace1").getSelectedItem() === null) {
				MessageBox.error("Please make sure gender and race are selected");
			} else {
				this.BeneficiariesModel.getData().data.push({
					"BpNo": "",
					"ObjectId": "",
					"Guid": "",
					"Zztype": "",
					"Zzafld000007": sap.ui.getCore().byId("bname1").getValue(),
					"Zzafld000008": sap.ui.getCore().byId("bcontact1").getValue(),
					"Zzafld000009": sap.ui.getCore().byId("bidnumber1").getValue(),
					//	"Position": sap.ui.getCore().byId("cposition").getValue(),
					"Zzafld00000a": sap.ui.getCore().byId("bgender1").getSelectedItem().getKey(),
					"Zzafld00000b": sap.ui.getCore().byId("brace1").getSelectedItem().getText(),
					"Zzafld00000c": sap.ui.getCore().byId("bdisabilitynature1").getValue(),
					"Zzafld00000d": sap.ui.getCore().byId("bposition1").getValue(),
					"Zzafld000087": sap.ui.getCore().byId("bdisability1").getValue()
				});

				oTable.setModel();

				oTable.setModel(this.BeneficiariesModel, "BeneficiariesModel");
				oTable.getModel("BeneficiariesModel").refresh(true);

				this.byId("countExistingBeneficiaries").setText("Beneficiaries (" + this.BeneficiariesModel.getData().data.length + ")");

				sap.ui.getCore().byId("bname1").setValue();
				sap.ui.getCore().byId("bidnumber1").setValue();
				sap.ui.getCore().byId("bgender1").setValue();
				sap.ui.getCore().byId("brace1").setValue();
				sap.ui.getCore().byId("bcontact1").setValue();
				sap.ui.getCore().byId("bposition1").setValue();
				sap.ui.getCore().byId("bdisability1").setValue();
				sap.ui.getCore().byId("bdisabilitynature1").setValue();
			
				this.onCancel();
			}
		},

		onSaveTarget: function(oEvent) {
			var oTable = this.byId("targetTable21");

			if (sap.ui.getCore().byId("tgender1").getSelectedItem() === null || sap.ui.getCore().byId("trace1").getSelectedItem() === null) {
				MessageBox.error("Please make sure gender and race are selected");
			} else {
				this.TargetGroupModel.getData().data.push({
					"BpNo": "",
					"ObjectId": "",
					"Guid": "",
					"Zztype": "",
					"Zzafld000007": sap.ui.getCore().byId("tname1").getValue(),
					"Zzafld000008": sap.ui.getCore().byId("tcontact1").getValue(),
					"Zzafld000009": sap.ui.getCore().byId("tidnumber1").getValue(),
					//	"Position": sap.ui.getCore().byId("cposition").getValue(),
					"Zzafld00000a": sap.ui.getCore().byId("tgender1").getSelectedItem().getKey(),
					"Zzafld00000b": sap.ui.getCore().byId("trace1").getSelectedItem().getKey(),
					"Zzafld00000c": sap.ui.getCore().byId("tdisabilitynature1").getValue(),
					"Zzafld00000d": sap.ui.getCore().byId("tposition1").getValue(),
					"Zzafld000087": sap.ui.getCore().byId("tdisability1").getValue()
				});

				oTable.setModel();

				oTable.setModel(this.TargetGroupModel, "TargetModel");
				oTable.getModel("TargetModel").refresh(true);

				this.byId("countExistingTarget").setText("Target Group (" + this.TargetGroupModel.getData().data.length + ")");

				sap.ui.getCore().byId("tname1").setValue();
				sap.ui.getCore().byId("tidnumber1").setValue();
				sap.ui.getCore().byId("tgender1").setValue();
				sap.ui.getCore().byId("trace1").setValue();
				sap.ui.getCore().byId("tcontact1").setValue();
				sap.ui.getCore().byId("tposition1").setValue();
				sap.ui.getCore().byId("tdisability1").setValue();
				sap.ui.getCore().byId("tdisabilitynature1").setValue();
				this.onCancel();
			}
		},

		onSaveBoardExistingCapacity: function(oEvent) {
			var oTable = this.byId("BoardCapacity21");

			if (sap.ui.getCore().byId("cgender1").getSelectedItem() === null || sap.ui.getCore().byId("crace1").getSelectedItem() === null) {
				MessageBox.error("Please make sure gender and race are selected");
			} else {
				this.CapacityModel.getData().data.push({
					"BpNo": "",
					"ObjectId": "",
					"Guid": "",
					"Zztype": sap.ui.getCore().byId("ctype1").getSelectedItem().getText(),
					"Zzafld000007": sap.ui.getCore().byId("cname1").getValue(),
					"Zzafld000008": sap.ui.getCore().byId("ccontact1").getValue(),
					"Zzafld000009": sap.ui.getCore().byId("cidnumber1").getValue(),
					//	"Position": sap.ui.getCore().byId("cposition").getValue(),
					"Zzafld00000a": sap.ui.getCore().byId("cgender1").getSelectedItem().getKey(),
					"Zzafld00000b": sap.ui.getCore().byId("crace1").getSelectedItem().getKey(),
					"Zzafld00000c": sap.ui.getCore().byId("cdisabilitynature1").getValue(),
					"Zzafld00000d": sap.ui.getCore().byId("cposition1").getValue(),
					"Zzafld000087": sap.ui.getCore().byId("cdisability1").getValue()
				});

				//Refresh model
				//var oTable = this.byId("capacity");
				oTable.setModel();

				oTable.setModel(this.CapacityModel, "CapacityModel");
				oTable.getModel("CapacityModel").refresh(true);

				this.byId("countExistingCapacity").setText("Capacity of Board/Staff (" + this.CapacityModel.getData().data.length + ")");

				sap.ui.getCore().byId("cname1").setValue();
				sap.ui.getCore().byId("cname1").setValue();
				sap.ui.getCore().byId("cidnumber1").setValue();
				sap.ui.getCore().byId("cgender1").setValue();
				sap.ui.getCore().byId("crace1").setValue();
				sap.ui.getCore().byId("ccontact1").setValue();
				sap.ui.getCore().byId("cposition1").setValue();
				sap.ui.getCore().byId("cdisability1").setValue();
				sap.ui.getCore().byId("cdisabilitynature1").setValue();
				this.onCancel();
			}
		},
		
		onSaveAsset: function() {
		  	var oTable = this.byId("OnceOffCostsTable1");

			if (sap.ui.getCore().byId("Product").getValue() === "" || sap.ui.getCore().byId("ExistPrice").getValue() === ""
			  || sap.ui.getCore().byId("PropPrice").getValue() === "") {
				MessageBox.error("Please input all the required values");
			} else {
				this.OnceOffModel.getData().data.push({
					"ObjectId": "",
					"ParentId": "",
					"RecordId": "",
					"Zzafld00009v": sap.ui.getCore().byId("Product").getValue(),
					"Zzafld00009w": sap.ui.getCore().byId("ExistPrice").getValue(),
					"Zzafld00009y": sap.ui.getCore().byId("PropPrice").getValue()
				});

				//Refresh model
				//var oTable = this.byId("capacity");
				oTable.setModel();

				oTable.setModel(this.OnceOffModel, "OnceOffModel");
				oTable.getModel("OnceOffModel").refresh(true);

				sap.ui.getCore().byId("Product").setValue();
				sap.ui.getCore().byId("ExistPrice").setValue();
				sap.ui.getCore().byId("PropPrice").setValue();
				this.onCancel();
			}	
		},

		handleChangeAppType: function(oEvent) {
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				MessageBox.error("Please select application Type");
				this.byId("idAppType2").setValue("");
			}
		},

		handleChangePeriod: function(oEvent) {
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				MessageBox.error("Please select period of operation");
				this.byId("idPeriodOperation").setValue("");
			}
		},

		handleChangeRegion: function(oEvent) {
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				MessageBox.error("Please select region");
				this.byId("Region2").setValue("");
			}
		},
		
		onUpdateFCIBNEFICIARIES: function(oEvent) {
			var oSource = oEvent.getSource();
			var sValue;

			sValue = oSource.getValue();

			if (sValue.length <= 6) {
				this.ValueFCIBenef = sValue;
				sap.ui.getCore().byId("totalNumBeneficiaries").setValue(sValue);
			} else {
				sap.ui.getCore().byId("totalNumBeneficiaries").setValue(this.ValueFCIBenef);
				MessageBox.error("Maximum Digits Exceeded");
			}
		},

		onPressExistingBeneficiary: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogBeneficiary = this.createFormDialog("gdsd.FundingApplication.view.fragments.UpdateBeneficiariers");

			this._DialogBeneficiary.setModel(this.BeneficiariesModel);
			this._DialogBeneficiary.bindElement(oBindingContextPath);

			this._DialogBeneficiary.open();

		},
		
	onPressCostImplication: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogCostImp = this.createFormDialog("gdsd.FundingApplication.view.fragments.UpdateFinancialCosts");

			this._DialogCostImp.setModel(this.CostImplicationsModel);
			this._DialogCostImp.bindElement(oBindingContextPath);

			this._DialogCostImp.open();

		},

		onPressExistingTarget: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogTarget = this.createFormDialog("gdsd.FundingApplication.view.fragments.UpdateTargetGroup");

			this._DialogTarget.setModel(this.TargetGroupModel);
			this._DialogTarget.bindElement(oBindingContextPath);

			this._DialogTarget.open();

		},

		onPressExistingCapacity: function(oEvent) {

			var oItem = oEvent.getSource();
			var oBindingContextPath = oItem.getBindingContextPath();

			this._DialogTarget = this.createFormDialog("gdsd.FundingApplication.view.fragments.UpdateCapacity");

			this._DialogTarget.setModel(this.CapacityModel);
			this._DialogTarget.bindElement(oBindingContextPath);

			this._DialogTarget.open();

		},

		onDeleteExistingTarget: function(oEvent) {

			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("TargetModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("TargetModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this.TargetGroupModel.refresh();

			//			alert("Entry Successfully Deleted");
		},

		onDeleteExistingBeneficiaries: function(oEvent) {

			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("BeneficiariesModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("BeneficiariesModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this.BeneficiariesModel.refresh();

			//			alert("Entry Successfully Deleted");
		},

		onDeleteExistingCapacity: function(oEvent) {

			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("CapacityModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("CapacityModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this.CapacityModel.refresh();

			//			alert("Entry Successfully Deleted");
		},
		
	   onDeleteCostImplicationPressed: function(oEvent) {

			var regExp = /\/([^/]+)\//; // regular expression to extract a string between two forward slashes /Test String/
			var path = oEvent.getSource().getBindingContext("CostImplicationsModel").getPath();
			var index = parseInt(path[path.length - 1], 0);
			var bindingArray = regExp.exec(path);
			oEvent.getSource().getBindingContext("CostImplicationsModel").getModel().getData()[bindingArray[1]].splice(index, 1);
			this.CostImplicationsModel.refresh();
		},

		
		
		getOnceOffCosts: function() {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("RecordId", "EQ", this.Guid);

			this._oODataModel.read("/GetOnceOffCostSet", {
				filters: [oFilter],
				success: function(odata) {
					var oTable = this.byId("tableCostImplications1");
					this.CostImplicationsModel.getData().data = odata.results;

					oTable.setModel();
					oTable.setModel(this.CostImplicationsModel, "CostImplicationsModel");
					oTable.getModel("CostImplicationsModel").refresh(true);
					//sap.ui.core.BusyIndicator.hide();
					this.getCost();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve once off details");
				}.bind(this)
			});
		},
		
		getCost: function() {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("RecordId", "EQ", this.Guid);

			this._oODataModel.read("/GetCostSet", {
				filters: [oFilter],
				success: function(odata) {
					var oTable = this.byId("OnceOffCostsTable1");
					this.OnceOffModel.getData().data = odata.results;

					oTable.setModel();
					oTable.setModel(this.OnceOffModel, "OnceOffModel");
					oTable.getModel("OnceOffModel").refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve once off details");
				}.bind(this)
			});
		},

		getCapacities: function(vGuid) {
			sap.ui.core.BusyIndicator.show(0);
			var oFilter = new sap.ui.model.Filter("RecordId", "EQ", vGuid);

			this._oODataModel.read("/GetCapacitySet", {
				filters: [oFilter],
				success: function(odata) {

					//Distribute capacity data
					this.distrubuteCapacity(odata.results);
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve capacity details");
				}.bind(this)
			});
		},

		distrubuteCapacity: function(arrCapacity) {
			for (var capacity = 0; capacity < arrCapacity.length; capacity++) {

				switch (arrCapacity[capacity].Zztype) {
					case "BENEF":
						this.BeneficiariesModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "TARG":
						this.TargetGroupModel.getData().data.push(arrCapacity[capacity]);
						break;
					case "STAFF":
					case "BOARD":
						this.CapacityModel.getData().data.push(arrCapacity[capacity]);
						break;
				}
			}

			this.RestoreModels();

		},

		RestoreModels: function(oEvent) {

			var oTableTarget = this.byId("targetTable21");
			var oTableCapacity = this.byId("BoardCapacity21");
			var oTableBeneficiary = this.byId("beneficiariesTable21");

			oTableBeneficiary.setModel(this.BeneficiariesModel, "BeneficiariesModel");
			oTableBeneficiary.getModel("BeneficiariesModel").refresh(true);

			oTableCapacity.setModel(this.CapacityModel, "CapacityModel");
			oTableCapacity.getModel("CapacityModel").refresh(true);

			oTableTarget.setModel(this.TargetGroupModel, "TargetModel");
			oTableTarget.getModel("TargetModel").refresh(true);

			//sap.ui.core.BusyIndicator.hide();
			this.getOnceOffCosts();

		},

		
		onAddAssetPressed: function() {

			this.createFormDialog("gdsd.FundingApplication.view.fragments.AddAsset").open();

		},
		
			onFloatCheck: function(oEvent) {

			var sValue = oEvent.getSource().getValue();
			var regexp = /^[0-9]*(\.[0-9]{0,2})?$/;
			var bFlag = regexp.test(sValue);
			if (!bFlag) {
				oEvent.getSource().setValueState("Error");
				oEvent.getSource().setValueStateText("Please enter a decimal value of 2");
			} else {
				oEvent.getSource().setValueState("None");
				oEvent.getSource().setValueStateText("");
			}

		},
		
		onSaveCostImplications: function() {

			var ttlNumBenef = sap.ui.getCore().byId("totalNumBeneficiaries").getValue();
			var SubRate = sap.ui.getCore().byId("monthlySubrate").getValue();
			var TotalCosts = sap.ui.getCore().byId("budgetCosts").getValue();
			var oTable = this.byId("tableCostImplications1");
			TotalCosts = 0;

			if (this.validateCostType() === true) {
				MessageBox.error("This cost type already exist");
			} else {

				if (ttlNumBenef !== "" && SubRate !== "") {
					TotalCosts = (parseFloat(ttlNumBenef) * parseFloat(SubRate));

					sap.ui.getCore().byId("budgetCosts").setValue(TotalCosts);
				}

				if (sap.ui.getCore().byId("typeCostImplications").getSelectedItem() === null || sap.ui.getCore().byId("totalNumBeneficiaries").getValue() ===
					"" || sap.ui.getCore()
					.byId("monthlySubrate").getValue() === "" || sap.ui.getCore().byId("personnelType").getSelectedItem() === null) {
					MessageBox.error("Please input all the required values");
				} else {
					this.CostImplicationsModel.getData().data.push({
						"ObjectId": "",
						"ParentId": "",
						"RecordId": "",
						"Zzafld0000a1": sap.ui.getCore().byId("totalNumBeneficiaries").getValue(),
						"Zzafld0000ae": sap.ui.getCore().byId("typeCostImplications").getSelectedItem().getKey(),
						"Zzafld0000a3": sap.ui.getCore().byId("monthlySubrate").getValue(),
						"Zzafld0000a5": sap.ui.getCore().byId("personnelType").getSelectedItem().getKey(),
						"Zzafld0000a6": sap.ui.getCore().byId("budgetCosts").getValue()
					});

					//Refresh model
					//var oTable = this.byId("capacity");
					oTable.setModel();

					oTable.setModel(this.CostImplicationsModel, "CostImplicationsModel");
					oTable.getModel("CostImplicationsModel").refresh(true);

					sap.ui.getCore().byId("totalNumBeneficiaries").setValue();
					sap.ui.getCore().byId("typeCostImplications").setValue();
					sap.ui.getCore().byId("monthlySubrate").setValue();
					sap.ui.getCore().byId("personnelType").setValue();
					sap.ui.getCore().byId("budgetCosts").setValue();
					this.onCancel();
				}

			}
		},

		validateCostType: function() {

			for (var i = 0; i < this.CostImplicationsModel.getData().data.length; i++) {
				if (this.CostImplicationsModel.getData().data[i].Zzafld0000ae === sap.ui.getCore().byId("typeCostImplications").getSelectedItem().getKey()) {
					return true;
				}
			}
			return false;
		},
		
		handleChangeCostImpType: function(oEvent) {
			var ValueState = coreLibrary.ValueState;
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
		//		MessageBox.error("Please select a Cost Implication Type");
				this.byId("typeCostImplications1").setValue("");
			}else {
				oValidatedComboBox.setValueState(ValueState.None);
			}
		},
		handleChangePersonnelType: function(oEvent) {
			var ValueState = coreLibrary.ValueState;
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey(),
				sValue = oValidatedComboBox.getValue();

			if (!sSelectedKey && sValue) {
				oValidatedComboBox.setValueState(ValueState.Error);
		//		MessageBox.error("Please select Personnel Type");
				this.byId("personnelType1").setValue("");
			} else {
				oValidatedComboBox.setValueState(ValueState.None);
			}
		}

	});

});