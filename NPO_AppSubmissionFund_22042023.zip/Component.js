sap.ui.define(["sap/ui/core/UIComponent", "sap/ui/Device", "gdsd/FundingApplication/model/models", "sap/ui/model/json/JSONModel"], function(
	i, e, o, t) {
	"use strict";
	return i.extend("gdsd.FundingApplication.Component", {
		metadata: {
			manifest: "json"
		},
		init: function() {
			i.prototype.init.apply(this, arguments);
			this.getRouter().initialize();
			this.setModel(o.createDeviceModel(), "device");
			this.oModelApplicationProcessing = new t({
				data: []
			});
			this.oModelApplicationProcessing.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.setModel(this.oModelApplicationProcessing, "Applications");
		}
	});
});