sap.ui.define(["sap/ui/core/mvc/Controller"], function(n) {
	"use strict";
	return n.extend("gdsd.NewClaimsApp.controller.ExistingSocialWorkPost", {
		onInit: function() {}
	});
});