sap.ui.define(["./BaseController", "sap/ui/Device", "sap/m/MessageBox"], function(e, t, s) {
	"use strict";
	return e.extend("gdsd.NewClaimsApp.controller.SocialWorkPosts", {
		onInit: function() {
			this._mViewSettingsDialogs = {};
			this._oODataModel = this.getOwnerComponent().getModel();
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this._claimsModel = this.getOwnerComponent().getModel("Claims");
			this.Router.getRoute("SocialWorkPosts").attachPatternMatched(this._onObjectMatched, this);

			this.SWPModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.SummaryStaffyModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.BeneficiaryModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.ChildrenHomeModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.PlacesModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.AttendanceModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.HBCModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.AwarenessModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.AgeingModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.ClaimsModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.SpecialServiceModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.HomesForPersonsModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.ProctiveWorkshopModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.HBCAnnexBModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.AnnexureAModel = new sap.ui.model.json.JSONModel({
				data: []
			});
			this.OtherInfoModel = new sap.ui.model.json.JSONModel({
				data: []
			});

			this.SWPModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.SummaryStaffyModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.HomesForPersonsModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.SpecialServiceModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.ClaimsModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.AgeingModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.AwarenessModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.HBCModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.AttendanceModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.PlacesModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.ChildrenHomeModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.BeneficiaryModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.ProctiveWorkshopModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.HBCAnnexBModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.AnnexureAModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.OtherInfoModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
		},
		_onObjectMatched: function(e) {
			var t = e.getParameter("arguments").FormNo;
			this.sPath = "/" + window.decodeURIComponent(e.getParameter("arguments").claimPath);
			this.formatUI(t);
			var s = this._claimsModel.getProperty(this.sPath);
			this.Guid = s.Guid;
			var i = new sap.ui.model.json.JSONModel({
				data: s
			});
			i.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.byId("header").setModel(i);
			this.byId("header").bindElement({
				path: "/data"
			});
			this.byId("particular").setModel(i);
			this.byId("particular").bindElement({
				path: "/data"
			});
			this.byId("participantShelterChildren").setModel(i);
			this.byId("participantShelterChildren").bindElement({
				path: "/data"
			});
			this.byId("particularShelterWoman").setModel(i);
			this.byId("particularShelterWoman").bindElement({
				path: "/data"
			});
			this.byId("particularServiceCentre").setModel(i);
			this.byId("particularServiceCentre").bindElement({
				path: "/data"
			});
			this.byId("particularsChildrenHome").setModel(i);
			this.byId("particularsChildrenHome").bindElement({
				path: "/data"
			});
			this.byId("particularsPlaces").setModel(i);
			this.byId("particularsPlaces").bindElement({
				path: "/data"
			});
			this.byId("particularsPatient").setModel(i);
			this.byId("particularsPatient").bindElement({
				path: "/data"
			});
			this.byId("particularsHomePeopleDis").setModel(i);
			this.byId("particularsHomePeopleDis").bindElement({
				path: "/data"
			});
			this.byId("particularsHBCAged").setModel(i);
			this.byId("particularsHBCAged").bindElement({
				path: "/data"
			});
			this.byId("particularsresidentialFacility").setModel(i);
			this.byId("particularsresidentialFacility").bindElement({
				path: "/data"
			});
			this.byId("particularsProtectWorkshop").setModel(i);
			this.byId("particularsProtectWorkshop").bindElement({
				path: "/data"
			});
			this.SWPModel.getData().data = [];
			this.SummaryStaffyModel.getData().data = [];
			this.HomesForPersonsModel.getData().data = [];
			this.SpecialServiceModel.getData().data = [];
			this.ClaimsModel.getData().data = [];
			this.AgeingModel.getData().data = [];
			this.AwarenessModel.getData().data = [];
			this.HBCModel.getData().data = [];
			this.AttendanceModel.getData().data = [];
			this.PlacesModel.getData().data = [];
			this.ChildrenHomeModel.getData().data = [];
			this.BeneficiaryModel.getData().data = [];
			this.ProctiveWorkshopModel.getData().data = [];
			this.HBCAnnexBModel.getData().data = [];
			this.AnnexureAModel.getData().data = [];
			this.RestoreModels();
			this.getCapacities(s.Guid);
			this.OtherInfoModel.getData().data = [];

			this.byId("otherRelevantInfo").setModel(i);
			this.byId("otherRelevantInfo").bindElement({
				path: "/data"
			});
		},
		createFormDialog: function(e) {
			var s = this._mViewSettingsDialogs[e];
			if (!s) {
				s = sap.ui.xmlfragment(e, this);
				this._mViewSettingsDialogs[e] = s;
				if (t.system.desktop) {
					s.addStyleClass("sapUiSizeCompact");
				}
			}
			return s;
		},
		onAddSocialWorkPost: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.SocialWorkPosts").open();
		},
		onAddSummaryOfStaff: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.SummaryOfStaff").open();
		},
		onAddBeneficiary: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.Beneficiary").open();
		},
		onAddAAgeing: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.ActiveAgeing").open();
		},
		onAddHBC: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.HBCSummary").open();
		},
		onAddAnnex: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.HBCAnnexB").open();
		},
		onChildrenHome: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.ChildrenHome").open();
		},
		onAddPlaces: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.PlacesOfStay").open();
		},
		onAddAttendance: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.AttendenceRegister").open();
		},
		onAddAwareness: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.Awareness").open();
		},
		onAddAgeing: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.ActiveAgeing").open();
		},
		onAddClaims: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.ClaimForm").open();
		},
		onAddSpecialServices: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.SpecialServices").open();
		},
		onAddHomesForPersons: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.HomesForPersons").open();
		},
		onAddProtectiveWorkshops: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.ProtectiveWorkshops").open();
		},
		onAddHBCAnnexB: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.HBCAnnexB").open();
		},
		onAddAnnexureA: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.AnnexureA").open();
		},
		onAddResFacility: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.ResidentialFacility").open();
		},
		onAddSCBeneficiary: function() {
			this.createFormDialog("gdsd.NewClaimsApp.view.fragments.ServiceCenters").open();
		},
		onCancel: function() {
			var e, t;
			for (e in this._mViewSettingsDialogs) {
				t = this._mViewSettingsDialogs[e];
				if (t) {
					t.close();
				}
			}
		},
		formatUI: function(e) {
			this.claimType = e;
			switch (e) {
				case "1":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("beneficiaries").setVisible(false);
					this.byId("awareness").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(false);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(false);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("ageing").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(true);
					this.byId("childrenHome").setVisible(true);
					this.byId("places").setVisible(true);
					this.byId("summary").setVisible(true);
					this.byId("header").setTitle("CYCC - Child & Youth Care Centres");
					break;
				case "2":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("participantShelterChildren").setVisible(true);
					this.byId("annexureA").setVisible(true);
					this.byId("beneficiaries").setVisible(true);
					this.byId("summary").setVisible(true);
					this.byId("attendence").setVisible(false);
					this.byId("awareness").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(false);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(false);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("ageing").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("header").setTitle("Shelter For Children");
					break;
				case "3":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("particularShelterWoman").setVisible(true);
					this.byId("attendence").setVisible(false);
					this.byId("beneficiaries").setVisible(true);
					this.byId("summary").setVisible(true);
					this.byId("annexureA").setVisible(true);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("awareness").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(false);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("ageing").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("header").setTitle("Shelter For Women and Adults");
					break;
				case "4":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("summary").setVisible(true);
					this.byId("beneficiaries").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(false);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("ageing").setVisible(true);
					this.byId("hbcsummary").setVisible(true);
					this.byId("particularsHBCAged").setVisible(true);
					this.byId("annexureA").setVisible(true);
					this.byId("hbcannex").setVisible(true);
					this.byId("annexureA").setVisible(true);
					this.byId("awareness").setVisible(true);
					this.byId("header").setTitle("Home Based Care for Older Person");
					break;
				case "5":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("summary").setVisible(true);
					this.byId("ageing").setVisible(false);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("beneficiaries").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(false);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(true);
					this.byId("personNeeds").setVisible(true);
					this.byId("specialServices").setVisible(true);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(false);
					this.byId("awareness").setVisible(false);
					this.byId("header").setTitle("Residential Facilities for People with Disabilities");
					break;
				case "7":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("particularsPatient").setVisible(true);
					this.byId("claim").setVisible(true);
					this.byId("summary").setVisible(true);
					this.byId("awareness").setVisible(false);
					this.byId("ageing").setVisible(false);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("beneficiaries").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(false);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("header").setTitle("In-Patient Centre");
					break;
				case "8":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("particularsPatient").setVisible(true);
					this.byId("claim").setVisible(true);
					this.byId("summary").setVisible(true);
					this.byId("ageing").setVisible(false);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("beneficiaries").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(false);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("header").setTitle("Out-Patient Centre");
					break;
				case "9":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("annexureA").setVisible(true);
					this.byId("summary").setVisible(true);
					this.byId("beneficiaries").setVisible(true);
					this.byId("awareness").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(false);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(false);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("ageing").setVisible(false);
					this.byId("particularsPlaces").setVisible(true);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("header").setTitle("Places Of Care (Creches)");
					break;
				case "10":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("summary").setVisible(true);
					this.byId("ageing").setVisible(false);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("beneficiaries").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(false);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(true);
					this.byId("particularsProtectWorkshop").setVisible(true);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("awareness").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("header").setTitle("Protective Workshops");
					break;
				case "11":
					this.byId("serviceCentrebeneficiaries").setVisible(true);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("annexureA").setVisible(true);
					this.byId("summary").setVisible(true);
					this.byId("hbcsummary").setVisible(true);
					this.byId("hbcannex").setVisible(true);
					this.byId("beneficiaries").setVisible(false);
					this.byId("particularServiceCentre").setVisible(true);
					this.byId("awareness").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(false);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(false);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("ageing").setVisible(true);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("header").setTitle("Service Centers and Luncheon Clubs");
					break;
				case "12":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("summary").setVisible(true);
					this.byId("beneficiaries").setVisible(false);
					this.byId("awareness").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(true);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(true);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("ageing").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("header").setTitle("Social Work Posts - Disability");
					break;
				case "13":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("summary").setVisible(false);
					this.byId("beneficiaries").setVisible(false);
					this.byId("awareness").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(true);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(true);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("ageing").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("header").setTitle("Social Work Posts - Children");
					break;
				case "14":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("summary").setVisible(false);
					this.byId("beneficiaries").setVisible(false);
					this.byId("awareness").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(true);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(true);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("ageing").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("header").setTitle("Social Work Posts - Older Person");
					break;
				case "15":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("summary").setVisible(false);
					this.byId("beneficiaries").setVisible(true);
					this.byId("awareness").setVisible(false);
					this.byId("service").setVisible(true);
					this.byId("swposts").setVisible(false);
					this.byId("other").setVisible(true);
					this.byId("particular").setVisible(true);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("ageing").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("header").setTitle("Social Work Posts - Crime Prevention");
					break;
				case "16":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("summary").setVisible(false);
					this.byId("beneficiaries").setVisible(true);
					this.byId("awareness").setVisible(false);
					this.byId("service").setVisible(true);
					this.byId("swposts").setVisible(true);
					this.byId("other").setVisible(true);
					this.byId("particular").setVisible(true);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("ageing").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("header").setTitle("Social Work Posts - Families");
					break;
				case "17":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("summary").setVisible(false);
					this.byId("beneficiaries").setVisible(false);
					this.byId("awareness").setVisible(false);
					this.byId("service").setVisible(true);
					this.byId("swposts").setVisible(true);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(true);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("ageing").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("header").setTitle("Social Work Posts - Substance Abuse");
					break;
				case "18":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(false);
					this.byId("residentialFacility").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("summary").setVisible(false);
					this.byId("beneficiaries").setVisible(false);
					this.byId("awareness").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(true);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(true);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("hbcsummary").setVisible(false);
					this.byId("hbcannex").setVisible(false);
					this.byId("ageing").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("header").setTitle("Social Work Posts - VEP");
					break;
				case "19":
					this.byId("serviceCentrebeneficiaries").setVisible(false);
					this.byId("particularsresidentialFacility").setVisible(true);
					this.byId("residentialFacility").setVisible(true);
					this.byId("particularShelterWoman").setVisible(false);
					this.byId("attendence").setVisible(false);
					this.byId("summary").setVisible(true);
					this.byId("beneficiaries").setVisible(false);
					this.byId("particularServiceCentre").setVisible(false);
					this.byId("service").setVisible(false);
					this.byId("swposts").setVisible(false);
					this.byId("other").setVisible(false);
					this.byId("particular").setVisible(false);
					this.byId("participantShelterChildren").setVisible(false);
					this.byId("particularsPatient").setVisible(false);
					this.byId("claim").setVisible(false);
					this.byId("particularsHomePeopleDis").setVisible(false);
					this.byId("personNeeds").setVisible(false);
					this.byId("specialServices").setVisible(false);
					this.byId("protectiveWorkshop").setVisible(false);
					this.byId("particularsProtectWorkshop").setVisible(false);
					this.byId("particularsChildrenHome").setVisible(false);
					this.byId("childrenHome").setVisible(false);
					this.byId("places").setVisible(false);
					this.byId("particularsPlaces").setVisible(false);
					this.byId("ageing").setVisible(true);
					this.byId("hbcsummary").setVisible(true);
					this.byId("particularsHBCAged").setVisible(false);
					this.byId("annexureA").setVisible(true);
					this.byId("hbcannex").setVisible(true);
					this.byId("annexureA").setVisible(true);
					this.byId("awareness").setVisible(true);
					this.byId("header").setTitle("Residential Facilities");

			}
		},
		onSaveSWP: function() {
			var e = this.byId("tblSWPdisability");
			if (sap.ui.getCore().byId("sname").getValue() === "" || sap.ui.getCore().byId("sage").getValue() === "" || sap.ui.getCore().byId(
					"srace").getSelectedItem() === null || sap.ui.getCore().byId("spostlevel").getSelectedItem() === null || sap.ui.getCore().byId(
					"spoststatus").getSelectedItem() === null || sap.ui.getCore().byId("scaseload").getSelectedItem() === null) {
				s.error("Please make you enter all the required input, e.g Name, Age, gender, race etc");
			} else {
				this.SWPModel.getData().data.push({
					RecordId: "",
					Zztype: "SWP",
					Zzafld000007: sap.ui.getCore().byId("sname").getValue(),
					Zzafld000009: sap.ui.getCore().byId("swpdID").getValue(),
					Zzafld00000g: sap.ui.getCore().byId("sage").getValue(),
					Zzafld00000a: sap.ui.getCore().byId("sgender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("srace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("swpdisability").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("sdisabilitynature").getValue(),
					Zzafld00002k: sap.ui.getCore().byId("spostlevel").getSelectedItem().getKey(),
					Zzafld00002l: sap.ui.getCore().byId("ssalary").getValue(),
					Zzafld00000r: sap.ui.getCore().byId("swpsubidized").getSelectedItem().getKey(),
					Zzafld00002m: sap.ui.getCore().byId("spoststatus").getSelectedItem().getKey(),
					Zzafld00002n: sap.ui.getCore().byId("scaseload").getSelectedItem().getKey(),
					Zzafld00002o: sap.ui.getCore().byId("sservice").getValue()
				});
				e.setModel();
				e.setModel(this.SWPModel, "SocialWorkPostModel");
				e.getModel("SocialWorkPostModel").refresh(true);
				sap.ui.getCore().byId("sname").setValue();
				sap.ui.getCore().byId("swpdID").setValue();
				sap.ui.getCore().byId("sage").setValue();
				sap.ui.getCore().byId("sgender").setValue();
				sap.ui.getCore().byId("srace").setValue();
				sap.ui.getCore().byId("swpdisability").setValue();
				sap.ui.getCore().byId("sdisabilitynature").setValue();
				sap.ui.getCore().byId("spostlevel").setValue();
				sap.ui.getCore().byId("ssalary").setValue();
				sap.ui.getCore().byId("swpsubidized").setValue();
				sap.ui.getCore().byId("spoststatus").setValue();
				sap.ui.getCore().byId("scaseload").setValue();
				sap.ui.getCore().byId("sservice").setValue();
				this.onCancel();
			}
		},
		onSaveStaffSummary: function() {
			var e = this.byId("tblSWPstaffsummary");
			if (sap.ui.getCore().byId("suname").getValue() === "" || sap.ui.getCore().byId("suidnum").getValue() === "" || sap.ui.getCore().byId(
					"sugender").getSelectedItem() === null || sap.ui.getCore().byId("surace").getSelectedItem() === null || sap.ui.getCore().byId("sudisabled").getSelectedItem() === null 
					|| sap.ui.getCore().byId("sudisabilitynature").getValue() === "" || sap.ui.getCore().byId("sudesignation").getValue() === "" 
					|| sap.ui.getCore().byId("susalary").getValue() === "" || sap.ui.getCore().byId("sutraining").getSelectedItem() === null || sap.ui.getCore().byId("sutrainingspe").getValue() === ""
					|| sap.ui.getCore().byId("susubidized").getSelectedItem() === null) {
				s.error("Please make sure you enter all fields");
			} else {
				this.SummaryStaffyModel.getData().data.push({
					RecordId: "",
					Zztype: "SUMMA",
					Zzafld000007: sap.ui.getCore().byId("suname").getValue(),
					Zzafld000009: sap.ui.getCore().byId("suidnum").getValue(),
					Zzafld00000a: sap.ui.getCore().byId("sugender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("surace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("sudisabled").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("sudisabilitynature").getValue(),
					Zzafld000087: sap.ui.getCore().byId("sudesignation").getValue(),
					Zzafld00002l: sap.ui.getCore().byId("susalary").getValue(),
					Zzafld000017: sap.ui.getCore().byId("sutraining").getSelectedItem().getKey(),
					Zzafld000018: sap.ui.getCore().byId("sutrainingspe").getValue(),
					Zzafld00000r: sap.ui.getCore().byId("susubidized").getSelectedItem().getKey()
				});
				e.setModel();
				e.setModel(this.SummaryStaffyModel, "StaffSummaryPostModel");
				e.getModel("StaffSummaryPostModel").refresh(true);
				sap.ui.getCore().byId("suname").setValue();
				sap.ui.getCore().byId("suidnum").setValue();
				sap.ui.getCore().byId("sugender").setValue();
				sap.ui.getCore().byId("surace").setValue();
				sap.ui.getCore().byId("sudisabled").setValue();
				sap.ui.getCore().byId("sudisabilitynature").setValue();
				sap.ui.getCore().byId("sudesignation").setValue();
				sap.ui.getCore().byId("susalary").setValue();
				sap.ui.getCore().byId("sutraining").setValue();
				sap.ui.getCore().byId("sutrainingspe").setValue();
				sap.ui.getCore().byId("susubidized").setValue();
				this.onCancel();
			}
		},
		onSaveBeneficiaty: function() {
			var e = this.byId("beneficiaries");
			if (sap.ui.getCore().byId("bname").getValue() === "" || sap.ui.getCore().byId("bage").getValue() === "" || sap.ui.getCore().byId(
					"bidnum").getValue() === "" || sap.ui.getCore().byId("bgender").getSelectedItem() === null || sap.ui.getCore().byId("brace").getSelectedItem() ===
				null) {
				s.error("Please make you enter all the required input, e.g Name, Age, gender, race etc");
			} else {
				this.BeneficiaryModel.getData().data.push({
					RecordId: "",
					Zztype: "BENEF",
					Zzafld000007: sap.ui.getCore().byId("bname").getValue(),
					Zzafld000009: sap.ui.getCore().byId("bidnum").getValue(),
					Zzafld00000a: sap.ui.getCore().byId("bgender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("brace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("bdisable").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("bdisabilitynature").getValue(),
					Zzafld00000g: sap.ui.getCore().byId("bage").getValue(),
					Zzafld00000h: sap.ui.getCore().byId("bcounselrec").getSelectedItem().getKey(),
					Zzafld00002o: sap.ui.getCore().byId("bservice").getValue()
				});
				e.setModel();
				e.setModel(this.BeneficiaryModel, "BeneficiaryPostModel");
				e.getModel("BeneficiaryPostModel").refresh(true);
				sap.ui.getCore().byId("bname").setValue();
				sap.ui.getCore().byId("bidnum").setValue();
				sap.ui.getCore().byId("bage").setValue();
				sap.ui.getCore().byId("bgender").setValue();
				sap.ui.getCore().byId("brace").setValue();
				sap.ui.getCore().byId("bdisable").setValue();
				sap.ui.getCore().byId("bdisabilitynature").setValue();
				sap.ui.getCore().byId("bcounselrec").setValue();
				sap.ui.getCore().byId("bservice").setValue();
				this.onCancel();
			}
		},
		onSaveChildrenHome: function() {
			var e = this.byId("tblCHbeneficiaries");
			if (sap.ui.getCore().byId("chbGender").getSelectedItem() === null || sap.ui.getCore().byId("chbDoA").getValue() === "" || sap.ui.getCore().byId("chbRace").getSelectedItem() === null ||
				sap.ui.getCore().byId("chbAdmission").getSelectedItem() === null || sap.ui.getCore().byId("chbExitDate").getValue() === "" || sap.ui.getCore().byId("chbName").getValue() === "" || sap.ui.getCore()
				.byId("chbID").getValue() === "" || sap.ui.getCore().byId("chbReason").getSelectedItem() === null) {
				s.error("Please sure make you enter all the required inputs fields");
			} else {
				this.ChildrenHomeModel.getData().data.push({
					RecordId: "",
					Zztype: "CHILD",
					Zzafld000007: sap.ui.getCore().byId("chbName").getValue(),
					Zzafld000009: sap.ui.getCore().byId("chbID").getValue(),
					Zzafld00000o: this.convertToSAPDate(sap.ui.getCore().byId("chbDoA").getValue()),
					Zzafld00000a: sap.ui.getCore().byId("chbGender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("chbRace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("chbDisability").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("chbdisabilitynature").getValue(),
					Zzafld00000u: sap.ui.getCore().byId("chbChooseStatus").getSelectedItem().getKey(),
					//Zzafld00000v: sap.ui.getCore().byId("chbPlaceofSafety").getSelected(),
					//Zzafld00000w: sap.ui.getCore().byId("chbSpecializedServices").getSelected(),
					Zzafld00000x: sap.ui.getCore().byId("chbService").getValue(),
					Zzafld00000g: sap.ui.getCore().byId("chbAge").getValue(),
					Zzafld00000y: sap.ui.getCore().byId("chbAdmission").getSelectedItem().getKey(),
					Zzafld00000l: this.convertToSAPDate(sap.ui.getCore().byId("chbExitDate").getValue()),
					Zzafld00000m: sap.ui.getCore().byId("chbReason").getSelectedItem().getKey(),
					Zzafld00000i: sap.ui.getCore().byId("chbOther").getValue()
				});
				e.setModel();
				e.setModel(this.ChildrenHomeModel, "ChildrenHomeModel");
				e.getModel("ChildrenHomeModel").refresh(true);
				sap.ui.getCore().byId("chbName").setValue();
				sap.ui.getCore().byId("chbID").setValue();
				sap.ui.getCore().byId("chbDoA").setValue();
				sap.ui.getCore().byId("chbGender").setValue();
				sap.ui.getCore().byId("chbDisability").setValue();
				sap.ui.getCore().byId("chbdisabilitynature").setValue();
				sap.ui.getCore().byId("chbChooseStatus").setValue();
				//sap.ui.getCore().byId("chbPlaceofSafety").setSelected(false);
				//sap.ui.getCore().byId("chbSpecializedServices").setSelected(false);
				sap.ui.getCore().byId("chbAge").setValue();
				sap.ui.getCore().byId("chbService").setValue();
				sap.ui.getCore().byId("chbAdmission").setValue();
				sap.ui.getCore().byId("chbExitDate").setValue();
				sap.ui.getCore().byId("chbReason").setValue();
				sap.ui.getCore().byId("chbOther").setValue();
				sap.ui.getCore().byId("chbGender").setSelectedItem(null);
				sap.ui.getCore().byId("chbRace").setSelectedItem(null);
				sap.ui.getCore().byId("chbAdmission").setSelectedItem(null);
				sap.ui.getCore().byId("chbReason").setSelectedItem(null);
				this.onCancel();
			}
		},
		onSavePlaces: function() {
			var e = this.byId("tblCHPlaceofSafety");
			if (sap.ui.getCore().byId("pGender").getSelectedItem() === null || sap.ui.getCore().byId("pRace").getSelectedItem() === null || sap
				.ui.getCore().byId("padmission").getSelectedItem() === null || sap.ui.getCore().byId("pname").getValue() === "" || sap.ui.getCore()
				.byId("pidnum").getValue() === "" || sap.ui.getCore().byId("pDoA").getValue() === "" || sap.ui.getCore().byId("pAge").getValue() ===
				"" || sap.ui.getCore().byId("padmission").getSelectedItem() === null || sap.ui.getCore().byId("pExitDate").getValue() === "") {
				s.error("Please sure make you enter all the required inputs, e.g Name, Age, gender, race, dates etc");
			} else {
				this.PlacesModel.getData().data.push({
					RecordId: "",
					Zztype: "PLACE",
					Zzafld000007: sap.ui.getCore().byId("pname").getValue(),
					Zzafld000009: sap.ui.getCore().byId("pidnum").getValue(),
					Zzafld00000o: this.convertToSAPDate(sap.ui.getCore().byId("pDoA").getValue()),
					Zzafld00000a: sap.ui.getCore().byId("pGender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("pRace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("pDisabled").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("pdisabilitynature").getValue(),
					Zzafld00000g: sap.ui.getCore().byId("pAge").getValue(),
					Zzafld00000y: sap.ui.getCore().byId("padmission").getSelectedItem().getKey(),
					Zzafld00000l: this.convertToSAPDate(sap.ui.getCore().byId("pExitDate").getValue()),
					Zzafld00000m: sap.ui.getCore().byId("reason").getSelectedItem().getKey(),
					Zzafld00000i: sap.ui.getCore().byId("other").getValue()
				});
				e.setModel();
				e.setModel(this.PlacesModel, "PlacesModel");
				e.getModel("PlacesModel").refresh(true);
				sap.ui.getCore().byId("pname").setValue();
				sap.ui.getCore().byId("pidnum").setValue();
				sap.ui.getCore().byId("pDoA").setValue();
				sap.ui.getCore().byId("pGender").setValue();
				sap.ui.getCore().byId("pRace").setValue();
				sap.ui.getCore().byId("pDisabled").setValue();
				sap.ui.getCore().byId("pdisabilitynature").setValue();
				sap.ui.getCore().byId("pAge").setValue();
				sap.ui.getCore().byId("padmission").setValue();
				sap.ui.getCore().byId("pExitDate").setValue();
				sap.ui.getCore().byId("reason").setValue();
				sap.ui.getCore().byId("other").setValue();
				this.onCancel();
			}
		},

		onSaveResidentialFacility: function() {
			var e = this.byId("tblResFacility");
			if (sap.ui.getCore().byId("rfGender").getSelectedItem() === null || sap.ui.getCore().byId("rfRace").getSelectedItem() === null ||
				sap.ui.getCore().byId("rfname").getValue() === "" || sap.ui.getCore().byId("rfidnum").getValue() === "" || sap.ui.getCore().byId(
					"rfAge").getValue() === "") {
				s.error("Please sure make you enter all the required inputs, e.g Name, Age, Gender, Race, etc");
			} else {
				this.HBCModel.getData().data.push({
					RecordId: "",
					Zztype: "",
					Zzafld000007: sap.ui.getCore().byId("rfname").getValue(),
					Zzafld000009: sap.ui.getCore().byId("rfidnum").getValue(),
					Zzafld00000a: sap.ui.getCore().byId("rfGender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("rfRace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("rfDisabled").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("rfdisabilityspecify").getValue(),
					Zzafld00000o: this.convertToSAPDate(sap.ui.getCore().byId("rfDate").getValue()),
					Zzafld0000lp: sap.ui.getCore().byId("rfSafeBeds").getValue(),
					Zzafld00000g: sap.ui.getCore().byId("rfAge").getValue(),
					Zzafld00002l: sap.ui.getCore().byId("rfIncome").getSelectedItem().getKey(),
					Zzafld00000h: sap.ui.getCore().byId("rfCounseling").getSelectedItem().getKey(),
					Zzafld00000l: this.convertToSAPDate(sap.ui.getCore().byId("rfDischargeDate").getValue()),
					Zzafld00000m: sap.ui.getCore().byId("rfExitReason").getValue()

				});
				e.setModel();
				e.setModel(this.HBCModel, "HBCModel");
				e.getModel("HBCModel").refresh(true);
				sap.ui.getCore().byId("rfname").setValue();
				sap.ui.getCore().byId("rfidnum").setValue();
				sap.ui.getCore().byId("rfGender").setValue();
				sap.ui.getCore().byId("rfRace").setValue();
				sap.ui.getCore().byId("rfDisabled").setValue();
				sap.ui.getCore().byId("rfdisabilityspecify").setValue();
				sap.ui.getCore().byId("rfDate").setValue();
				sap.ui.getCore().byId("rfSafeBeds").setValue();
				sap.ui.getCore().byId("rfAge").setValue();
				sap.ui.getCore().byId("rfIncome").setValue();
				sap.ui.getCore().byId("rfCounseling").setValue();
				sap.ui.getCore().byId("rfDischargeDate").setValue();
				sap.ui.getCore().byId("rfExitReason").setValue();
				this.onCancel();
			}

		},
		onSaveHBC: function() {
			var e = this.byId("tlbHbcSummary");
			if (sap.ui.getCore().byId("hbcgender").getSelectedItem() === null || sap.ui.getCore().byId("hbcrace").getSelectedItem() === null ||
				sap.ui.getCore().byId("hbcname").getValue() === "" || sap.ui.getCore().byId("hbcidnum").getValue() === "" || sap.ui.getCore().byId(
					"hbcage").getValue() === "") {
				s.error("Please sure make you enter all the required inputs, e.g Name, Age, gender, race, etc");
			} else {
				this.HBCModel.getData().data.push({
					RecordId: "",
					Zztype: "",
					Zzafld000007: sap.ui.getCore().byId("hbcname").getValue(),
					Zzafld000009: sap.ui.getCore().byId("hbcidnum").getValue(),
					Zzafld00000a: sap.ui.getCore().byId("hbcgender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("hbcrace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("hbcdisabled").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("hbcdisabilitynature").getValue(),
					Zzafld00000g: sap.ui.getCore().byId("hbcage").getValue(),
					Zzafld00000h: sap.ui.getCore().byId("hbccounselrec").getSelectedItem().getKey(),
					Zzafld0000mh: sap.ui.getCore().byId("hbcPHC").getSelectedItem().getKey(),
					Zzafld0000mi: sap.ui.getCore().byId("hbcMeals").getSelectedItem().getKey(),
					Zzafld0000mj: sap.ui.getCore().byId("hbcRECactivities").getSelectedItem().getKey(),
					Zzafld0000mk: sap.ui.getCore().byId("hbcShoppingAssist").getSelectedItem().getKey(),
					Zzafld0000ml: sap.ui.getCore().byId("hbcTransport").getSelectedItem().getKey(),
					Zzafld00000i: sap.ui.getCore().byId("hbcother").getValue()
				});
				e.setModel();
				e.setModel(this.HBCModel, "HBCModel");
				e.getModel("HBCModel").refresh(true);
				sap.ui.getCore().byId("hbcname").setValue();
				sap.ui.getCore().byId("hbcidnum").setValue();
				sap.ui.getCore().byId("hbcage").setValue();
				sap.ui.getCore().byId("hbcgender").setValue();
				sap.ui.getCore().byId("hbcrace").setValue();
				sap.ui.getCore().byId("hbcdisabled").setValue();
				sap.ui.getCore().byId("hbcdisabilitynature").setValue();
				sap.ui.getCore().byId("hbcPHC").setValue();
				sap.ui.getCore().byId("hbcMeals").setValue();
				sap.ui.getCore().byId("hbcRECactivities").setValue();
				sap.ui.getCore().byId("hbcShoppingAssist").setValue();
				sap.ui.getCore().byId("hbcTransport").setValue();
				this.onCancel();
			}
		},
		onSaveAwareness: function() {
			var e = this.byId("tblhbcaAwareness");
			if (sap.ui.getCore().byId("aGender").getSelectedItem() === null || sap.ui.getCore().byId("aRace").getSelectedItem() === null || sap
				.ui.getCore().byId("aname").getValue() === "" || sap.ui.getCore().byId("aidnum").getValue() === "" || sap.ui.getCore().byId("aAge")
				.getValue() === "") {
				s.error("Please sure make you enter all the required inputs, e.g Name, Age, gender, race, etc");
			} else {
				this.AwarenessModel.getData().data.push({
					RecordId: "",
					Zztype: "",
					Zzafld000007: sap.ui.getCore().byId("aname").getValue(),
					Zzafld000009: sap.ui.getCore().byId("aidnum").getValue(),
					Zzafld00000a: sap.ui.getCore().byId("aGender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("aRace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("aDisability").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("aDisabilitynature").getValue(),
					Zzafld00000g: sap.ui.getCore().byId("aAge").getValue(),
					Zzafld00000h: sap.ui.getCore().byId("aCounselrec").getSelectedItem().getKey(),
					Zzafld00000x: sap.ui.getCore().byId("aOther").getValue()
				});
				e.setModel();
				e.setModel(this.AwarenessModel, "AwarenessModel");
				e.getModel("AwarenessModel").refresh(true);
				sap.ui.getCore().byId("aname").setValue();
				sap.ui.getCore().byId("aidnum").setValue();
				sap.ui.getCore().byId("aAge").setValue();
				sap.ui.getCore().byId("aGender").setValue();
				sap.ui.getCore().byId("aRace").setValue();
				sap.ui.getCore().byId("aDisability").setValue();
				sap.ui.getCore().byId("aDisabilitynature").setValue();
				sap.ui.getCore().byId("aCounselrec").setValue();
				sap.ui.getCore().byId("aOther").setValue();
				this.onCancel();
			}
		},
		onSaveAgeing: function() {
			var e = this.byId("tblAAgeing");
			if (sap.ui.getCore().byId("agGender").getSelectedItem() === null || sap.ui.getCore().byId("agRace").getSelectedItem() === null ||
				sap.ui.getCore().byId("agname").getValue() === "" || sap.ui.getCore().byId("agidnum").getValue() === "" || sap.ui.getCore().byId(
					"agAge").getValue() === "") {
				s.error("Please sure make you enter all the required inputs, e.g Name, Age, gender, race, etc");
			} else {
				this.AgeingModel.getData().data.push({
					RecordId: "",
					Zztype: "",
					Zzafld000007: sap.ui.getCore().byId("agname").getValue(),
					Zzafld000009: sap.ui.getCore().byId("agidnum").getValue(),
					Zzafld00000a: sap.ui.getCore().byId("agGender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("agRace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("agDisability").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("agDisabilitynature").getValue(),
					Zzafld00000g: sap.ui.getCore().byId("agAge").getValue(),
					Zzafld00000h: sap.ui.getCore().byId("agcounselrec").getSelectedItem().getKey(),
					Zzafld000015: sap.ui.getCore().byId("agtype").getValue(),
					Zzafld00000t: sap.ui.getCore().byId("totalNumber").getValue()
				});
				e.setModel();
				e.setModel(this.AgeingModel, "AgeingModel");
				e.getModel("AgeingModel").refresh(true);
				sap.ui.getCore().byId("agname").setValue();
				sap.ui.getCore().byId("agidnum").setValue();
				sap.ui.getCore().byId("agAge").setValue();
				sap.ui.getCore().byId("agGender").setValue();
				sap.ui.getCore().byId("agRace").setValue();
				sap.ui.getCore().byId("agDisability").setValue();
				sap.ui.getCore().byId("agDisabilitynature").setValue();
				sap.ui.getCore().byId("agcounselrec").setValue();
				sap.ui.getCore().byId("totalNumber").setValue();
				this.onCancel();
			}
		},
		onSaveClaims: function() {
			var e = this.byId("tblipcClaimForm");
			if (sap.ui.getCore().byId("clGender").getSelectedItem() === null || sap.ui.getCore().byId("clRace").getSelectedItem() === null ||
				sap.ui.getCore().byId("clname").getValue() === "" || sap.ui.getCore().byId("clidnum").getValue() === "" || sap.ui.getCore().byId(
					"clAge").getValue() === "" || sap.ui.getCore().byId("clDoA").getValue() === "" || sap.ui.getCore().byId("clDoE").getValue() ===
				"") {
				s.error("Please sure make you enter all the required inputs, e.g Name, Age, gender, race, etc");
			} else {
				this.ClaimsModel.getData().data.push({
					RecordId: "",
					Zztype: "CLAIM",
					Zzafld000007: sap.ui.getCore().byId("clname").getValue(),
					Zzafld000009: sap.ui.getCore().byId("clidnum").getValue(),
					Zzafld00000a: sap.ui.getCore().byId("clGender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("clRace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("clDisabled").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("clDisabilitynature").getValue(),
					Zzafld00000g: sap.ui.getCore().byId("clAge").getValue(),
					Zzafld00000h: sap.ui.getCore().byId("clCounselRec").getSelectedItem().getKey(),
					Zzafld00000o: this.convertToSAPDate(sap.ui.getCore().byId("clDoA").getValue()),
					Zzafld00000l: this.convertToSAPDate(sap.ui.getCore().byId("clDoE").getValue()),
					Zzafld00000t: sap.ui.getCore().byId("clNumDays").getValue(),
					Zzafld000019: sap.ui.getCore().byId("clAmount").getValue()
				});
				e.setModel();
				e.setModel(this.ClaimsModel, "ClaimsModel");
				e.getModel("ClaimsModel").refresh(true);
				sap.ui.getCore().byId("clname").setValue();
				sap.ui.getCore().byId("clidnum").setValue();
				sap.ui.getCore().byId("clAge").setValue();
				sap.ui.getCore().byId("clGender").setValue();
				sap.ui.getCore().byId("clRace").setValue();
				sap.ui.getCore().byId("clDisabled").setValue();
				sap.ui.getCore().byId("clDisabilitynature").setValue();
				sap.ui.getCore().byId("clCounselRec").setValue();
				sap.ui.getCore().byId("clDoA").setValue();
				sap.ui.getCore().byId("clDoE").setValue();
				sap.ui.getCore().byId("clNumDays").setValue();
				sap.ui.getCore().byId("clAmount").setValue();
				this.onCancel();
			}
		},
		onSaveSpecialServices: function() {
			var e = this.byId("tblSpecialServices");
			if (sap.ui.getCore().byId("ssGender").getSelectedItem() === null || sap.ui.getCore().byId("ssRace").getSelectedItem() === null ||
				sap.ui.getCore().byId("ssname").getValue() === "" || sap.ui.getCore().byId("ssidnum").getValue() === "" || sap.ui.getCore().byId(
					"ssAge").getValue() === "") {
				s.error("Please sure make you enter all the required inputs, e.g Name, Age, gender, race, etc");
			} else {
				this.SpecialServiceModel.getData().data.push({
					RecordId: "",
					Zztype: "SPEC",
					Zzafld000007: sap.ui.getCore().byId("ssname").getValue(),
					Zzafld000009: sap.ui.getCore().byId("ssidnum").getValue(),
					Zzafld00000a: sap.ui.getCore().byId("ssGender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("ssRace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("ssDisabled").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("ssdisabilitynature").getValue(),
					Zzafld00000g: sap.ui.getCore().byId("ssAge").getValue(),
					Zzafld00000n: sap.ui.getCore().byId("ssService").getValue(),
					Zzafld00000o: this.convertToSAPDate(sap.ui.getCore().byId("ssDateReferred").getValue())
				});
				e.setModel();
				e.setModel(this.SpecialServiceModel, "SpecialServiceModel");
				e.getModel("SpecialServiceModel").refresh(true);
				sap.ui.getCore().byId("ssname").setValue();
				sap.ui.getCore().byId("ssidnum").setValue();
				sap.ui.getCore().byId("ssAge").setValue();
				sap.ui.getCore().byId("ssGender").setValue();
				sap.ui.getCore().byId("ssRace").setValue();
				sap.ui.getCore().byId("ssDisabled").setValue();
				sap.ui.getCore().byId("ssdisabilitynature").setValue();
				sap.ui.getCore().byId("ssService").setValue();
				sap.ui.getCore().byId("ssDateReferred").setValue();
				this.onCancel();
			}
		},
		onSaveHomesForPersons: function() {
			var e = this.byId("tblHPN");
			if (sap.ui.getCore().byId("hpGender").getSelectedItem() === null || sap.ui.getCore().byId("hpRace").getSelectedItem() === null ||
				sap.ui.getCore().byId("hpname").getValue() === "" || sap.ui.getCore().byId("hpidnum").getValue() === "" || sap.ui.getCore().byId(
					"hpAge").getValue() === "") {
				s.error("Please sure make you enter all the required inputs, e.g Name, Age, gender, race, etc");
			} else {
				this.HomesForPersonsModel.getData().data.push({
					RecordId: "",
					Zztype: "HOME",
					Zzafld000007: sap.ui.getCore().byId("hpname").getValue(),
					Zzafld000009: sap.ui.getCore().byId("hpidnum").getValue(),
					Zzafld00000a: sap.ui.getCore().byId("hpGender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("hpRace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("hpDisabled").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("hpdisabilityspecify").getValue(),
					Zzafld00000o: this.convertToSAPDate(sap.ui.getCore().byId("hpadmissiondate").getValue()),
					Zzafld00000g: sap.ui.getCore().byId("hpAge").getValue(),
					Zzafld00000h: sap.ui.getCore().byId("hpCounselRec").getSelectedItem().getKey(),
					Zzafld00000l: this.convertToSAPDate(sap.ui.getCore().byId("hpDateExit").getValue()),
					Zzafld00000m: sap.ui.getCore().byId("hpExitReason").getValue(),
					Zzafld00000k: sap.ui.getCore().byId("hpIncome").getValue()

				});
				e.setModel();
				e.setModel(this.HomesForPersonsModel, "HomesForPersonsModel");
				e.getModel("HomesForPersonsModel").refresh(true);
				sap.ui.getCore().byId("hpname").setValue();
				sap.ui.getCore().byId("hpidnum").setValue();
				sap.ui.getCore().byId("hpAge").setValue();
				sap.ui.getCore().byId("hpGender").setValue();
				sap.ui.getCore().byId("hpRace").setValue();
				sap.ui.getCore().byId("hpDisabled").setValue();
				sap.ui.getCore().byId("hpdisabilityspecify").setValue();
				sap.ui.getCore().byId("hpadmissiondate").setValue();
				sap.ui.getCore().byId("hpCounselRec").setValue();
				sap.ui.getCore().byId("hpDateExit").setValue();
				sap.ui.getCore().byId("hpExitReason").setValue();
				sap.ui.getCore().byId("hpIncome").setValue();
				this.onCancel();
			}
		},
		onSaveProtectiveWorkshops: function() {
			var e = this.byId("tblProtWorkshop");
			if (sap.ui.getCore().byId("proGender").getSelectedItem() === null || sap.ui.getCore().byId("proRace").getSelectedItem() === null ||
				sap.ui.getCore().byId("proname").getValue() === "" || sap.ui.getCore().byId("proidnum").getValue() === "" || sap.ui.getCore().byId(
					"proAge").getValue() === "") {
				s.error("Please sure make you enter all the required inputs, e.g Name, Age, gender, race, etc");
			} else {
				this.ProctiveWorkshopModel.getData().data.push({
					RecordId: "",
					Zztype: "",
					Zzafld000007: sap.ui.getCore().byId("proname").getValue(),
					Zzafld000009: sap.ui.getCore().byId("proidnum").getValue(),
					Zzafld00000a: sap.ui.getCore().byId("proGender").getSelectedItem().getKey(),
					Zzafld00000b: sap.ui.getCore().byId("proRace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("proDisabled").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("prodisabilityspecify").getValue(),
					Zzafld00000g: sap.ui.getCore().byId("proAge").getValue(),
					Zzafld00000x: sap.ui.getCore().byId("proservice").getValue(),
					Zzafld000013: sap.ui.getCore().byId("proreferred").getSelectedItem().getKey(),
					Zzafld000014: sap.ui.getCore().byId("orgName").getValue(),
					Zzafld00004w: sap.ui.getCore().byId("proName").getValue(),
					Zzafld000087: sap.ui.getCore().byId("prodesignation").getValue(),
					Zzafld00000o: this.convertToSAPDate(sap.ui.getCore().byId("prodate").getValue())

				});
				e.setModel();
				e.setModel(this.ProctiveWorkshopModel, "ProtectiveWorkshopModel");
				e.getModel("ProtectiveWorkshopModel").refresh(true);
				sap.ui.getCore().byId("proname").setValue();
				sap.ui.getCore().byId("proidnum").setValue();
				sap.ui.getCore().byId("proAge").setValue();
				sap.ui.getCore().byId("proGender").setValue();
				sap.ui.getCore().byId("proRace").setValue();
				sap.ui.getCore().byId("proDisabled").setValue();
				sap.ui.getCore().byId("prodisabilityspecify").setValue();
				sap.ui.getCore().byId("proservice").setValue();
				sap.ui.getCore().byId("proreferred").setValue();
				sap.ui.getCore().byId("orgName").setValue();
				sap.ui.getCore().byId("proName").setValue();
				sap.ui.getCore().byId("prodesignation").setValue();
				sap.ui.getCore().byId("prodate").setValue();
				this.onCancel();
			}
		},
		onSaveHBCAnnexB: function() {
			var e = this.byId("tblAnnexB");
			if (sap.ui.getCore().byId("hbcAnnexGender").getSelectedItem() === null || sap.ui.getCore().byId("hbcAnnexRace").getSelectedItem() ===
				null || sap.ui.getCore().byId("hbcAnnexOrgName").getValue() === "" || sap.ui.getCore().byId("hbcAnnexNameOrgPerson").getValue() ===
				"" || sap.ui.getCore().byId("hbcAnnexDate").getValue() === "") {
				s.error("Please sure make you enter all the required inputs");
			} else {
				this.HBCAnnexBModel.getData().data.push({
					Zzafld00004w: sap.ui.getCore().byId("hbcAnnexOrgName").getValue(),
					Zzafld00004x: sap.ui.getCore().byId("hbcAnnexPersonVisit").getValue(),
					Zzafld00004z: sap.ui.getCore().byId("hbcAnnexGender").getSelectedItem().getKey(),
					Zzafld000050: sap.ui.getCore().byId("hbcAnnexRace").getSelectedItem().getKey(),
					Zzafld0000ln: sap.ui.getCore().byId("hbcAnnexDisabled").getSelectedItem().getKey(),
					Zzafld00000c: sap.ui.getCore().byId("hbcAnnexspecifydisability").getValue(),
					Zzafld00004u: sap.ui.getCore().byId("hbcAnnexAddressPerson").getValue(),
					Zzafld0000lq: sap.ui.getCore().byId("hbcAnnexNameOrgPerson").getValue(),
					Zzafld000053: sap.ui.getCore().byId("hbcAnnexNeeds").getValue(),
					Zzafld000052: sap.ui.getCore().byId("hbcAnnexOther").getValue(),
					Zzafld00004y: sap.ui.getCore().byId("hbcAnnexService").getSelectedItem().getKey(),
					Zzafld000054: sap.ui.getCore().byId("hbcAnnexTotalNumber").getValue(),
					Zzafld000055: sap.ui.getCore().byId("hbcAnnexPersonnel").getValue(),
					Zzafld000056: this.convertToSAPDate(sap.ui.getCore().byId("hbcAnnexDate").getValue())
				});
				e.setModel();
				e.setModel(this.HBCAnnexBModel, "HBCAnnexModel");
				e.getModel("HBCAnnexModel").refresh(true);
				sap.ui.getCore().byId("hbcAnnexOrgName").setValue();
				sap.ui.getCore().byId("hbcAnnexPersonVisit").setValue();
				sap.ui.getCore().byId("hbcAnnexGender").setValue();
				sap.ui.getCore().byId("hbcAnnexRace").setValue();
				sap.ui.getCore().byId("hbcAnnexDisabled").setValue();
				sap.ui.getCore().byId("hbcAnnexspecifydisability").setValue();
				sap.ui.getCore().byId("hbcAnnexAddressPerson").setValue();
				sap.ui.getCore().byId("hbcAnnexNameOrgPerson").setValue();
				sap.ui.getCore().byId("hbcAnnexService").setValue();
				sap.ui.getCore().byId("hbcAnnexOther").setValue();
				sap.ui.getCore().byId("hbcAnnexNeeds").setValue();
				sap.ui.getCore().byId("hbcAnnexTotalNumber").setValue();
				sap.ui.getCore().byId("hbcAnnexPersonnel").setValue();
				sap.ui.getCore().byId("hbcAnnexDate").setValue();
				this.onCancel();
			}
		},
		onSaveAnnexureA: function() {
			var e = this.byId("tblhbcaAnnexA");
			if (sap.ui.getCore().byId("annexName").getValue() === "" || sap.ui.getCore().byId("annexID").getValue() === "" || sap.ui.getCore().byId(
					"annexOrg").getValue() === "" || sap.ui.getCore().byId("annexMonth").getValue() === "") {
				s.error("Please sure make you enter all the required inputs");
			} else {
				this.AnnexureAModel.getData().data.push({
					ObjectId: "",
					ParentId: "",
					Zzafld00001d: sap.ui.getCore().byId("annexName").getValue(),
					Zzafld00001e: sap.ui.getCore().byId("annexID").getValue(),
					Zzafld00001f: sap.ui.getCore().byId("annexDay1").getSelected(),
					Zzafld00001g: sap.ui.getCore().byId("annexDay2").getSelected(),
					Zzafld00001h: sap.ui.getCore().byId("annexDay3").getSelected(),
					Zzafld00001i: sap.ui.getCore().byId("annexDay4").getSelected(),
					Zzafld00001j: sap.ui.getCore().byId("annexDay5").getSelected(),
					Zzafld00001k: sap.ui.getCore().byId("annexDay6").getSelected(),
					Zzafld00001l: sap.ui.getCore().byId("annexDay7").getSelected(),
					Zzafld00001m: sap.ui.getCore().byId("annexDay8").getSelected(),
					Zzafld00001n: sap.ui.getCore().byId("annexDay9").getSelected(),
					Zzafld00001o: sap.ui.getCore().byId("annexDay10").getSelected(),
					Zzafld00001p: sap.ui.getCore().byId("annexDay11").getSelected(),
					Zzafld00001q: sap.ui.getCore().byId("annexDay12").getSelected(),
					Zzafld00001r: sap.ui.getCore().byId("annexDay13").getSelected(),
					Zzafld00001s: sap.ui.getCore().byId("annexDay14").getSelected(),
					Zzafld00001t: sap.ui.getCore().byId("annexDay15").getSelected(),
					Zzafld00001u: sap.ui.getCore().byId("annexDay16").getSelected(),
					Zzafld00001v: sap.ui.getCore().byId("annexDay17").getSelected(),
					Zzafld00001w: sap.ui.getCore().byId("annexDay18").getSelected(),
					Zzafld00001x: sap.ui.getCore().byId("annexDay19").getSelected(),
					Zzafld00001y: sap.ui.getCore().byId("annexDay20").getSelected(),
					Zzafld00001z: sap.ui.getCore().byId("annexDay21").getSelected(),
					Zzafld000020: sap.ui.getCore().byId("annexDay22").getSelected(),
					Zzafld000023: sap.ui.getCore().byId("annexOrg").getValue(),
					Zzafld000024: sap.ui.getCore().byId("annexMonth").getValue()
				});
				e.setModel();
				e.setModel(this.AnnexureAModel, "AnnexAModel");
				e.getModel("AnnexAModel").refresh(true);
				sap.ui.getCore().byId("annexName").setValue();
				sap.ui.getCore().byId("annexID").setValue();
				sap.ui.getCore().byId("annexDay1").setSelected(false);
				sap.ui.getCore().byId("annexDay2").setSelected(false);
				sap.ui.getCore().byId("annexDay3").setSelected(false);
				sap.ui.getCore().byId("annexDay4").setSelected(false);
				sap.ui.getCore().byId("annexDay5").setSelected(false);
				sap.ui.getCore().byId("annexDay6").setSelected(false);
				sap.ui.getCore().byId("annexDay7").setSelected(false);
				sap.ui.getCore().byId("annexDay8").setSelected(false);
				sap.ui.getCore().byId("annexDay9").setSelected(false);
				sap.ui.getCore().byId("annexDay10").setSelected(false);
				sap.ui.getCore().byId("annexDay11").setSelected(false);
				sap.ui.getCore().byId("annexDay12").setSelected(false);
				sap.ui.getCore().byId("annexDay13").setSelected(false);
				sap.ui.getCore().byId("annexDay14").setSelected(false);
				sap.ui.getCore().byId("annexDay15").setSelected(false);
				sap.ui.getCore().byId("annexDay16").setSelected(false);
				sap.ui.getCore().byId("annexDay17").setSelected(false);
				sap.ui.getCore().byId("annexDay18").setSelected(false);
				sap.ui.getCore().byId("annexDay19").setSelected(false);
				sap.ui.getCore().byId("annexDay20").setSelected(false);
				sap.ui.getCore().byId("annexDay21").setSelected(false);
				sap.ui.getCore().byId("annexDay22").setSelected(false);
				sap.ui.getCore().byId("annexOrg").setValue();
				sap.ui.getCore().byId("annexMonth").setValue();
				this.onCancel();
			}
		},
		onUpdateClaim: function() {
			sap.ui.core.BusyIndicator.show(0);
			var e = this.byId("particular").getModel().getData().data;
			e.ClaimType = this.claimType;
			e.Status = "E0019";
			this._ObjectGuid = e.Guid;
			this._oODataModel.update("/GetClaimsSet(Guid='" + e.Guid + "')", e, {
				success: function(e) {
					this.onSubmitCapacity();
				}.bind(this),
				error: function(e) {
					sap.ui.core.BusyIndicator.hide();
					s.error("Error occured when submiting Application");
				}
			});
		},
		onSubmitCapacity: function() {
			var e = [],
				t = [],
				i = [],
				a = {},
				l = {},
				r = {};
			var d = [],
				o = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZDSD_CRM_UI5_APP_SRV/");
			for (var n = 0; n < this.SWPModel.getData().data.length; n++) {
				a = this.SWPModel.getData().data[n];
				a.ParentId = this._ObjectGuid;
				e.push(a);
			}
			for (var b = 0; b < this.SummaryStaffyModel.getData().data.length; b++) {
				a = this.SummaryStaffyModel.getData().data[b];
				a.ParentId = this._ObjectGuid;
				e.push(a);
			}
			for (var u = 0; u < this.HomesForPersonsModel.getData().data.length; u++) {
				a = this.HomesForPersonsModel.getData().data[u];
				a.ParentId = this._ObjectGuid;
				e.push(a);
			}
			for (var u = 0; u < this.SpecialServiceModel.getData().data.length; u++) {
				a = this.SpecialServiceModel.getData().data[u];
				a.ParentId = this._ObjectGuid;
				e.push(a);
			}
			for (var u = 0; u < this.ClaimsModel.getData().data.length; u++) {
				a = this.ClaimsModel.getData().data[u];
				a.ParentId = this._ObjectGuid;
				e.push(a);
			}
			for (var u = 0; u < this.AgeingModel.getData().data.length; u++) {
				a = this.AgeingModel.getData().data[u];
				a.ParentId = this._ObjectGuid;
				e.push(a);
			}
			for (var u = 0; u < this.AwarenessModel.getData().data.length; u++) {
				a = this.AwarenessModel.getData().data[u];
				a.ParentId = this._ObjectGuid;
				e.push(a);
			}
			for (var u = 0; u < this.HBCModel.getData().data.length; u++) {
				a = this.HBCModel.getData().data[u];
				a.ParentId = this._ObjectGuid;
				e.push(a);
			}
			for (var u = 0; u < this.ProctiveWorkshopModel.getData().data.length; u++) {
				a = this.ProctiveWorkshopModel.getData().data[u];
				a.ParentId = this._ObjectGuid;
				e.push(a);
			}
			for (var u = 0; u < this.PlacesModel.getData().data.length; u++) {
				a = this.PlacesModel.getData().data[u];
				a.ParentId = this._ObjectGuid;
				e.push(a);
			}
			for (var u = 0; u < this.ChildrenHomeModel.getData().data.length; u++) {
				a = this.ChildrenHomeModel.getData().data[u];
				a.ParentId = this._ObjectGuid;
				e.push(a);
			}
			for (var u = 0; u < this.BeneficiaryModel.getData().data.length; u++) {
				a = this.BeneficiaryModel.getData().data[u];
				a.ParentId = this._ObjectGuid;
				e.push(a);
			}
			for (var u = 0; u < this.HBCAnnexBModel.getData().data.length; u++) {
				r = this.HBCAnnexBModel.getData().data[u];
				r.ParentId = this._ObjectGuid;
				i.push(r);
			}
			for (var u = 0; u < this.AnnexureAModel.getData().data.length; u++) {
				l = this.AnnexureAModel.getData().data[u];
				l.ParentId = this._ObjectGuid;
				t.push(l);
			}

			if (e.length > 0 || t.length > 0 || i.length > 0) {
				for (var h = 0; h < e.length; h++) {
					d.push(o.createBatchOperation("/GetCapacitySet", "POST", e[h]));
				}
				for (var g = 0; g < t.length; g++) {
					d.push(o.createBatchOperation("/GetClaimAnnexureASet", "POST", t[g]));
				}
				for (var c = 0; c < i.length; c++) {
					d.push(o.createBatchOperation("/GetClaimAnnexureBSet", "POST", i[c]));
				}
				o.addBatchChangeOperations(d);
				o.setUseBatch(true);
				sap.ui.core.BusyIndicator.show();
				o.submitBatch(function(e) {
					var t = new DOMParser(),
						i;
					sap.ui.core.BusyIndicator.hide();
					if (e.__batchResponses[0].__changeResponses[0].statusCode.startsWith("2")) {
						this.successAndNavigate();
					} else {
						s.error("Error occured when updating claim");
					}
					o.resetChanges();
					o.refresh();
				}.bind(this), function(e) {
					sap.ui.core.BusyIndicator.hide();
				});
			} else {
				sap.ui.core.BusyIndicator.hide();
				this.successAndNavigate();
			}
		},
		successAndNavigate: function(e) {
			s.success("Claim Saved", {
				icon: sap.m.MessageBox.Icon.CONFIRMATION,
				title: "Confirmation",
				actions: [sap.m.MessageBox.Action.OK],
				onClose: function(e) {
					if (e === "OK") {
						this.Router.navTo("ListOfClaims");
						return;
					}
				}.bind(this)
			});
		},

		onPressResidentialFacility: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogHBC = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditResidentialFacility");
			this._DialogHBC.setModel(this.HBCModel);
			this._DialogHBC.bindElement(s);
			this._DialogHBC.open();
		},
		onPressSWPost: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogSocialWorkPost = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditSocialWorkPosts");
			this._DialogSocialWorkPost.setModel(this.SWPModel);
			this._DialogSocialWorkPost.bindElement(s);
			this._DialogSocialWorkPost.open();
		},
		onPressHBCAnnexB: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogHCBAnnexB = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditHBCAnnexB");
			this._DialogHCBAnnexB.setModel(this.HBCAnnexBModel);
			this._DialogHCBAnnexB.bindElement(s);
			this._DialogHCBAnnexB.open();
		},
		onPressSpecialServices: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogSpecialServices = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditSpecialServices");
			this._DialogSpecialServices.setModel(this.SpecialServiceModel);
			this._DialogSpecialServices.bindElement(s);
			this._DialogSpecialServices.open();
		},
		onPressSummaryStaff: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogSummary = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditSummaryOfStaff");
			this._DialogSummary.setModel(this.SummaryStaffyModel);
			this._DialogSummary.bindElement(s);
			this._DialogSummary.open();
		},
		onPressBeneficiary: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogBeneficiary = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditBeneficiary");
			this._DialogBeneficiary.setModel(this.BeneficiaryModel);
			this._DialogBeneficiary.bindElement(s);
			this._DialogBeneficiary.open();
		},
		onPressChildrenHome: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogChildren = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditChildrenHome");
			this._DialogChildren.setModel(this.ChildrenHomeModel);
			this._DialogChildren.bindElement(s);
			this._DialogChildren.open();
		},
		onPressHBCSummary: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogHBC = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditHBCSummary");
			this._DialogHBC.setModel(this.HBCModel);
			this._DialogHBC.bindElement(s);
			this._DialogHBC.open();
		},
		onPressHomesForPerson: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogHomesPersons = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditHomeForPersons");
			this._DialogHomesPersons.setModel(this.HomesForPersonsModel);
			this._DialogHomesPersons.bindElement(s);
			this._DialogHomesPersons.open();
		},
		onPressPlaces: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogPlaces = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditPlacesOfStay");
			this._DialogPlaces.setModel(this.PlacesModel);
			this._DialogPlaces.bindElement(s);
			this._DialogPlaces.open();
		},
		onPressAwareness: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogAwareness = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditAwareness");
			this._DialogAwareness.setModel(this.AwarenessModel);
			this._DialogAwareness.bindElement(s);
			this._DialogAwareness.open();
		},
		onPressAgeing: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogAgeing = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditActiveAgeing");
			this._DialogAgeing.setModel(this.AgeingModel);
			this._DialogAgeing.bindElement(s);
			this._DialogAgeing.open();
		},
		onPressClaim: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogClaim = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditClaimForm");
			this._DialogClaim.setModel(this.ClaimsModel);
			this._DialogClaim.bindElement(s);
			this._DialogClaim.open();
		},
		onPressProtectiveWorkshops: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogProtective = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditProtectiveWorkshops");
			this._DialogProtective.setModel(this.ProctiveWorkshopModel);
			this._DialogProtective.bindElement(s);
			this._DialogProtective.open();
		},
		onPressAnnexureA: function(e) {
			var t = e.getSource();
			var s = t.getBindingContextPath();
			this._DialogAnnexureA = this.createFormDialog("gdsd.NewClaimsApp.view.fragments.EditAnnexureA");
			this._DialogAnnexureA.setModel(this.AnnexureAModel);
			this._DialogAnnexureA.bindElement(s);
			this._DialogAnnexureA.open();
		},
		getCapacities: function(e) {
			sap.ui.core.BusyIndicator.show(0);
			var t = new sap.ui.model.Filter("RecordId", "EQ", e);
			this._oODataModel.read("/GetCapacitySet", {
				filters: [t],
				success: function(e) {
					this.distrubuteCapacity(e.results);
					this.getClaimAnnexureA(this.Guid);
				}.bind(this),
				error: function(e) {
					sap.ui.core.BusyIndicator.hide();
					s.error("Error occured in the server while trying to retrieve capacity details");
				}.bind(this)
			});
		},
		getClaimAnnexureA: function(e) {
			sap.ui.core.BusyIndicator.show(0);
			var t = new sap.ui.model.Filter("RecordId", "EQ", e);
			var i = this.byId("tblhbcaAwareness");
			this._oODataModel.read("/GetClaimAnnexureASet", {
				filters: [t],
				success: function(e) {
					this.AnnexureAModel.getData().data = e.results;
					i.setModel();
					i.setModel(this.AnnexureAModel, "AnnexAModel");
					i.getModel("AnnexAModel").refresh(true);
					this.getClaimAnnexureB(this.Guid);
				}.bind(this),
				error: function(e) {
					sap.ui.core.BusyIndicator.hide();
					s.error("Error occured in the server while trying to retrieve capacity details");
				}.bind(this)
			});
		},
		getClaimAnnexureB: function(e) {
			sap.ui.core.BusyIndicator.show(0);
			var t = new sap.ui.model.Filter("RecordId", "EQ", e);
			var i = this.byId("tblAnnexB");
			this._oODataModel.read("/GetClaimAnnexureBSet", {
				filters: [t],
				success: function(e) {
					this.HBCAnnexBModel.getData().data = e.results;
					i.setModel();
					i.setModel(this.HBCAnnexBModel, "HBCAnnexModel");
					i.getModel("HBCAnnexModel").refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(e) {
					sap.ui.core.BusyIndicator.hide();
					s.error("Error occured in the server while trying to retrieve capacity details");
				}.bind(this)
			});
		},

		distrubuteCapacity: function(e) {
			for (var t = 0; t < e.length; t++) {
				switch (e[t].Zztype) {
					case "SWP":
						this.SWPModel.getData().data.push(e[t]);
						break;
					case "BENEF":
						this.BeneficiaryModel.getData().data.push(e[t]);
						break;
					case "CHILD":
						this.ChildrenHomeModel.getData().data.push(e[t]);
						break;
					case "CLAIM":
						this.ClaimsModel.getData().data.push(e.data[t]);
						break;
					case "SUMMA":
						this.SummaryStaffyModel.getData().data.push(e[t]);
						break;
					case "PLACE":
						this.PlacesModel.getData().data.push(e[t]);
						break;
					case "HBC":
						this.HBCModel.getData().data.push(e[t]);
						break;
					case "AWARE":
						this.AwarenessModel.getData().data.push(e[t]);
						break;
					case "AGE":
						this.AgeingModel.getData().data.push(e[t]);
						break;
					case "SPEC":
						this.SpecialServiceModel.getData().data.push(e[t]);
						break;
					case "HOME":
						this.HomesForPersonsModel.getData().data.push(e[t]);
						break;
					case "PROT":
						this.ProctiveWorkshopModel.getData().data.push(e[t]);
						break;
				}
			}
			this.RestoreModels();
		},
		convertToSAPDate: function(e) {
			var t = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-ddTKK:mm:ss"
			});
			return t.format(new Date(e));
		},
		onValidateID: function(e) {
			var t = e.getSource();
			var i;
			i = t.getValue();
			if (i.length <= 13) {
				this.ValueOther = i;
				sap.ui.getCore().byId(e.mParameters.id).setValue(i);
			} else {
				sap.ui.getCore().byId(e.mParameters.id).setValue(this.ValueOther);
				s.error("Exceeded the limit");
			}
		},
		onValidateAge: function(e) {
			var t = e.getSource();
			var i;
			i = t.getValue();
			if (i.length <= 3) {
				this.ValueOther = i;
				sap.ui.getCore().byId(e.mParameters.id).setValue(i);
			} else {
				sap.ui.getCore().byId(e.mParameters.id).setValue(this.ValueOther);
				s.error("Exceeded the limit");
			}
		},
		handleChangeDropdown: function(e) {
			var t = e.getSource(),
				i = t.getSelectedKey(),
				a = t.getValue();
			if (!i && a) {
				s.error("Please select value from the drop downlist");
				sap.ui.getCore().byId(e.mParameters.id).setValue("");
			}
		},
		RestoreModels: function(e) {
			var t = this.byId("tblhbcaAnnexA"),
				s = this.byId("tblAnnexB"),
				i = this.byId("tblProtWorkshop"),
				a = this.byId("tblHPN"),
				l = this.byId("tblSpecialServices"),
				r = this.byId("tblipcClaimForm"),
				d = this.byId("tblAAgeing"),
				o = this.byId("tblhbcaAwareness"),
				n = this.byId("tlbHbcSummary"),
				b = this.byId("tblCHPlaceofSafety"),
				u = this.byId("tblCHbeneficiaries"),
				h = this.byId("beneficiaries"),
				g = this.byId("tblSWPstaffsummary"),
				c = this.byId("tblSWPdisability"),
				f = this.byId("tblResFacility");
			c.setModel();
			c.setModel(this.SWPModel, "SocialWorkPostModel");
			c.getModel("SocialWorkPostModel").refresh(true);
			g.setModel();
			g.setModel(this.SummaryStaffyModel, "StaffSummaryPostModel");
			g.getModel("StaffSummaryPostModel").refresh(true);
			h.setModel();
			h.setModel(this.BeneficiaryModel, "BeneficiaryPostModel");
			h.getModel("BeneficiaryPostModel").refresh(true);
			u.setModel();
			u.setModel(this.ChildrenHomeModel, "ChildrenHomeModel");
			u.getModel("ChildrenHomeModel").refresh(true);
			b.setModel();
			b.setModel(this.PlacesModel, "PlacesModel");
			b.getModel("PlacesModel").refresh(true);
			n.setModel();
			n.setModel(this.HBCModel, "HBCModel");
			n.getModel("HBCModel").refresh(true);
			f.setModel(this.HBCModel, "HBCModel");
			f.getModel("HBCModel").refresh(true);
			o.setModel();
			o.setModel(this.AwarenessModel, "AwarenessModel");
			o.getModel("AwarenessModel").refresh(true);
			d.setModel();
			d.setModel(this.AgeingModel, "AgeingModel");
			d.getModel("AgeingModel").refresh(true);
			r.setModel();
			r.setModel(this.ClaimsModel, "ClaimsModel");
			r.getModel("ClaimsModel").refresh(true);
			l.setModel();
			l.setModel(this.SpecialServiceModel, "SpecialServiceModel");
			l.getModel("SpecialServiceModel").refresh(true);
			a.setModel();
			a.setModel(this.HomesForPersonsModel, "HomesForPersonsModel");
			a.getModel("HomesForPersonsModel").refresh(true);
			i.setModel();
			i.setModel(this.ProctiveWorkshopModel, "ProtectiveWorkshopModel");
			i.getModel("ProtectiveWorkshopModel").refresh(true);
			sap.ui.core.BusyIndicator.hide();
			//	t.setModel();
			//	t.setModel(this.AnnexAModel, "AnnexAModel");
			//	t.getModel("AnnexAModel").refresh(true);
		},
		onDeleteSWPPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("SocialWorkPostModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("SocialWorkPostModel").getModel().getData()[a[1]].splice(i, 1);
			this.SWPModel.refresh();
		},
		onDeleteSummaryPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("StaffSummaryPostModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("StaffSummaryPostModel").getModel().getData()[a[1]].splice(i, 1);
			this.SummaryStaffyModel.refresh();
		},
		onDeleteBeneficiaryPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("BeneficiaryPostModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("BeneficiaryPostModel").getModel().getData()[a[1]].splice(i, 1);
			this.BeneficiaryModel.refresh();
		},
		onDeleteChildrenHomePressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("ChildrenHomeModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("ChildrenHomeModel").getModel().getData()[a[1]].splice(i, 1);
			this.ChildrenHomeModel.refresh();
		},
		onDeletePlaceofSafetyPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("PlacesModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("PlacesModel").getModel().getData()[a[1]].splice(i, 1);
			this.PlacesModel.refresh();
		},
		onDeleteHBCAnnexBPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("HBCAnnexModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("HBCAnnexModel").getModel().getData()[a[1]].splice(i, 1);
			this.HBCAnnexModel.refresh();
		},
		onDeleteHBCSummaryPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("HBCModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("HBCModel").getModel().getData()[a[1]].splice(i, 1);
			this.HBCModel.refresh();
		},

		onDeleteResFacilityPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("HBCModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("HBCModel").getModel().getData()[a[1]].splice(i, 1);
			this.HBCModel.refresh();
		},
		onDeleteAwarenessProgPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("AwarenessModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("AwarenessModel").getModel().getData()[a[1]].splice(i, 1);
			this.AwarenessModel.refresh();
		},
		onDeleteAgeingPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("AgeingModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("AgeingModel").getModel().getData()[a[1]].splice(i, 1);
			this.AgeingModel.refresh();
		},
		onDeleteClaimFormPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("ClaimsModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("ClaimsModel").getModel().getData()[a[1]].splice(i, 1);
			this.ClaimsModel.refresh();
		},
		onDeleteSpecialServicesPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("SpecialServiceModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("SpecialServiceModel").getModel().getData()[a[1]].splice(i, 1);
			this.SpecialServiceModel.refresh();
		},
		onDeleteHomesForPersonsPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("HomesForPersonsModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("HomesForPersonsModel").getModel().getData()[a[1]].splice(i, 1);
			this.HomesForPersonsModel.refresh();
		},
		onDeleteProtectiveWorkshopsPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("ProtectiveWorkshopModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("ProtectiveWorkshopModel").getModel().getData()[a[1]].splice(i, 1);
			this.ProctiveWorkshopModel.refresh();
		},

		onDeleteSummaryofStaffPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("StaffSummaryPostModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("StaffSummaryPostModel").getModel().getData()[a[1]].splice(i, 1);
			this.StaffSummaryPostModel.refresh();
		},

		onDeleteAnnexAPressed: function(e) {
			var t = /\/([^/]+)\//;
			var s = e.getSource().getBindingContext("AnnexAModel").getPath();
			var i = parseInt(s[s.length - 1], 0);
			var a = t.exec(s);
			e.getSource().getBindingContext("AnnexAModel").getModel().getData()[a[1]].splice(i, 1);
			this.AnnexAModel.refresh();
		}
	});
});