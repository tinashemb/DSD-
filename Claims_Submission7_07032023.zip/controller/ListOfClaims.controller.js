sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter", "sap/ui/model/FilterOperator", "sap/m/MessageBox", "sap/ui/Device"],
	function(e, t, i, o, s) {
		"use strict";
		return e.extend("gdsd.NewClaimsApp.controller.ListOfClaims", {
			onInit: function() {
				this._oODataModel = this.getOwnerComponent().getModel();
				this.Router = sap.ui.core.UIComponent.getRouterFor(this);
				this._claimsModel = this.getOwnerComponent().getModel("Claims");
				this.Router.getRoute("ListOfClaims").attachPatternMatched(this._onObjectMatched, this);
			},
			_onObjectMatched: function(e) {
				this.getClaims();
			},
			getClaims: function() {
				sap.ui.core.BusyIndicator.show(0);
				this._oODataModel.read("/GetClaimsSet", {
					success: function(e) {
						if (e.results[0]) {
							var t = new sap.ui.model.json.JSONModel({
								data: e.results[0]
							});
						}
						this._claimsModel.getData().data = e.results;
						var i = new sap.ui.model.json.JSONModel({
							data: e.results
						});
						this.getView().setModel();
						this.byId("headerNPO").setModel(t);
						this.byId("headerNPO").bindElement({
							path: "/data"
						});
						this.getView().setModel(this._claimsModel);
						this.getView().getModel().refresh(true);
						sap.ui.core.BusyIndicator.hide();
					}.bind(this),
					error: function(e) {
						sap.ui.core.BusyIndicator.hide();
						o.error("Error occured in the server while trying to retrieve claim details");
					}.bind(this)
				});
			},
			onItemPress: function(e) {
				if (e.getSource().getBindingContext().getProperty("ClaimType") === "") {
					this.Router.navTo("FormSelection", {
						claimPath: window.encodeURIComponent(e.getSource().getBindingContext().getPath().substr(1))
					});
				} else {
					this.Router.navTo("SocialWorkPosts", {
						FormNo: e.getSource().getBindingContext().getProperty("ClaimType"),
						claimPath: window.encodeURIComponent(e.getSource().getBindingContext().getPath().substr(1))
					});
				}
			},
			onSearch: function(e) {
				var i = e.getSource().getValue();
				if (i && i.length > 0) {
					var o = sap.ui.model.FilterOperator.Contains;
					var s = new t([new sap.ui.model.Filter("ObjectId", o, i)], false);
				}
				var n = this.byId("ApplicationList");
				var r = n.getBinding("items");
				r.filter(s, "Application");
			}
		});
	});