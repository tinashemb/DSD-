sap.ui.define(["./BaseController"], function(e) {
	"use strict";
	return e.extend("gdsd.NewClaimsApp.controller.Shelter", {
		onInit: function() {}
	});
});