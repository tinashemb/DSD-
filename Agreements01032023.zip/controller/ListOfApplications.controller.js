sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox"
], function (Controller, Filter, FilterOperator, History, Sorter, MessageBox) {
	"use strict";
	return Controller.extend("gdsd.Agreements.controller.ListOfApplications", {

		onInit: function () {
			this._oODataModel = this.getOwnerComponent().getModel();
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this._AgreementModel = this.getOwnerComponent().getModel("Agreement");
			this.Router.getRoute("ListOfApplications").attachPatternMatched(this._onObjectMatched, this);
		},

		_onObjectMatched: function () {
			this.getAllAgreements();
		},

		getAllAgreements: function () {
			//1000001809
			var oFilterBP = new sap.ui.model.Filter("BpNo", "EQ", '1600000202');
			this._AgreementModel.getData().data = [];
			sap.ui.core.BusyIndicator.show(0);
			this._oODataModel.read("/GetAgreementSet", {
					filters: [oFilterBP],
				success: function (odata) {
					if (odata.results[0]) {
						var AgreementModel = new sap.ui.model.json.JSONModel({
							data: odata.results[0]
						});
						this.byId("detailPage").setTitle(odata.results[0].DescriptionP);
					}
					this._AgreementModel.getData().data = odata.results;

					this.getView().setModel();
					this.byId("headerNPO").setModel(AgreementModel);
					this.byId("headerNPO").bindElement({
						path: "/data"
					});
					this.getView().setModel(this._AgreementModel);
					this.getView().getModel().refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function (error) {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error("Error occured in the server while trying to retrieve agreement details");
				}.bind(this)
			});
		},

		onItemPress: function (oEvent) {
			this.Router.navTo("ExistingApplication", {
				Path: window.encodeURIComponent(oEvent.getSource().getBindingContext().getPath().substr(1))
			});
		},

		onSearch: function (oEvent) {
			// add filter for search
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var contains = sap.ui.model.FilterOperator.Contains;
				var aFilters = new Filter([
						new sap.ui.model.Filter("ObjectId", contains, sQuery)
						//	new sap.ui.model.Filter("But000/NameOrg2", contains, sQuery)
					],
					false);
			}
			// update list binding
			var oList = this.byId("AgreementList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		}
	});
});