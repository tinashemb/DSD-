sap.ui.define(["./BaseController", "sap/ui/model/Filter", "sap/ui/model/FilterOperator", "sap/m/MessageBox", "sap/ui/Device"], function(t,
	e, i, o, n) {
	"use strict";
	return t.extend("gdsd.FundingApplication.controller.ListOfApplications", {
		onInit: function() {
			this._oODataModel = this.getOwnerComponent().getModel();
			this.Router = sap.ui.core.UIComponent.getRouterFor(this);
			this._ApplicationModel = this.getOwnerComponent().getModel("Applications");
			this.Router.getRoute("ListOfApplications").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(t) {
			this.getAllApplications();
		},
		getAllApplications: function() {
			sap.ui.core.BusyIndicator.show(0);
			this._oODataModel.read("/GETApplicationFundingSet", {
				success: function(t) {
					if (t.results[0]) {
						var e = new sap.ui.model.json.JSONModel({
							data: t.results[0]
						});
						this.byId("detailPage").setTitle(t.results[0].But000.McName1);
					}
					this._ApplicationModel.getData().data = t.results;
					this.getView().setModel();
					this.byId("headerNPO").setModel(e);
					this.byId("headerNPO").bindElement({
						path: "/data"
					});
					this.getView().setModel(this._ApplicationModel);
					this.getView().getModel().refresh(true);
					sap.ui.core.BusyIndicator.hide();
				}.bind(this),
				error: function(t) {
					sap.ui.core.BusyIndicator.hide();
					o.error("Error occured in the server while trying to retrieve application details");
				}.bind(this)
			});
		},
		onNewApplication: function() {
			this.Router.navTo("NewApplication");
			
		},
		onItemPress: function(t) {
			var e = t.getSource();
			this.Router.navTo("ExistingApplication", {
				ApplicationPath: window.encodeURIComponent(e.getBindingContext().getPath().substr(1))
			});
		},
		onSearch: function(t) {
			var i = t.getSource().getValue();
			if (i && i.length > 0) {
				var o = sap.ui.model.FilterOperator.Contains;
				var n = new e([new sap.ui.model.Filter("ObjectId", o, i)], false);
			}
			var s = this.byId("ApplicationList");
			var a = s.getBinding("items");
			a.filter(n, "Application");
		}
	});
});